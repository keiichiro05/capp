<?php
/*
# Proj. : eVisitor
# Auth  : damarteduh@gmail.con©2020
# Create: Home | 2020-01-26 12:11 PM
*/

date_default_timezone_set("Asia/Jakarta");
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo APP_NAME." ".APP_VER; ?></title>
    <link rel="shortcut icon" href="favicon.ico" />

    <!-- Fontawesome -->
    <link href="static/css/font-awesome.min.css" rel="stylesheet">
    <link href="static/css/elegant-icons-style.css" rel="stylesheet" />
    
    <!-- Custome Style -->
    <link rel="stylesheet" href="static/css/damar.style.css">

    <!-- Bootstrap -->
    <link href="static/css/bootstrap.min.css" rel="stylesheet">

    <!-- Load JavaScript Libraries -->
    <script type="text/javascript" src="static/js/jquery-1.12.0.min.js"></script>

    <!-- Bootstrap Javascript -->
    <script type="text/javascript" src="static/js/bootstrap.min.js"></script>
  </head>
  <body>
    <?php 
        if(isset($navtop)) require $navtop;
        if(isset($navside)) require $navside;
        echo '<div class="container-fluid" id="main">';
        include $content;
        echo '</div>';
        if(isset($footer)) require $footer; 
    ?>
  </body>
</html>