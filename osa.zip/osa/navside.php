<?php
/*
Auth : DamarTeduh©2020, Hotel El Royal BWG 2020-03-03 23:23 PM
Rev  : 
*/
?>

<!-- Side Navigation -->
<link rel="stylesheet" href="static/css/sidenav.css">    

<!-- Side Navigation -->
<div id="mySidenav" class="sidenav">
	<input type="checkbox" id="cmdSidenav"><label for="cmdSidenav" class="openmenu" id="openMn"></label>
	<?php 
		foreach ($mModul as $kModul => $vModul) { 
			foreach ($vModul as $key => $value) {
				if($key=="judul"){
	?>
				<a href='<?php echo $kModul; ?>' class="<?php if($controller==$kModul) echo "active"; ?>" title="<?php echo $value; ?>"><span class="<?php echo $kModul; ?>"></span><?php echo $value; ?></a>
	<?php } } } ?>
</div>

<script type="text/javascript">
	$("#cmdSidenav").change(function() {
	  if($(this).prop('checked') == true) {
	    $('#openMn').addClass('exit');
		$('#openMn').removeClass('openmenu');
	    document.getElementById("mySidenav").style.width = "250px";
	  } else {
	  	$('#openMn').addClass('openmenu');
		$('#openMn').removeClass('exit');
	    document.getElementById("mySidenav").style.width = "35px";
	  }
	});
</script>