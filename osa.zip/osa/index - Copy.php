<?php
/*
# Proj. : eVisitor
# Auth  : damarteduh@gmail.con©2020
# Create: Home | 2020-01-26 12:11 PM
*/

//Start the Session
session_start();

// Load config
include "application/config/config.php";

// Set our defaults
    $controller = 'main';
    $action = 'index';
    $url = '';


if(!isset($_SESSION[APP_NAME]["username"])) header('location:login.php');
    
    
// Get request url and script url
    $request_url = (isset($_SERVER['REQUEST_URI'])) ? $_SERVER['REQUEST_URI'] : '';
    $script_url  = (isset($_SERVER['PHP_SELF'])) ? $_SERVER['PHP_SELF'] : '';
        
// Get our url path and trim the / of the left and the right
    if($request_url != $script_url) $url = trim(preg_replace('/'. str_replace('/', '\/', str_replace('index.php', '', $script_url)) .'/', '', $request_url, 1), '/');

// Split the url into segments
    $segments = explode('?', $url);
    $org_segments = explode('/', $request_url);

// Do our default checks
    if(isset($segments[0]) && $segments[0] != '') $controller = $segments[0];
    if(isset($_GET['ac']) && $_GET['ac'] != '') $action = $_GET['ac'];

// Get our controller file
   $path = APP_DIR . 'controllers/' . $controller . '.php';
   $content = APP_DIR . 'views/' . $controller . '/' . $action . '.php';

    if(file_exists($path) AND file_exists($content) AND !isset($org_segments[3])){
        include($path);
    } else {
        require_once('application/assets/error.php');
    }
?>