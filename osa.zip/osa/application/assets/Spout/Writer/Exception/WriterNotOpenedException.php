<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class WriterNotOpenedException
 *
 * @api
 * @package Box\Spout\Writer\Exception
 */
class WriterNotOpenedException extends WriterException
{
}
