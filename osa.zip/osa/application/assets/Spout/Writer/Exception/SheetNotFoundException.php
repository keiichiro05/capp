<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class SheetNotFoundException
 *
 * @api
 * @package Box\Spout\Writer\Exception
 */
class SheetNotFoundException extends WriterException
{
}
