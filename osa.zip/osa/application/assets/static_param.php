<?php
/*
# Prject: VMI Primary 1.0
# Auth  : DamarTeduh©2019
# Create: Cyber 2 | 2019-07-31 11:30 AM
# Rev   : 
# 	20200420 Home, Rework ke template BARU - DWR
*/

# Master tipe sorting ASC or DESC
$mSortTyp=array("ASC"=>"ASC", "DESC"=>"DESC");

# Master status aktif
$mAktif= array("Y"=>"Active","N"=>"Not Active");
$mUsed = array("Y"=>"Used","N"=>"Not Used");
$mYN   = array("Y"=>"Y","N"=>"N");
$mTF   = array("true"=>"Y","false"=>"N");
$mStatusSipa=array(""=>"","EXPIRED"=>"danger","ALERT"=>"warning");

# Master region
$mRegion = array("HO"=>"HO", "REG-1"=>"Region 1", "REG-2"=>"Region 2", "REG-3"=>"Region 3", "REG-4"=>"Region 4");

# Tipe CAPEX request
$mTipeCapex=array("BOTH"=>"CAPEX & LEASING", "CAPEX"=>"CAPEX", "LEASING"=>"LEASING");

# Master Status Approve
$mStatusAppr=array('' => '','APPROVED' => 'APPROVED', 'NOT APPROVED' => 'NOT APPROVED');

# Master Bulan
$bln = array(1 => "JAN", 2 => "FEB", 3 => "MAR", 4 => "APR", 5 => "MAY", 6 => "JUN", 7 => "JUL", 8 => "AUG", 9 => "SEP", 10 => "OCT", 11 => "NOV", 12 => "DEC");

# Call Master
$mAlert=array("EXPIRED"=>"MERAH", "ALERT"=>"KUNING", ""=>"");
?>