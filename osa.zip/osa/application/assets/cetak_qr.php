<?php
require_once "qr_generator/qrlib.php";
$size=(isset($_GET['s']) AND $_GET['s']!='')?$_GET['s']:8;
$border=0;
QRcode::png($_GET["id"],false, 'L', $size, $border);
?>