<?php
/*
# Auth  : Dyah PP Wardhana (c) DamarTeduh 2018
# Create: 2018-06-13 02:53 AM
# Ket   : Error handling
# Rev   : 

*/
?>

<body style="font-family: arial;"><div style="width: 100%;display: block;text-align: center;position: fixed;top: 25%;"><span style="color: red;font-size: 56px;display: block;-webkit-transform: rotate(-90deg);-moz-transform: rotate(-90deg);-ms-transform:rotate(-90deg);-o-transform: rotate(-90deg);filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=3);">404</span><h1>ERROR</h1><p>Looks like this page does not exist...</p></div></body>