<link rel="stylesheet" type="text/css" href="static/css/pikaday.css" />

<?php
$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
/*
# Auth  : Dyah PP Wardhana (c) DamarTeduh 2018
# Create: 2018-07-28 01:25 AM
# Ket   : Function pilih periode tanggal
# Rev   : 
*/

function sendEmail($mailto,$subject,$msgcontent){
	$mail = new PHPMailer; 
	$mail->IsSMTP();
	$mail->SMTPAuth = false;
	$mail->Host = "mail.nead.danet";
	$mail->SMTPDebug = 2;
	$mail->Port = 25;
	$mail->SetFrom("no-reply@adop.admin","ADOP No-Reply");
	$mail->Subject = $subject;
	$mail->MsgHTML($msgcontent);
	foreach ($mailto as $key => $value) {
		$mail->AddAddress($key);
	}
	$mail->Send();
}

# Compress image
function compress_image($source_url, $destination_url, $quality) {
	$info = getimagesize($source_url);
	if ($info['mime'] == 'image/jpeg') $image = imagecreatefromjpeg($source_url);
	elseif ($info['mime'] == 'image/gif') $image = imagecreatefromgif($source_url);
	elseif ($info['mime'] == 'image/png') $image = imagecreatefrompng($source_url);
	imagejpeg($image, $destination_url, $quality);
	return $destination_url;
}

# 20191105 Input Combo
function cmbInput($name,$class,$id,$value,$master_data,$input_name,$disabled){
	$kode ='<input type="text" name="'.$name.'" class="'.$class.'" id="'.$id.'" list="'.$input_name.'" value="'.$value.'" '.$disabled.'/>';
	$kode.='<datalist id="'.$input_name.'">'."\n";
	foreach ($master_data AS $row) {
		$kode .='<option value="'.key($master_data).'">'.$row.'</option>'."\n";
		next($master_data);
	}
	$kode .='</datalist>'."\n";
	return $kode;
}

function topHeaderDetail($judul,$MenuNew,$otherMenu){
	$kode="<ul class='menu-atas'><li class='judul'><h4>".$judul."</h4></li>";
	if($MenuNew=='true') $kode.="<li><button type='button' id='new' title='Buat baru'><i class='fa fa-file'></i></button></li> ";
	$kode.="<li><button type='button' id='refresh' title='Refresh'><i class='fa fa-refresh'></i></button></li>";
	if(isset($otherMenu)) $kode.="<li>".$otherMenu."</li>";
	$kode.="</ul>";
	return $kode;
}

function topHeader($judul,$MenuNew){
	$kode="<ul class='menu-atas'>
		<li class='judul'><h4>".$judul."</h4></li>";
	if($MenuNew=='true') $kode.="<li><button type='button' id='new' title='Buat baru'><i class='fa fa-file'></i></button></li> ";
	$kode.="<li><button type='button' id='refresh' title='Refresh'><i class='fa fa-refresh'></i></button></li>
		<li class='pembagi'></li>
		<li><button type='button' id='filter'><i class='fa fa-filter'></i></button></li>
		<li><button type='button' id='sort'><i class='fa fa-sort-amount-asc'></i></button></li>
		<li><button type='button' id='search'><i class='fa fa-search'></i></button></li>
	</ul>";
	$kode.="<script type='text/javascript'>
		$(document).ready(function(){ $('#refresh').click(function(){ window.location.reload(); }); $('#search').click(function(){ $('#mySearch').toggle(); }); $('#filter').click(function(){ $('#myFilter').toggle(); }); $('#sort').click(function(){ $('#mySort').toggle(); }); });</script>";
	return $kode;
}

# Hanya di pakai di VMI Project
function cmbMinggu($name,$id,$cls,$ref,$set,$start_week,$end_week){
	$kode='<select name="'.$name.'" class="'.$cls.'" id="'.$id.'" '.$set.' >'."\n";
	for($i=$start_week;$i<=$end_week;$i++){
		$kode .='<option value="'.$i.'"';
		if(trim($i)==trim($ref)) {
			  $kode .=' selected';
			}
		$kode .='>'.$i.'</option>'."\n";
		}
	$kode .='</select>'."\n";
	return $kode;
}

function alertMsg($comment){
	$kode = "<div style='margin-top: 20px;padding: 20px;border:dotted 1px gray;color: #f44336;'><b>ALERT!</b> ".$comment."</div>";
	return $kode;
}

function dataEmpty($result, $comment){
	if(mysqli_num_rows($result)==0){
		$kode = "<div style='margin-top: 20px;padding: 20px;border:dotted 1px gray;color: #f44336;'><b>ALERT!</b> ".$comment."</div>";
	}
	else {
		$kode = "";
	}
		return $kode;
}

function scrollBawah(){
	$kode  = '<button id="scrollToBottom" OnClick="scrollToBottom();"><i class="fa fa-arrow-circle-down"></i></button>';
	$kode .= '<script type="text/javascript">function scrollToBottom(){var elmnt = document.getElementById("submitProposed");
	elmnt.scrollIntoView();}</script>';
	return $kode;
}

function formClosed($reference){
	$kode  = '<a class="btnClosed" href="'.$reference.'"><i class="fa fa-times"></i></a>';
	return $kode;
}

/*function tglPicker($name,$class,$id,$tglSelect,$enab){
	$kode ='<input type="text" class="'.$class.'" name="'.$name.'" id="'.$id.'" value="'.$tglSelect.'" '.$enab.' readonly>';
	$kode.= '<script type="text/javascript">$(document).ready(function(){$("#'.$id.'").datepicker({
		dateFormat : "yy-mm-dd",firstDay: 1,changeMonth : true,changeYear : true});});</script>';
	return $kode;
}*/

function tglPicker($name,$class,$id,$value,$other){
	$kode ='<input type="text" name="'.$name.'" class="'.$class.'" id="'.$id.'" value="'.$value.'" readonly '.$other.'>';
	$kode .= '<script type="text/javascript">var startDate,	updateStartDate = function() {startPicker.setStartRange(startDate);}, startPicker = new Pikaday({field: document.getElementById("'.$id.'"), format: "YYYY-MM-DD", onSelect: function(){startDate = this.getDate();updateStartDate();} }), _startDate = startPicker.getDate(); if (_startDate){startDate = _startDate;updateStartDate();}</script>';
	return $kode;
}

function cmbBoxWarna($name,$class,$id,$ref,$dataCat,$other){
	$kode='<select style="background-color: '.$ref.'" class="'.$class.'" name="'.$name.'" id="'.$id.'" '.$other.'>'."\n";
	foreach ($dataCat AS $row) {
		$kode .='<option style="background-color: '.key($dataCat).'" value="'.key($dataCat).'"';
		if(key($dataCat)==$ref) {
        	$kode .=' selected';
        }
		$kode .='>'.$row.'</option>'."\n";
		next($dataCat);
		}
		$kode .='</select>'."\n";
		return $kode;
}

function cmbBox($name,$class,$id,$ref,$dataCat,$other){
	$kode='<select class="'.$class.'" name="'.$name.'" id="'.$id.'" '.$other.'>'."\n";
	foreach ($dataCat AS $row) {
		$kode .='<option value="'.key($dataCat).'"';
		if(key($dataCat)==$ref) {
        	$kode .=' selected';
        }
		$kode .='>'.$row.'</option>'."\n";
		next($dataCat);
		}
		$kode .='</select>'."\n";
		return $kode;
}

// function checkbox JWK
function checkBox($name,$class,$id,$ref,$dataCat,$other){
	// $kode='<div id="checkboxJWK"><form class="'.$class.'" name="'.$name.'" id="'.$id.'" '.$other.' method="POST">';
	$kode = "<div class='card box'>";
	$kode .= "<h2>Filter by Day JWK</h2>";
	
	if (is_array($dataCat) || is_object($dataCat)){
		foreach ($dataCat AS $row) {
			$kode .='<input type="checkbox" name="checklist[]" value="'.$row.'"> '.$row.'<br />';
		}
	}
		// $kode .= '<input type="submit" />';
		// $kode .='</form></div>';
	$kode .= "</div>";
	return $kode;
}

// function checkbox Supplier
function checkBoxSupplier($name,$class,$id,$ref,$dataCat,$other){
	// $kode='<div id="checkboxJWK"><form class="'.$class.'" name="'.$name.'" id="'.$id.'" '.$other.' method="POST">';
	$kode = "<h2>SPD Multiplication by Depo</h2>";
	$kode .= "<div id=cmbSupplier 'width: 100%; display: table;'>";
	if (is_array($dataCat) || is_object($dataCat)){
		foreach ($dataCat AS $row) {
			$kode .= "<div style='display: table-row'>";
			$kode .='<div style="width: 280px; display: table-cell;"><input type="checkbox" class="inputSupplier" name="checklistSupplier[]" value="'.$row.'"> '.$row.'</div>';
			$kode .="<div style='display: table-cell;'>
                        <input type='number' min='0' class='inputSPD' style='max-width: 100px' name='jumlahSPD[]' placeholder='SPD...' >
                        <input type='number' min='0' class='inputSPD' style='max-width: 100px' name='multiplierStockdate[]' placeholder='0.5' value='0.5' step='0.01' disabled>
                        </div>";
			$kode .= "</div><br>";
		}
	}
	$kode .= "</div>";
	return $kode;
}

// function checkbox OG Minimal
function checkBoxOGMinimal($name,$class,$id,$ref,$dataCat,$other){
	// $kode='<div id="checkboxJWK"><form class="'.$class.'" name="'.$name.'" id="'.$id.'" '.$other.' method="POST">';
	$kode = "<h2>OG Minimal by Depo</h2>";
	$kode .= "<div id=cmbOGMinimal 'width: 100%; display: table;'>";
	if (is_array($dataCat) || is_object($dataCat)){
		foreach ($dataCat AS $row) {
			$kode .= "<div style='display: table-row'>";
			$kode .='<div style="width: 280px; display: table-cell;"><input type="checkbox" name="checklistSupplierOG[]" value="'.$row.'"> '.$row.'</div>';
			$kode .="<div style='display: table-cell;'><input type='number' min='0' name='jumlahOGMinimal[]' placeholder='OG Minimal...' ></div>";
			$kode .= "</div>";
		}
	}
	$kode .= "</div>";
	return $kode;
}

// function checkbox brand
function checkBoxBrand(){
	$kode = "<div>";
	$kode .= "<h2>Brand</h2>";
	$kode .='<input type="checkbox" name="checklistBrand[]" value="AQUA"> AQUA<br />';
	$kode .='<input type="checkbox" name="checklistBrand[]" value="VIT"> VIT<br />';
	$kode .= "</div>";
	return $kode;
}

function stockdateSpdMultiplier(){
    $kode = "<div>";
    $kode .= "<h2>Stockdate SPD Multiplier</h2>";
    $kode .='<input type="number" placeholder="0.5" name="spdMultiplier" step="0.01"> <br />';
    $kode .= "</div>";
    return $kode;
}

// function checkbox Custom SPD
function customSPD(){
	$kode = "<div>";
	$kode .= "<h2>Custom SPD</h2>";
	$kode .= '<input type="number" placeholder="0" name="customSPD" step="0.01"> <br/>';
	$kode .= "</div>";
	return $kode;
}

// function mode PKM or MaxStock
function radioMode(){
	$kode = "<div>";
	$kode .= "<h2>Mode</h2>";
	$kode .='<input type="radio" name="mode" id="radioMaxStock" value="maxStock"> Max Stock<br />';
	$kode .='<input type="radio" name="mode" id="radioPkm" value="PKM"> PKM<br />';
	$kode .= "</div>";
	return $kode;
}

// function mode SPD or Forecast
function radioModeSpd(){
	$kode = "<div class='card box'>";
	$kode .= "<h2>Mode SPD</h2>";
	$kode .='<input type="radio" name="modeSpd" id="radioSpd" value="typeSpd"> Average<br />';
	$kode .='<input type="radio" name="modeSpd" id="radioForecast" value="typeForecast"> Forecast<br />';
	$kode .= "</div>";
	return $kode;
}

function cmbTahun($name,$id,$cls,$ref,$set,$start){
  $kode='<select name="'.$name.'" class="'.$cls.'" id="'.$id.'" '.$set.' >'."\n";
  for($i = $start; $i < date("Y")+1; $i++){
    $kode .='<option value="'.$i.'"';
    if(trim($i)==trim($ref)) {
          $kode .=' selected';
        }
    $kode .='>'.$i.'</option>'."\n";
    }
  $kode .='</select>'."\n";
  return $kode;
}

function cmbBulan($name,$id,$cls,$ref,$set){
  $bln = array(1 => "Jan", 2 => "Feb", 3 => "Mar", 4 => "Apr", 5 => "May", 6 => "Jun", 7 => "Jul", 8 => "Aug", 9 => "Sep", 10 => "Oct", 11 => "Nov", 12 => "Dec");
  $kode='<select name="'.$name.'" class="'.$cls.'" id="'.$id.'" '.$set.' >'."\n";
  for($i=1; $i<13; $i++){
    $kode .='<option value="'.$i.'"';
    if(trim($i)==trim($ref)) {
          $kode .=' selected';
        }
    $kode .='>'.$bln[$i].'</option>'."\n";
    }
  $kode .='</select>'."\n";
  return $kode;
}

# 20180808
function getPreValue($sessionName,$defaultValue){
	$_SESSION[$sessionName]= isset($_SESSION[$sessionName])?$_SESSION[$sessionName]:$defaultValue;
	$_SESSION[$sessionName]= isset($_POST[$sessionName])?$_POST[$sessionName]:$_SESSION[$sessionName];
	return $_SESSION[$sessionName];
}

function pageHeader($judul, $otherMenu){
	$kode = '<div class="damarheader"><form method="POST" id="formPageHeader"><h4>'.$judul.' | <small>';
	$kode.= (isset($otherMenu) AND $otherMenu!='')?$otherMenu:'';
	$kode.= '</small></h4></form></div>';
	return $kode;
}

function tableHeader($judul, $otherMenu){
	$kode ='<div class="damarheader"><form method="POST" id="formPageHeader">'.$judul.' | <small><a href="#" id="cmdXls"><i class="fa fa-download"></i> Excel</a> </small>';
	$kode .= (isset($otherMenu) AND $otherMenu!='')?$otherMenu:'';
	$kode .= ' </form></div>';
	$kode .= '<script type="text/javascript">$(document).ready(function(){ $("#cmdXls").click(function(){export_table_to_excel("myTable");}); });</script>';
	return $kode;
}

function cariKey(){
	$kode = '<input type="text" id="cmdSearch" placeholder="&#xf002; CARI..." style="font-family:Arial, FontAwesome" onkeyup="cari(this);">';
	$kode .= '<script type="text/javascript">function cari(e){ var that = e.value; var elems = document.getElementsByClassName("cari");	for (var i = 0; i < elems.length; ++i) { if(elems[i].innerHTML.toLowerCase().indexOf(that.toLowerCase()) == -1){ elems[i].style.display = "none"; }	else { elems[i].style.display = "";	} } }</script>';
	return $kode;
}

function getJenisMinggu($con, $fieldDate) {
	$str = "SELECT w.minggu FROM tbl_weekconv w WHERE w.tanggal = '".$fieldDate."'";
	$result = mysqli_query($con, $str);
	while($row=mysqli_fetch_assoc($result)) {
		$mJenisMinggu[$row['minggu']] = $row['minggu'];
	}
	foreach ($mJenisMinggu as $key => $value) {
		$nomorMinggu = $value;
	}

	// sengaja dibalik logika genap ganjil untuk keperluan load data nanti
	if ($nomorMinggu % 2 == 0) {
		$jenisMinggu = 'GANJIL';
	} else {
		$jenisMinggu = 'GENAP';
	}
	return $jenisMinggu;
}

function perkalianSpd() {
	$kode = '<input type="text" name="cmdPerkalian" placeholder="&#xf002; Berapa x SPD" style="font-family:Arial, FontAwesome" onkeyup="hitung(this);">';
	return $kode;
}

function newUpload($id,$btn,$judul,$action){
	$kode = '<div id="'.$id.'"><div id="fgHeader"><i class="fa fa-pencil"></i> '.$judul.'</div><div id="frmInner"><form action="'.$action.'" method="POST" name="'.$id.'" enctype="multipart/form-data"><div class="dt-form-group"><label>Select File (csv)</label><input type="file" name="cFile" required></div><div class="dt-form-group"><label></label><button type="submit" name="submit" >Submit</button> <button id="cmdCancel">Cancel</button></div></form></div></div><div id="bgFrm01"></div>';
	$kode .= '<script type="text/javascript">$(document).ready(function(){$("#'.$btn.'").click(function(){ fg_popup_form("'.$id.'","frmInner","bgFrm01","100"); }); $("#cmdCancel").click(function(){ fg_hideform("'.$id.'","bgFrm01"); }); }); </script>';
	return $kode;
}

// Handle hari Forecast
function hariForecast($dayJWK, $incr) {
	if ((((int)$dayJWK + (int)$incr) % 6) == '1') {
		return 'SENIN';
	}
	else if ((((int)$dayJWK + (int)$incr) % 6) == '2') {
		return 'SELASA';
	}
	else if ((((int)$dayJWK + (int)$incr) % 6) == '3') {
		return 'RABU';
	}
	else if ((((int)$dayJWK + (int)$incr) % 6) == '4') {
		return 'KAMIS';
	}
	else if ((((int)$dayJWK + (int)$incr) % 6) == '5') {
		return 'JUMAT';
	}
	else if ((((int)$dayJWK + (int)$incr) % 6) == '0') {
		return 'SABTU';
	}
}

// function uploadFile($judul,$action){
// 	$kode = '<div id="fgFrm01"><div id="fgHeader"><i class="fa fa-pencil"></i> '.$judul.'</div><div id="frmInner"><form action="'.$action.'" method="POST" enctype="multipart/form-data"><div class="dt-form-group"><label>Select File (csv)</label><input type="file" name="cFile" required></div><div class="dt-form-group"><label></label><button type="submit" name="submit" >Submit</button> <button id="cmdCancel">Cancel</button></div></form></div></div><div id="bgFrm01"></div>';
// 	$kode .= '<script type="text/javascript">$(document).ready(function(){$("#cmdUpload1").click(function(){	fg_popup_form("fgFrm01","frmInner","bgFrm01","100"); }); $("#cmdCancel").click(function(){ fg_hideform("fgFrm01","bgFrm01"); }); }); </script>';
// 	return $kode;
// }

// function uploadFile2($judul2,$action2){
// 	$kode = '<div id="fgFrm03"><div id="fgHeader"><i class="fa fa-pencil"></i> '.$judul2.'</div><div id="frmInner"><form action="'.$action2.'" method="POST" enctype="multipart/form-data"><div class="dt-form-group"><label>Select File (csv)</label><input type="file" name="cFile" required></div><div class="dt-form-group"><label></label><button type="submit" name="submit" >Submit</button> <button id="cmdCancel2">Cancel</button></div></form></div></div><div id="bgFrm03"></div>';
// 	$kode .= '<script type="text/javascript">$(document).ready(function(){$("#cmdUpload2").click(function(){	fg_popup_form("fgFrm03","frmInner","bgFrm03","100"); }); $("#cmdCancel2").click(function(){ fg_hideform("fgFrm03","bgFrm03"); }); }); </script>';
// 	return $kode;
// }


function setPeriode($tglStart,$tglEnd){
	$kode ='<input class="taggal" type="text" name="tglStart" id="start" value="'.$tglStart.'" readonly> to <input class="taggal" type="text" name="tglEnd" id="end" value="'.$tglEnd.'" readonly>';
	$kode .= '<script type="text/javascript">var startDate, endDate, updateStartDate = function(){startPicker.setStartRange(startDate); endPicker.setStartRange(startDate); endPicker.setMinDate(startDate); }, updateEndDate = function(){ startPicker.setEndRange(endDate); startPicker.setMaxDate(endDate);	endPicker.setEndRange(endDate);	}, startPicker = new Pikaday({field: document.getElementById("start"), format: "YYYY-MM-DD", maxDate: new Date(2020, 12, 31), onSelect: function(){	startDate = this.getDate();	updateStartDate(); }}), endPicker = new Pikaday({ field: document.getElementById("end"), format: "YYYY-MM-DD", maxDate: new Date(2020, 12, 31),	onSelect: function() { 	endDate = this.getDate(); updateEndDate(); }}), _startDate = startPicker.getDate(),	_endDate = endPicker.getDate(); if (_startDate){startDate = _startDate; updateStartDate();} if (_endDate){ endDate = _endDate; updateEndDate();}</script>';
	return $kode;
}

// function deleteToko() {
// 	$kode = '<form><input type="text" name="kodeToko" placeholder="Kode Toko..."><button name="submitKode" type="submit">Delete Toko</form>';
// 	return $kode;
// }

/*function pagging($url, $count_row, $limit, $offset) {
	echo '<div class="pagination" style="margin-top: 20px">';
	echo '<ul>';
	$page = $offset+1;
	// Jumlah data per halamannya
	// Untuk menentukan dari data ke berapa yang akan ditampilkan pada tabel yang ada di database
	// $limit_start = ($page - 1) * $limit;
	if($page == 1){ // Jika page adalah page ke 1, maka disable link PREV
    	echo '<li class="disabled"><a href="#">First</a></li>';
    	echo '<li class="disabled"><a href="#">&laquo;</a></li>';
  	}
	else{ 
		// Jika page bukan page ke 1
    	$link_prev = ($page > 1)? $page - 1 : 1;
    	echo '<li><a href="'.BASE_URL.$url.'/1">First</a></li>';
    	echo '<li><a href="'.BASE_URL.$url.'/'.$link_prev.'">&laquo;</a></li>';
	}
	// LINK NUMBER
	$jumlah_page = ceil($count_row / $limit); // Hitung jumlah halamannya
	$jumlah_number = 3; // Tentukan jumlah link number sebelum dan sesudah page yang aktif
	$start_number = ($page > $jumlah_number)? $page - $jumlah_number : 1; // Untuk awal link number
	$end_number = ($page < ($jumlah_page - $jumlah_number))? $page + $jumlah_number : $jumlah_page; 
        
	// Untuk akhir link number            
	for($i = $start_number; $i <= $end_number; $i++){
		$link_active = ($page == $i)? ' class="active"' : '';
        echo '<li'.$link_active.'><a href="'.BASE_URL.$url.'/'.$i.'">'.$i.'</a></li>';
	}
            
	// <!-- LINK NEXT AND LAST -->
	// Jika page sama dengan jumlah page, maka disable link NEXT nya
	// Artinya page tersebut adalah page terakhir 
	if($page == $jumlah_page){ // Jika page terakhir
    	echo '<li class="disabled"><a href="#">&raquo;</a></li>';
    	echo '<li class="disabled"><a href="#">Last</a></li>';
	}
	else{ 
		// Jika Bukan page terakhir
    	$link_next = ($page < $jumlah_page)? $page + 1 : $jumlah_page;
    	echo '<li><a href="'.BASE_URL.$url.'/'.$link_next.'">&raquo;</a></li>';
    	echo '<li><a href="'.BASE_URL.$url.'/'.$jumlah_page.'">Last</a></li>';
	}
	echo "</ul>";
}*/
?>

<!-- Expport to Excel -->
<script type="text/javascript" src="static/js/xlsx.core.min.js"></script>
<script type="text/javascript" src="static/js/Blob.js"></script>
<script type="text/javascript" src="static/js/FileSaver.js"></script>
<script type="text/javascript" src="static/js/Export2Excel.js"></script>
<style type="text/css">
	@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700;900&family=Roboto:wght@100;300;400;500;700;900&display=swap');
	h2 {
		font-family: 'Roboto', sans-serif;
		font-weight: 900;
	}

	br {
		font-family: 'Roboto', sans-serif;
	}
	
	.damarheader { margin-bottom: 30px; }
	.damarheader > form {vertical-align: top; }
	.damarheader > form input[type=text], .damarheader > form select, .damarheader > form input[type=text].taggal {
		border: 1px solid #DBDADA;
		padding: 5px;
		margin-right: 5px;
		height: 25px;
		vertical-align: top;
		font-size: 12px;
	}
	.damarheader > form input[type=text].taggal { width: 100px; }
	.damarheader > form input[type=submit] {
		padding: 5px; 
		border: 1px solid #DBDADA;
		height: 25px;
	}
	.damarheader > form input[readonly] { background-color: #F2F1F1; }
	.damarheader > form a { 
		margin: 0 10px;
		padding: 0 5px;
		text-decoration: none;
	}
	div.damarheader > form h4 button {
		border-radius: 3px;
		border: 1px solid gray;
		height: 30px;
		width: 30px;
	}
	
	/*.damarheader > small {margin: 0 20px; padding: 0 10px; font-style: 10px;}*/
	#cmdXls, #cmdNew { margin: 0 10px; }
/* return to bottom */
	button#scrollToBottom {
		border-style: none;
		opacity: 0.6;
		background-color: transparent;
		color: #000;
		font-size: 30px;
		position: fixed;
		right: 10px;
	}
	a.btnClosed {
		/*border-style: none;*/
		border: 1px solid red;
		border-radius: 3px;
		padding: 0 6px;
		opacity: 0.6;
		background-color: transparent;
		color: red;
		font-size: 18px;
		position: fixed;
		right: 15px;	
		z-index: 9;
	}
	a.btnClosed:hover { 
		border: 1px solid red; 
		color: white; 
		background-color: red 
	}

/* Menu filter, search, sort */
ul.menu-atas {
	font-family: Segoe UI,Frutiger,Frutiger Linotype,Dejavu Sans,Helvetica Neue,Arial,sans-serif;
	margin-top: 10px;
	margin-left: 0px;
	list-style: none;
	padding-left: 0px;
	position: relative;
}
ul.menu-atas li a { 
	text-decoration: none;
	color: black;
	vertical-align: middle;
}
ul.menu-atas li button { margin-right: 5px; }
ul.menu-atas li { display: inline-block; }
ul.menu-atas li.pembagi { padding: 0 10px; }
ul.menu-atas button:hover, div#mySearch button:hover, ul.menu-atas li a:hover { opacity: 0.6; }
ul.menu-atas button, div#mySearch button {
	border-radius: 3px;
	border: 1px solid gray;
	height: 30px;
	width: 30px;
}
ul.menu-atas li.menu-kanan { float: right; }
ul.menu-atas li.judul { margin-right: 30px; }
div#myFilter label, div#mySort label, div#mySearch label { width: 150px; }
div#myFilter select, div#mySort select, div#mySearch input { border: none; }
div#myFilter, div#mySort, div#mySearch { 
	border-bottom: 1px solid gray; 
	padding-bottom: 5px; 
	margin-bottom: 10px;
}
div#myFilter, div#mySort { display: none; }
div#mySearch input { width: 300px; background-color: #f6f6f6; padding: 5px; height: 30px; }

ul.menu-atas li select, ul.menu-atas li input[type=text] {
	border-radius: 3px;
	border: 1px solid gray;
	height: 30px;
	padding-left: 5px
}

.damarheader > form > div > input {
	display: inline-block;
}

#container {
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  justify-content: space-between;
  align-items: auto;
  align-content: space-around;
  border-style: solid;
  border-color: #2989D8;
  margin-top: 10px;
  margin-bottom: 10px;
}

.container-brand {
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  justify-content: space-between;
  align-items: auto;
  align-content: space-around;
}

.box {
  flex: 1 0 auto;
  margin: 10px;
}

#container .card {
  padding: 20px;
  border-style: dashed;
  border-color: #2989D8;
}

/* #cmbSupplier div {
	display: table-column;
} */
</style>

<!-- Date Picker -->
<!-- <script src="static/js/jquery-ui.js"></script> -->
<!-- <link rel="stylesheet" href="static/css/jquery-ui.css"> -->

<script src="static/js/moment.min.js"></script>
<script src="static/js/pikaday.js"></script>