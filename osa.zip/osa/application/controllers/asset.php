<?php
/*
# Project : AMEX V3.0 (YW1leDMwZGFtYXJ0ZWR1aDIwMjA=)
# Auth    : damarteduh@gmail.com©2020, BWG El Royal, 2020-03-04 06:34 AM
# Rev     : 
	20200426 Home, Rework ke template BARU - DWR
*/

switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navside= 'navside.php';
		$navtop = 'navtop.php';
		require 'master.php';
		break;

	case 'speccap':	# 20200506 02:18 PM, Home
	case 'send':	# 20200427 06:07 AM, Home
	case 'actual':	# 20200318 11:16 AM, Home
	case 'history':	# 20200313 05:16 AM, Home
	case 'child1':	# 20200313 05:16 AM, Home
	case 'child0':	# 20200128 07:40 AM, Home
		require 'master.php';
		break;
}
?>