<?php
switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navtop = 'navtop.php';
		require 'master.php';
		break;
    case 'download_spd_176':
        require 'master.php';
        break;
}
?>