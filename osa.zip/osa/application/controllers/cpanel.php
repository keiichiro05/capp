<?php
/*
# Project : AMEX V3.0 (YW1leDMwZGFtYXJ0ZWR1aDIwMjA=)
# Auth    : damarteduh@gmail.com©2020, BWG El Royal, 2020-03-04 06:34 AM
# Rev     : 
	20200423 Home, Rework ke template BARU - DWR
*/

switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navtop = 'navtop.php';
		require 'master.php';
		break;

	case 'email':		# 20200427 15:12, Home BOGOR
	case 'klasifikasi':	# 20200513 16:57, Home BOGOR
	case 'plant':		# 20200423 21:59, Home BOGOR
	case 'cariuser':	# 20200423 18:01, Home BOGOR
	case 'akses':		# 20200423 11:24, Home BOGOR
	case 'userdetail':	# 20200331 12:45, Home BOGOR
	case 'user':		# 20200331 12:45, Home BOGOR
	case 'welcome':		# 20200331 12:45, Home BOGOR
	case 'send':		# 20200128 07:40, Home
		require 'master.php';
		break;
}
?>