<?php
switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navtop = 'navtop.php';
		require 'master.php';
		break;
    case 'send':
        require 'master.php';
        break;
    case 'downloadTemplate':
        require 'master.php';
        break;
}
?>