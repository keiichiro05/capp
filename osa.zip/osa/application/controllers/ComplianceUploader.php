<?php

class ComplianceUploader
{
    protected $crude_data = [];
    public function csv_reader($file_location){
        try{
            if(($opened_file = fopen($file_location, "r"))!==FALSE){
                while(($csv_stream = fgetcsv($opened_file, 25000, ","))!== FALSE){
                    $this->crude_data[] = $csv_stream;
                }
                fclose($opened_file);
            }

        }catch (Error $e){
            throw $e;
        }
    }

    public function verify(array $column_verificator){
        if(count($this->crude_data)==0){
            throw new Error("should read csv first!");
        }

        $first_element = $this->crude_data[0];
        if(count($first_element) != count($column_verificator)){
            throw new Error("column count not same");
        }

        for($i=0;$i<count($column_verificator);$i++){
            if($column_verificator[$i] != $first_element[$i]){
                throw new Error("column ".$column_verificator[$i]." not consist in csv!");
            }
        }
    }

    public function download_template($col_to_insert){

    }
    public function get_query($table_name, $col_to_insert){
        if(count($this->crude_data)<=1){
            throw new Error("should read csv first! and has at least 1 data");
        }

        $query = "REPLACE INTO `".$table_name."` (".$col_to_insert.") VALUES ";
        $skip = true;
        foreach ($this->crude_data as $row_data){
            if(!$skip){
                $tmp = "(";
                for($i=0; $i<count($row_data); $i++){
                    $tmp .= "'".str_replace("'","", $row_data[$i])."'";
                    if($i<count($row_data)-1){
                        $tmp .= ",";
                    }
                }
                $tmp .= "),";
                $query .= $tmp;
            }else{
                $skip = false;
            }
        }
        $query = substr_replace($query, ";", -1);

        return $query;
    }

    public function execute_sql(mysqli $mysql, string $query){
        $result = mysqli_query($mysql, $query);
        //var_dump($result);
        if(!$result){
            echo "something error just happened into sql query <br>" . $query . "<br><br>";
            var_dump(mysqli_error($mysql));
            echo "<br>===================================================<br>";
            //throw new Exception("something wrong happened with query : ".mysqli_error($mysql));
        }
        return mysqli_affected_rows($mysql);
    }
}