<?php
/*
# Prject: billingtracker
# User  : Jefry (phoa.permana@danone.com)
# Auth  : DamarTeduh©2020
# Create: BOGOR | 2020-05-13 13:27
*/
switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navtop = 'navtop.php';
		require 'master.php';
		break;
	case 'data_generator':
		$navtop = 'navtop.php';
		require 'master.php';
		break;

}
?>