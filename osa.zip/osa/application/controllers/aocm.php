<?php
/*
# Project : AMEX V3.0 (YW1leDMwZGFtYXJ0ZWR1aDIwMjA=)
# Auth    : damarteduh@gmail.com©2020, BWG El Royal, 2020-03-04 06:34 AM
# Rev     : 
*/

switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navside= 'navside.php';
		$navtop = 'navtop.php';
		require 'master.php';
		break;

	case 'listvisit':	# 20200128 07:40 AM, Home
		$navtop = 'navtop.php';
		require 'master.php';
		break;
}
?>