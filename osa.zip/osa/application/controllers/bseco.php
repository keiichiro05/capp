<?php
/*
# Prject: billingtracker
# User  : Jefry (phoa.permana@danone.com)
# Auth  : DamarTeduh©2020
# Create: BOGOR | 2020-05-13 13:27
*/
switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
	case 'storestatus':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navside= 'navside.php';
		$navtop = 'navtop.php';
		require 'master.php';
		break;
	case 'send':
	require 'master.php';
		break;
	case 'sendMD':
		require 'master.php';
		break;
	case 'mdstatus':
		$navtop = 'navtop.php';
		$navside = 'navside.php';
		require 'master.php';
		break;
	case 'mdlog':
		$navtop = 'navtop.php';
		$navside = 'navside.php';
		require 'master.php';
		break;
	case 'storelog':
		$navtop = 'navtop.php';
		$navside = 'navside.php';
		require 'master.php';
		break;	
	case 'mdiod':
		$navtop = 'navtop.php';
		$navside = 'navside.php';
		require 'master.php';
		break;	
}
?>