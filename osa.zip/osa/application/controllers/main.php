<?php
/*
# Project : eVisitor
# Auth    : damarteduh@gmail.com©2020, 
# Rev     : 
	KOPI TUGOH BOGOR, 2020-01-25 10:37 AM
*/
switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navtop = 'navtop.php';
		require 'master.php';
		break;
}
?>