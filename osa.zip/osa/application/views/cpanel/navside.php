<?php 
/* ============================================
 * Project : SCDIGI v1.0
 * Auth    : DamarTeduh©2018 2019-05-30 16:07
 * Rev     : HOME - 
 * 	20200420 Home, Rework ke template BARU - DWR
 * ============================================
 */
?>

<style>
	.sidenav-cpanel {
	  height: 100%;
	  width: 250px;
	  position: fixed;
	  z-index: 1;
	  top: 0;
	  left: 0;
	  background-color: #111;
	  overflow-x: hidden;
	  font-family: Segoe UI,Frutiger,Frutiger Linotype,Dejavu Sans,Helvetica Neue,Arial,sans-serif;
	  margin-top: 50px;
	}
	.sidenav-cpanel h3 {
	  color: yellow;
	  margin-left: 6px;
	}
	.sidenav-cpanel a, .sidenav-cpanel li {
		font-size: 13px;
	}
	.sidenav-cpanel a {
	  padding: 6px 8px 6px 16px;
	  text-decoration: none;
	  color: #818181;
	  display: block;
	}
	.sidenav-cpanel a:hover { color: #f1f1f1; }
	.sidenav-cpanel a.judul {
	  color: yellow;
	}
	#main {
    	transition: margin-left .5s;
    	margin-left: 280px;
	}

	/* 
	 * Treeview menu
	 * ====================================================
	 */

	/* Remove default bullets */
	ul, #myUL {
	  list-style-type: none;
	  color: #818181;
	  margin: 0;
	  padding: 0;
	}
	#myUL li { 
		padding: 6px 0px 6px 16px;
	}
	#myUL li.sub-menu {	padding: 0 6px; }

	/* Style the caret/arrow */
	.caret-custome {
	  cursor: pointer; 
	  user-select: none; /* Prevent text selection */
	  color: #818181;
	}

	/* Create the caret/arrow with a unicode, and style it */
	.caret-custome::after {
	  font-size: 10px;
	  content: "\25B6";
	  color: yellow;
	  display: inline-block;
	  margin-right: 6px;
	  padding-left: 6px;
	}

	/* Rotate the caret/arrow icon when clicked on (using JavaScript) */
	.caret-custome-down::after {
	  transform: rotate(90deg); 
	  padding-right: 6px;
	}
	.nested { display: none; } /* Hide the nested list */
	.active { display: block; } /* Show the nested list when the user clicks on the caret/arrow (with JavaScript) */
	.sidenav-cpanel a i, #myUL li i { padding-right: 10px } /* General Setup */
	.dt-footer {
		font-size:10px;
		color:gray;
		position:absolute;
		right:0;
		bottom:0;
		left:0;
		padding:0.5rem;
		/*text-align:right;*/
	}
	@media screen and (max-height: 450px) {
	  .sidenav-cpanel {padding-top: 15px;}
	  .sidenav-cpanel a {font-size: 18px;}
	}
</style>

<div class="sidenav-cpanel">
	<h3 class="cpanel"> Control Panel</h3>
	<hr>
	<a href="cpanel?ac=welcome" target="mainFrame"><i class="fa fa-info"></i>Welcome</a>
	<!-- <a href="control?action=user" target="main_page"><i class="fa fa-user"></i>User Register</a> -->
	<ul id="myUL">
	  	<li><span class="caret-custome"><i class="fa fa-gear"></i>User Management</span>
		    <ul class="nested">
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=user" target="mainFrame"><i class="fa fa-user"></i>User Register</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=akses" target="mainFrame"><i class="fa fa-lock"></i>User Access</a></li>
		    </ul>
		</li>
	</ul>
	<ul id="myUL">
	  	<li><span class="caret-custome"><i class="fa fa-gear"></i>Master Data</span>
		    <ul class="nested">
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=plant" target="mainFrame"><i class="fa fa-file-o"></i>Daftar Plant</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=topik" target="mainFrame"><i class="fa fa-file-o"></i>Daftar Topik</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=kategori" target="mainFrame"><i class="fa fa-file-o"></i>Daftar Kategori</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=klasifikasi" target="mainFrame"><i class="fa fa-file-o"></i>Daftar Klasifikasi</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=currency" target="mainFrame"><i class="fa fa-file-o"></i>Daftar Currency</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=attch" target="mainFrame"><i class="fa fa-file-o"></i>Daftar Attachment</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=email" target="mainFrame"><i class="fa fa-file-o"></i>Daftar Email Notifikasi</a></li>
		    </ul>
		</li>
	</ul>
	<ul id="myUL">
	  	<li><span class="caret-custome"><i class="fa fa-gear"></i>General Config</span>
		    <ul class="nested">
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=loger" target="mainFrame"><i class="fa fa-file-o"></i>Konfigurasi Logger</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=ecograph" target="mainFrame"><i class="fa fa-file-o"></i>Konfigurasi Ecograph</a></li>
			    <li class="sub-menu" target="main_page"><a href="cpanel?ac=rain" target="mainFrame"><i class="fa fa-file-o"></i>Konfigurasi Sensor Rain</a></li>
		    </ul>
		</li>
	</ul>
  	<!-- <a href="control?action=kpi" target="main_page"><i class="fa fa-list-alt"></i> KPI</a> -->
  	<!-- <a href="control?action=depo" target="main_page"><i class="fa fa-map-marker"></i> Master Location</a> -->
  	<!-- <a href="control?action=prd" target="main_page"><i class="fa fa-barcode"></i> Product</a> -->
    <!-- <a href="control?action=order" target="main_page"><i class="fa fa-folder"></i> Order</a> -->
    <!-- <a href="control?action=reject" target="main_page"><i class="fa fa-folder"></i> Reject</a> -->
	<!-- <a href="control?action=plant" target="main_page"><i class="fa fa-folder"></i> Plant</a> -->
	<div class="dt-footer">ADOP Inovation&copy2019, version: <?php echo APP_VER; ?></div>
</div>

<script type="text/javascript">
	var toggler = document.getElementsByClassName("caret-custome");
	var i;

	for (i = 0; i < toggler.length; i++) {
	  toggler[i].addEventListener("click", function() {
	    this.parentElement.querySelector(".nested").classList.toggle("active");
	    this.classList.toggle("caret-custome-down");
	  });
	}
</script>