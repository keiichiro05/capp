<!-- Login Pop Up -->
<script type='text/javascript' src='static/js/popup.form.js'></script>
<link type="text/css" rel="stylesheet" href="static/css/popup.form.css"/>

<style type="text/css">
	.fa-unlock, .save { color: #18DE2F }
	.save { visibility: hidden; }
	.fa-lock { color: red }
	.delete { color: red; }
</style>

<?php
/*
# Project   : Bluefish
# Auth  	: Dyah PP Wardhana(c)DamarTeduh
# Create 	: 2019-02-27 11:37 AM, Hotel Haris
# Rev   	: 
*/


# Initialisasi -------
include APP_DIR . "config/connection.php";
require APP_DIR . "assets/utility_function.php";
require APP_DIR . "assets/static_param.php";

# Memory page ketika refresh
$_SESSION[APP_NAME]['cpanel']=$controller.'?ac='.$action;

$aksesIcon = array("true"=>"fa fa-unlock", "false"=>"fa fa-lock");

foreach ($mModul as $key => $value){
	$mModule[$key]=$key;
	foreach ($value['Sub'] as $action => $valueact) {
		$mAction[$key][$valueact]=$valueact;
		$jsonModul[$key][$valueact]=$valueact;
	}
}
$MODUL =getPreValue("modul",key($mModule));
$ACTION=getPreValue("action",key($mAction[$MODUL]));
$jsonmModul =json_encode($jsonModul);

$menu ='<form action="cpanel?ac=akses" method="POST">';
$menu.=cmbBox("modul","","iModul",$MODUL,$mModule,"");
$menu.=cmbBox("action","","iAction",$ACTION,$mAction[$MODUL],"");
$menu.='<button type="submit"><i class="fa fa-send"></i></button>';
$menu.='</form>';
echo topHeaderDetail("Previledge Management","true",$menu);
?>

<table class="table-control">
	<thead>
		<tr>
			<th>No</th>
			<th>User</th>
			<th>Create</th>
			<th>Edit</th>
			<th>Delete</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
<?php
	$str="SELECT * FROM db_depo.tbl_akses WHERE modul='{$MODUL}' AND action='{$ACTION}' ORDER BY buat,rubah,hapus";
	$result = mysqli_query($con,$str);
	while($row = mysqli_fetch_assoc($result)){
?>
		<tr class="cari">
			<td><?php echo $row['seq']; ?></td>
			<td><?php echo $row['username']; ?></td>
			<td>
				<?php echo cmbBox("buat","cmbEdit","iBuat".$row['seq'],$row['buat'],$mTF,"hidden"); ?>
				<i class="<?php echo $aksesIcon[$row['buat']]; ?>" id="iconBuat<?php echo $row['seq']; ?>"></i>
			</td>
			<td>
				<?php echo cmbBox("rubah","cmbEdit","iRubah".$row['seq'],$row['rubah'],$mTF,"hidden");	?>
				<i class="<?php echo $aksesIcon[$row['rubah']]; ?>" id="iconRubah<?php echo $row['seq']; ?>"></i>
			</td>
			<td>
				<?php echo cmbBox("hapus","cmbEdit","iHapus".$row['seq'],$row['hapus'],$mTF,"hidden");	?>
				<i class="<?php echo $aksesIcon[$row['hapus']]; ?>" id="iconHapus<?php echo $row['seq']; ?>"></i>
			</td>
			<td>
				<button class="save" id="cmdSimpanAkses<?php echo $row["seq"]; ?>" onclick="cmdSimpanAkses(<?php echo $row["seq"]; ?>);"></button>
				<button class="edit" id="cmdEditAkses<?php echo $row["seq"]; ?>" onclick="cmdEditAkses(<?php echo $row["seq"]; ?>);"></button>
				<button class="delete" onclick="cmdDeleteAkses(<?php echo $row["seq"]; ?>);"></button>
			</td>
		</tr>
<?php } ?>
	</tbody>
</table>

<!-- Pop Up Form -->
<div id='fgFrm01'>
	<div id="fgHeader">Access Registration</div>
		<div id="frmInner">
			<div class='container'>
				<form action="cpanel?ac=send" method="POST">
					<ul id="form-control">
						<li><span>Module</span> 
							<input type="text" name="modul" value="<?php echo $MODUL; ?>" readonly>
						</li>
						<li><span>Action</span> 
							<input type="text" name="action" value="<?php echo $ACTION; ?>" readonly>
						</li>
						<li><span>Username</span> 
							<input list="browsers" type="text" id="username" maxlength="10" name="usr" required oninput="cmdCekUsr();">
							<div id="listuser"></div>
						</li>
						<li><span>Create</span> 
							<?php echo cmbBox("buat","","","false",$mTF,""); ?>
						</li>
						<li><span>Edit</span> 
							<?php echo cmbBox("rubah","","","false",$mTF,""); ?>
						</li>
						<li><span>Delete</span> 
							<?php echo cmbBox("hapus","","","false",$mTF,""); ?>
						</li>
						<li><span></span>
							<button type="submit" name="nKet" id="iKet" value="iprev">Submit</button>
							<button type="button" onclick="fg_hideform('fgFrm01','bgFrm01')">Cancel</button>
						</li>
					</ul>
				</form>
			</div>
		</div>
	</div>
</div> 
<div id='bgFrm01'></div>

<script type="text/javascript">

	$("#new").on("click",function(){
		fg_popup_form('fgFrm01','fgHeader','bgFrm01','40');
	});

	$("#refresh").on("click",function(){ window.location.reload(); });

	function cmdCekUsr(){
		var usr   = document.getElementById("username").value;
		var modul = "<?php echo $MODUL; ?>";
		var action= "<?php echo $ACTION; ?>";
		var dtRow = 'usr='+usr+'&modul='+modul+'&action='+action;
		$.ajax({
			type: "POST",
			url: "cpanel?ac=cariuser",
			data: dtRow,
			cache: false,
			success: function(data){ $("#listuser").html(data); }
		});
	}

	$("#iModul").change(function(){
		var data = <?php echo $jsonmModul; ?>;
		$modul=this.value;
		$("#iAction").empty();
		for (var key in data[$modul]) { 
    		var select = document.getElementById("iAction");
		    var option = document.createElement("option");
		    option.text = key;
		    option.value = key;
		    select.add(option);
		}
	});

	function cmdDeleteAkses(id){
		var r = confirm("ALERT! Confirm delete...");
		if (r == true) {
			$.post("cpanel?ac=send", {seq:id, nKet:"dprev"}, function(result){
				window.location.reload();
			});
		}
	}

	function cmdSimpanAkses(id){
		document.getElementById("iconBuat"+id).style.display="block";
		document.getElementById("iconRubah"+id).style.display="block";
		document.getElementById("iconHapus"+id).style.display="block";
		document.getElementById("iBuat"+id).hidden=true;
		document.getElementById("iRubah"+id).hidden=true;
		document.getElementById("iHapus"+id).hidden=true;
		document.getElementById("cmdSimpanAkses"+id).style.visibility="hidden";
		document.getElementById("cmdEditAkses"+id).style.visibility="visible";
		var buat  = document.getElementById("iBuat"+id).value;
		var rubah = document.getElementById("iRubah"+id).value;
		var hapus = document.getElementById("iHapus"+id).value;
		$.post("cpanel?ac=send", {seq:id, buat:buat, rubah:rubah, hapus:hapus, nKet:"uprev"}, function(result){
			//$("#log").html(data); 
			window.location.reload();
		});
	}

	function cmdEditAkses(id){
		document.getElementById("iconBuat"+id).style.display="none";
		document.getElementById("iconRubah"+id).style.display="none";
		document.getElementById("iconHapus"+id).style.display="none";
		document.getElementById("iBuat"+id).hidden=false;
		document.getElementById("iRubah"+id).hidden=false;
		document.getElementById("iHapus"+id).hidden=false;
		document.getElementById("cmdSimpanAkses"+id).style.visibility="visible";
		document.getElementById("cmdEditAkses"+id).style.visibility="hidden";
	}
</script>
<?php mysqli_close($con); ?>
