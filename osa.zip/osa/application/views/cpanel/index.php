<?php

# Project   : RecPro
# Auth.  	: Dyah PP Wardhana (c) DamarTeduh 2018
# Create 	: 2018-12-27 03:02 PM, Pandaan Plant
# Rev.   	: 0.0 Welcome page

$page=isset($_SESSION[APP_NAME]['cpanel'])?$_SESSION[APP_NAME]['cpanel']:'cpanel?ac=welcome';
?>
<style type="text/css">
#mainFrame { 
	overflow: hidden; 
	border: none; 
	width: 100%; 
}
</style>

<div>
	<div class="side-menu">
		<?php include APP_DIR . "views/cpanel/navside.php"; ?>
	</div>
	<div class="main-frame">
		<iframe id="mainFrame" name="mainFrame" src="<?php echo $page; ?>"></iframe>
	</div>
</div>

<script type='text/javascript'>
	// Agar iframe height adjust auto windows screen size
	var iframe = document.getElementById("mainFrame");
	var t =  $(window).height() - $('body div').height() - 50;
	iframe.style.height = t + 'px';
</script>