<?php
/*
# Project : DWR V1.0 (ZHdzeXN0ZW1AZGFtYXJ0ZWR1aDIwMjA=)
# Auth    : DamarTeduh©2018 2019-03-04 14:03
# Rev     : SENTUL PLANT - Controller u/ c-panel
	20190918 07:11 AM Taman Dayu, Help page
*/

include APP_DIR . "config/connection.php";
include APP_DIR . "/assets/utility_function.php";

// echo alertMsg(" SORRY, ON GOING DEVELOPMENT..."); exit;

# Memory page ketika refresh
$_SESSION[APP_NAME]['cpanel']=$controller.'?ac='.$action;

$str="SELECT COUNT(DISTINCT username) qty FROM tbl_akses";
$result=mysqli_query($con,$str);
$qtyUser=mysqli_fetch_assoc($result);
?>

<style type="text/css">
	div.info > label {
		width: 200px; 
		font-weight: bold;
		display: inline-block;
		margin-bottom: 20px;
	}
	span.info-file { margin-left: 30px; }
</style>

<h3><?php echo APP_NAME." <sup>".APP_VER."</sup>"; ?> - Control Panel</h3>
<hr>
<div class="info"><label>Registered User</label> : <?php echo $qtyUser["qty"]; ?> user</div>
<hr>
<!-- <div class="info">
	<p>
		<lalel><i class="icon-file"></i> Data Sheet</lalel>
		<span class="info-file"><a href="static/files/EcographT-RSG30.pdf" target="_blank"><i class="icon-pdf"></i> EcographT-RSG30.pdf</a></span>
		<span class="info-file"><a href="static/files/EcographT-RSG35.pdf" target="_blank"><i class="icon-pdf"></i> EcographT-RSG35.pdf</a></span>
	</p>
</div>
<hr> -->
<div class="info">
<i class="icon-user"></i> System Administrator : 
<?php
	$str="SELECT username FROM tbl_akses WHERE modul='cpanel'";
	$result=mysqli_query($con,$str);
	while ($row=mysqli_fetch_assoc($result)) {
		echo "<a href='cpanel?ac=userdetail&id=".$row['username']."'>".$row['username']."</a>, ";
	}
?>
</div>
