<?php 
/*
# Project   : Bluefish
# Auth  	: Dyah PP Wardhana(c)DamarTeduh
# Create 	: 2019-02-27 08:15 PM, Hotel Haris
# Rev   	: 
*/

include APP_DIR . "config/connection.php";

$str=sprintf("SELECT tbuser.username FROM (SELECT username FROM tbm_usr WHERE username LIKE '%s%%') tbuser LEFT JOIN (SELECT username FROM tbl_akses WHERE modul='%s' AND `action`='%s') tbakses ON tbuser.username=tbakses.username WHERE tbakses.username IS NULL",$_POST["usr"],$_POST["modul"],$_POST["action"]);
$result=mysqli_query($con,$str);
?>
<datalist id="browsers">
<?php foreach ($result as $row) { ?>
   	<option value="<?php echo $row["username"]; ?>">
<?php } ?>
</datalist>
