<!-- Login Pop Up -->
<script type='text/javascript' src='static/js/popup.form.js'></script>
<link type="text/css" rel="stylesheet" href="static/css/popup.form.css"/>

<!-- Sticky Header Table -->
<link rel="stylesheet" type="text/css" href="static/css/component.css" />
<script src="static/js/jquery.stickyheader.js"></script>
<script src="static/js/jquery.ba-throttle-debounce.min.js"></script>

<?php
/*
# Project : DWSystem
# Auth    : DamarTeduh©2018 2019-03-04 21:03
# Rev     : HOME - Controller u/ c-panel
	20190918 Taman Dayu, lock page setelah refresh
	20200423 Home, Rework ke template BARU - DWR
*/
# Initialisasi -------
include APP_DIR . "config/connection.php";
require APP_DIR . "assets/utility_function.php";
require APP_DIR . "assets/static_param.php";

# Memory page ketika refresh
$_SESSION[APP_NAME]['cpanel']=$controller.'?ac='.$action;

$menu=cariKey();
echo topHeaderDetail("Daftar Plant","false",$menu);
?>

<table class="table-control">
	<thead>
		<tr>
			<th>No</th>
			<th>Region</th>
			<th>Group</th>
			<th>Plant Id</th>
			<th>Description</th>
			<th>Active</th>
		</tr>
	</thead>
	<tbody>
	<?php
		$i=1;
		# Query Plant
		$url = API_SERVER . "plant/site";
		$json= @file_get_contents($url);
		$rows= json_decode($json, TRUE); // echo json_last_error();
		foreach ($rows as $key => $variable) {
	?>
		<tr id="<?php echo $key; ?>" class="cari">
			<td><?php echo $i++; ?></td>
			<td><?php echo $rows[$key]['regional']; ?></td>
			<td><?php echo $rows[$key]['tipe']; ?></td>
			<td><?php echo $rows[$key]['nKode']; ?></td>
			<td><?php echo $rows[$key]['plant_name']; ?></td>
			<td><?php echo $rows[$key]['short_name']; ?></td>
			<!-- <td class="text-center">
				<button class="edit" onclick="cmdEdit(<?php echo $key; ?>);"></button>
			</td> -->
		</tr>
	<?php		
		}
	?>		
	</tbody>
</table>

<!-- Pop Up Form -->
<div id='fgFrm01'>
	<div id="fgHeader">Plant Registration</div>
		<div id="frmInner">
			<div class='container'>
				<form action="cpanel?ac=send" method="POST">
					<input type="hidden" id="iseq" name="seq">
					<ul id="form-control">
						<li><span>Plant Id</span><input type="text" id="iplantid" name="nKode" readonly></li>
						<li><span>Plant Description</span><input type="text" id="iplantdisk" name="szDescription"></li>
						<li><span>Region</span><?php echo cmbBox("region","","iregion","",$mRegion,""); ?></li>
						<li><span>Longitude</span><input type="float" id="iLon" name="lon"></li>
						<li><span>Latitude</span><input type="float" id="iLat" name="lat"></li>
						<li><span>Active</span><?php echo cmbBox("aktif","","iaktif","Y",$mYN,"");	?></li>
						<li><span></span>
							<button type="submit" name="nKet" id="iKet" value="uplant">Submit</button>
							<button type="button" onclick="fg_hideform('fgFrm01','bgFrm01')">Cancel</button>
						</li>
					</ul>
				</form>
			</div>
		</div>
	</div>
</div> 
<div id='bgFrm01'></div>

<!-- Pop Up Form -->
<div id='fgFrm02'>
	<div id="fgHeader">Plant Registration</div>
		<div id="frmInner">
			<div class='container'>
				<form action="cpanel?ac=send" method="POST">
					<ul id="form-control">
						<li><span>Add New Plant</span> <?php echo cmbBox("plant","","","",$mPlant,""); ?></li>
						<li><span></span>
							<button type="submit" name="nKet" value="iplant">Submit</button>
							<button type="button" onclick="fg_hideform('fgFrm02','bgFrm02')">Cancel</button>
						</li>
					</ul>
				</form>
			</div>
		</div>
	</div>
</div> 
<div id='bgFrm02'></div>

<div id="log"></div>

<script type="text/javascript">
	$("#new").on("click",function(){
		fg_popup_form('fgFrm02','fgHeader','bgFrm02','40');
	});

	$("#refresh").on("click",function(){
		window.location.reload();
	});

	function cmdEdit(id){
		var Row=$("#"+id).closest("tr");
		document.getElementById("iseq").value = id;
		document.getElementById("iregion").value = Row.find("td:eq(1)").text();
		document.getElementById("iplantid").value = Row.find("td:eq(2)").text();
		document.getElementById("iplantdisk").value = Row.find("td:eq(3)").text();
		document.getElementById("iaktif").value = Row.find("td:eq(4)").text();
		document.getElementById("iLon").value = Row.find("td:eq(5)").text();
		document.getElementById("iLat").value = Row.find("td:eq(6)").text();
		document.getElementById("iKet").value = "uplant";
		fg_popup_form('fgFrm01','fgHeader','bgFrm01','40');
	}
</script>

<?php 

?>