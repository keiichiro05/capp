<?php
# Project   : DWSystem
# Auth.  	: DamarTeduh©2018 2019-03-05 07:03
# Rev 		: HOME
# 20200420 Home, Rework ke template BARU - DWR

date_default_timezone_set("Asia/Jakarta");
include APP_DIR . "config/connection.php";
include APP_DIR . "assets/class.phpmailer.php";
include APP_DIR . "assets/utility_function.php";

$user=$_SESSION[APP_NAME]["username"];

switch ($_POST["nKet"]) {

# REGISTRASI USER
	case "iusr":	# Insert new user
		$str="INSERT INTO tbm_usr (username, pass, nik, nama_lengkap, plant_id, sys_admin, aktif, email) VALUES (LOWER('{$_POST["username"]}'),MD5('{$_POST["nik"]}'),'{$_POST["nik"]}',UPPER('{$_POST["nama"]}'),'{$_POST["plant"]}','{$_POST["sys_adm"]}','{$_POST["aktif"]}','{$_POST["email"]}')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>window.location.replace('cpanel?ac=akses')</script>";
		break;

	case "dusr": 	# Delete User
		$str="DELETE FROM tbm_usr WHERE username='{$_POST['username']}'";
		mysqli_query($con,$str);
		mysqli_close($con);
		break;

	case "eusr":
		$str="UPDATE tbm_usr SET nik='{$_POST["nik"]}', nama_lengkap=UPPER('{$_POST["nama"]}'), plant_id='{$_POST["plant"]}', region_id='{$_POST["region"]}', email='{$_POST["email"]}', aktif='{$_POST["aktif"]}', sys_admin='{$_POST["sys_adm"]}' WHERE username='{$_POST['username']}'";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case 'rusr': 	# Reset password to NIK
		$str="UPDATE tbm_usr SET pass=MD5('{$_POST["nik"]}') WHERE username= '{$_POST['username']}'";
		if(isset($_POST["email"]) AND $_POST["email"]!='') {
			$mailto[$_POST["email"]]=$_POST['username'];
			sendEmail($mailto,"Reset Password","Your new password: ".$_POST["nik"]);
		}
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:alert('INFO! Your password have been changed');</script>";
		echo "<script>javascript:window.location.href='application/login/signout.php';</script>";
		break;

# PREVILEDGE AKSES
	case "iprev": # Tambah previledge
		$str="INSERT INTO db_depo.tbl_akses (username,modul,action,buat,rubah,hapus) VALUES ('{$_POST["usr"]}','{$_POST["modul"]}','{$_POST["action"]}','{$_POST["buat"]}','{$_POST["rubah"]}','{$_POST["hapus"]}')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "dprev": # Delete previledge
		$str="DELETE FROM db_depo.tbl_akses WHERE seq={$_POST['seq']}";
		mysqli_query($con,$str);
		mysqli_close($con);
		break;

	case "uprev": # Edit previledge
		$str="UPDATE db_depo.tbl_akses SET buat='{$_POST["buat"]}', rubah='{$_POST["rubah"]}', hapus='{$_POST["hapus"]}' WHERE seq={$_POST['seq']}";
		mysqli_query($con,$str);
		mysqli_close($con);
		break;

# MASTER DATA PLANT
	case "uplant":
		$lon=(isset($_POST["lon"]) AND $_POST["lon"]!="")?$_POST["lon"]:'NULL';
		$lat=(isset($_POST["lat"]) AND $_POST["lat"]!="")?$_POST["lat"]:'NULL';
		$str="UPDATE tbm_location SET szDescription=UPPER('{$_POST["szDescription"]}'), region='{$_POST["region"]}', ParentSite='{$_POST["region"]}', aktif='{$_POST["aktif"]}', lon={$lon}, lat={$lat}, update_by='{$user}' WHERE seq={$_POST['seq']}";
		mysqli_query($con,$str);

		# Update region child
		$str="UPDATE tbm_location SET region='{$_POST["region"]}', update_by='{$user}' WHERE ParentSite={$_POST['nKode']}";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "iplant":
		$url = API_SERVER . "plant/read";
		$json=substr(@file_get_contents($url), 3);
		$rows =json_decode($json, TRUE);
		$post = array_search($_POST['plant'], array_column($rows, 'nKode'));
		$str="INSERT INTO tbm_location (nLevel, nKode, szDescription, region, equip_group, funloc, ParentSite, create_by, create_date) VALUES ('0', '{$rows[$post]['nKode']}', '{$rows[$post]['plant_name']}', '{$rows[$post]['regional']}', 'PLANT', '{$rows[$post]['nKode']}', '{$rows[$post]['regional']}', '{$user}', '".date('Y-m-d H:i:s')."')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;	

	case "syncplant":
		$url = API_SERVER . "plant/read";
		$json=substr(@file_get_contents($url), 3);
		$rows =json_decode($json, TRUE);
		// echo json_last_error();
		foreach ($rows as $key => $variable) {
			$str="REPLACE INTO tbm_location (nLevel, nKode, szDescription, region, equip_group, funloc, ParentSite, create_by, create_date) VALUES ('0', '{$rows[$key]['nKode']}', '{$rows[$key]['plant_name']}', '{$rows[$key]['regional']}', 'PLANT', '{$rows[$key]['nKode']}', '{$rows[$key]['regional']}', '{$user}', '".date('Y-m-d H:i:s')."')";
			mysqli_query($con,$str);
		}
		mysqli_close($con);
		break;

# MASTER DATA KLASIFIKASI
	case "iclass":
		$str="INSERT INTO `dbworkflow`.tbm_ecar_klasifikasi (kode, kategori, diskripsi, create_by) VALUES ('{$_POST['kode']}', '{$_POST['kategori']}', '{$_POST['diskripsi']}', '{$user}')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "uclass":
		$str="UPDATE `dbworkflow`.tbm_ecar_klasifikasi SET kategori='{$_POST['kategori']}', diskripsi='{$_POST['diskripsi']}', enab='{$_POST['aktif']}' WHERE kode='{$_POST['kode']}'";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

# MASTER DATA TOPIK
	case "itopik":
		$str="INSERT INTO `dbworkflow`.tbm_topik (kode, deskripsi, create_by) VALUES ('{$_POST['kode']}', '{$_POST['diskripsi']}', '{$user}')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "utopik":
		$str="UPDATE `dbworkflow`.tbm_topik SET deskripsi='{$_POST['diskripsi']}', enab='{$_POST['aktif']}' WHERE kode='{$_POST['kode']}'";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

# MASTER DATA KATEGORI
	case "iktg":
		$str="INSERT INTO `dbworkflow`.tbm_ecar_kategori (id_kategori, diskripsi_kategori, create_by) VALUES ('{$_POST['kode']}', '{$_POST['diskripsi']}', '{$user}')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "uktg":
		$str="UPDATE `dbworkflow`.tbm_ecar_kategori SET diskripsi_kategori='{$_POST['diskripsi']}', enab='{$_POST['aktif']}' WHERE id_kategori='{$_POST['kode']}'";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

# MASTER DATA CURRENCY
	case "icur":
		$str="INSERT INTO `dbworkflow`.tbm_currency (kode, diskripsi, exchange_rate, create_by) VALUES ('{$_POST['kode']}', '{$_POST['diskripsi']}', '{$_POST['rate']}', '{$user}')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "ucur":
		echo $str="UPDATE `dbworkflow`.tbm_currency SET diskripsi='{$_POST['diskripsi']}', exchange_rate='{$_POST['rate']}', enab='{$_POST['aktif']}' WHERE kode='{$_POST['kode']}'";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

# MASTER DATA ATTACH FILE BY KATEGORI
	case "iatt":
		$str="INSERT INTO `dbworkflow`.tbm_ecar_attachfile (kategori, requirement_file, create_by) VALUES ('{$_POST['kode']}', '{$_POST['diskripsi']}', '{$_POST['rate']}', '{$user}')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "uatt":
		echo $str="UPDATE `dbworkflow`.tbm_ecar_attachfile SET requirement_file='{$_POST['diskripsi']}', enab='{$_POST['aktif']}' WHERE seq='{$_POST['kode']}'";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

# MASTER DATA EMAIL
	case "iemail":
		$isApprover=($_POST['frmseq']==1)?"Y":"N";
		$str="INSERT INTO `dbworkflow`.tbm_approval_level (plant_id, topic, kategori, nama, jabatan, email, seq_appr, approver_id, is_first_approver) VALUES ('{$_POST['frmplant']}', '{$_POST['frmtopik']}', '{$_POST['frmktg']}', '{$_POST['frmnama']}', '{$_POST['frmjabatan']}', '{$_POST['frmemail']}', '{$_POST['frmseq']}', '{$_POST['frmusername']}', '{$isApprover}')";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "uemail":
		$isApprover=($_POST['frmseq']==1)?"Y":"N";
		$str="UPDATE `dbworkflow`.tbm_approval_level SET plant_id='{$_POST['frmplant']}', topic='{$_POST['frmtopik']}', kategori='{$_POST['frmktg']}' , nama='{$_POST['frmnama']}', jabatan='{$_POST['frmjabatan']}', email=LOWER('{$_POST['frmemail']}'), seq_appr='{$_POST['frmseq']}', approver_id='{$_POST['frmusername']}', is_first_approver='{$isApprover}' WHERE seq='{$_POST['seq']}'";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;

	case "demail":
		$str="DELETE FROM `dbworkflow`.tbm_approval_level WHERE seq={$_POST['seq']}";
		mysqli_query($con,$str);
		mysqli_close($con);
		echo "<script>javascript:history.back();</script>";
		break;
}
exit();
?>
