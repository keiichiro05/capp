<!-- Login Pop Up -->
<script type='text/javascript' src='static/js/popup.form.js'></script>
<link type="text/css" rel="stylesheet" href="static/css/popup.form.css"/>

<!-- Sticky Header Table -->
<link rel="stylesheet" type="text/css" href="static/css/component.css" />
<script src="static/js/jquery.stickyheader.js"></script>
<script src="static/js/jquery.ba-throttle-debounce.min.js"></script>

<?php
/*
# Prject: CAPEX Request
# User  : Jefry (phoa.permana@danone.com)
# Auth  : DamarTeduh©2020
# Create: BOGOR | 2020-05-13 16:33
*/

# Initialisasi -------
include APP_DIR . "config/connection.php";
require APP_DIR . "assets/utility_function.php";
include APP_DIR . "/assets/sql_function.php";
require APP_DIR . "assets/static_param.php";

# Memory page ketika refresh
$_SESSION[APP_NAME]['cpanel']=$controller.'?ac='.$action;

$menu=cariKey();
echo topHeaderDetail("Master Kategori","true",$menu);
?>

<table class="table-control">
	<thead>
		<tr>
			<th>Kode Kategori</th>
			<th>Diskripsi Kategori</th>
			<th>Active</th>
			<th>Create By</th>
			<th>Create Date</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
	<?php
		# Query Klasifikasi
		$str="SELECT * FROM `dbworkflow`.tbm_ecar_kategori";
		$result=mysqli_query($con,$str);
		while ($row=mysqli_fetch_assoc($result)) {
	?>
		<tr id="<?php echo $row['id_kategori']; ?>" class="cari">
			<td><?php echo $row['id_kategori']; ?></td>
			<td><?php echo $row['diskripsi_kategori']; ?></td>
			<td><?php echo $row['enab']; ?></td>
			<td><?php echo $row['create_by']; ?></td>
			<td><?php echo $row['create_date']; ?></td>
			<td class="text-center">
				<button class="edit" onclick="cmdEdit('<?php echo $row["id_kategori"]; ?>');"></button>
			</td>
		</tr>
	<?php		
		}
	?>		
	</tbody>
</table>

<!-- Pop Up Form -->
<div id='fgFrm01'>
	<div id="fgHeader">Kategori</div>
		<div id="frmInner">
			<div class='container'>
				<form action="cpanel?ac=send" method="POST">
					<ul id="form-control">
						<li><span>Code</span><input type="text" id="idKode" name="kode"></li>
						<li><span>Description</span><input type="text" id="idDisk" name="diskripsi"></li>
						<li><span>Active</span><?php echo cmbBox("aktif","","idAktif","Y",$mYN,"");	?></li>
						<li><span></span>
							<button type="submit" name="nKet" id="iKet" value="iclass">Submit</button>
							<button type="button" onclick="fg_hideform('fgFrm01','bgFrm01')">Cancel</button>
						</li>
					</ul>
				</form>
			</div>
		</div>
	</div>
</div> 
<div id='bgFrm01'></div>
<div id="log"></div>

<script type="text/javascript">
	$("#new").on("click",function(){
		document.getElementById("idKode").value = "";
		document.getElementById("idKode").readOnly = false;
		document.getElementById("idDisk").value = "";
		document.getElementById("idAktif").value = "Y";
		document.getElementById("iKet").value = "iktg";
		fg_popup_form('fgFrm01','fgHeader','bgFrm01','40');
	});

	$("#refresh").on("click",function(){ window.location.reload(); });

	function cmdEdit(id){
		var Row=$("#"+id).closest("tr");
		document.getElementById("idKode").value = id;
		document.getElementById("idKode").readOnly = true;
		document.getElementById("idDisk").value = Row.find("td:eq(1)").text();
		document.getElementById("idAktif").value = Row.find("td:eq(2)").text();
		document.getElementById("iKet").value = "uktg";
		fg_popup_form('fgFrm01','fgHeader','bgFrm01','40');
	}
</script>