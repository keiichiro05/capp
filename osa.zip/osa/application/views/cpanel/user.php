<!-- Login Pop Up -->
<script type='text/javascript' src='static/js/popup.form.js'></script>
<link type="text/css" rel="stylesheet" href="static/css/popup.form.css"/>
<style type="text/css">
	a.akses {
		display: block;
		text-decoration: none;
		height: 20px;
		text-align: center;
		border: 1px solid #0CA8F1;
		background: #0CA8F1;
		color: white;
		vertical-align: top;
	}
	.akses:hover { opacity: 0.5; color: white; }
</style>
<?php
/*
# Project : DWSystem
# Auth    : DamarTeduh©2018 2019-03-04 08:03
# Rev     : SENTUL PLANT - Controller u/ c-panel
# 	20190917 08:34 AM 	Pandaan, memory page -> $_SESSION[APP_NAME]['cpanel']=$controller.'?action='.$action;
	20190918 Taman Dayu, lock page setelah refresh
*/
include APP_DIR . "config/connection.php";
require APP_DIR . "assets/utility_function.php";
require APP_DIR . "assets/sql_function.php";

# Query master qmp level 0
# Query Plant - Sumber
$str="SELECT * FROM tbm_location WHERE nLevel=0 ORDER BY region, funloc";
$result=mysqli_query($con,$str);
while ($row=mysqli_fetch_assoc($result)) {
	$mPlant[$row['nKode']]=$row['szDescription'];
	$mReg[$row['nKode']]=$row['region'];
}
$mPlant[""]="ALL";
$mPlant["9000"]="Head Office";
$mReg["9000"]="HO";
asort($mPlant);

$jsonReg=json_encode($mReg);

$mSortTyp= array('ASC' => 'ASC','DESC'=>'DESC');
$mAktif  = array(""=>"Semua","Y"=>"Aktif","N"=>"Tidak Aktif");
$mField  = array('username'=>'Username', 'nama_lengkap'=>'Nama Lengkap', 'nik'=>'Nik', 'email'=>'Email', 'region_id'=>'Region', 'plant_id'=>'Plant', 'aktif'=>'Aktif', 'sys_admin'=>'Super User');

# Memory page ketika refresh
$_SESSION[APP_NAME]['cpanel']=$controller.'?ac='.$action;

# Set default value dan memori last select
$CARI =getPreValue('cmdKirim','');
$PLANT=getPreValue('plantUser','');
$AKTIF=getPreValue('aktifUser',key($mAktif));
$SORT=getPreValue('sortUser',key($mField));
$TYPSORT=getPreValue('typUser',key($mSortTyp));

# Top menu - Setup and Config
# --------------------------------------------------------------
$judul = "User Registration";
// require APP_DIR . "views/cpanel/topmenu.php";
echo topHeader($judul,"true");
# --------------------------------------------------------------

# Setup Paging
$batas   = 15;
$halaman = @$_GET['page'];
$posisi  = ($halaman-1) * $batas;
if(empty($halaman)){
	$posisi  = 0;
	$halaman = 1;
}
$str = "SELECT COUNT(username) jml FROM tbm_usr WHERE (nik LIKE '%{$CARI}%' OR nama_lengkap LIKE '%{$CARI}%' OR username LIKE '%{$CARI}%') AND plant_id LIKE '%{$PLANT}%' AND aktif LIKE '%{$AKTIF}%'";
$result = mysqli_query($con, $str);
$jmldata= mysqli_fetch_assoc($result);
$jmlhalaman = ceil($jmldata['jml']/$batas);
?>

<div class="sub-nav">
	<form action="cpanel?ac=user" method="POST">
	<div id="mySearch"><label><i class="fa fa-search"></i> Search</label>
		<input type="text" name="cmdKirim" value="<?php echo $CARI; ?>" placeholder="Cari nama, nik, username">
		<button type="submit"><i class="fa fa-send"></i></button>
	</div>
	<div id="myFilter"><label><i class="fa fa-filter"></i> Filter</label>
		<?php
			echo cmbBox('plantUser','','',$PLANT,$mPlant,'onchange="this.form.submit()"');
			echo cmbBox('aktifUser','','',$AKTIF,$mAktif,'onchange="this.form.submit()"');
		?>
	</div>
	<div id="mySort"><label><i class="fa fa-sort-amount-asc"></i> Sort</label>
		<?php
			echo cmbBox('sortUser','','',$SORT,$mField,'onchange="this.form.submit()"');
			echo cmbBox('typUser','','',$TYPSORT,$mSortTyp,'onchange="this.form.submit()"');
		?>
	</div>
	</form>
</div>

<table class="table-control">
	<thead>
		<tr>
			<th>Username</th>
			<th>NIK</th>
			<th>Full name</th>
			<th>Plant</th>
			<th>Email</th>
			<th>Sys-Admin</th>
			<th>Active</th>
			<th>Action</th>
			<th>Password</th>
			<th>Access</th>
		</tr>
	</thead>
	<tbody>
	<?php
		$str="SELECT * FROM tbm_usr WHERE (nik LIKE '%{$CARI}%' OR nama_lengkap LIKE '%{$CARI}%' OR username LIKE '%{$CARI}%') AND plant_id LIKE '%{$PLANT}%' AND aktif LIKE '%{$AKTIF}%' ORDER BY sys_admin, region_id, plant_id ASC";
		$result=mysqli_query($con,$str);
		while($row = mysqli_fetch_assoc($result)){
	?>
		<tr id="<?php echo $row['username']; ?>">
			<td><?php echo $row['username']; ?></td>
			<td><?php echo $row['nik']; ?></td>
			<td><?php echo $row['nama_lengkap']; ?></td>
			<td><?php echo isset($mPlant[$row['plant_id']])?$mPlant[$row['plant_id']]:$row['plant_id']; ?></td>
			<td><?php echo $row['email']; ?></td>
			<td><?php echo $row['sys_admin']; ?></td>
			<td><?php echo $row['aktif']; ?></td>
			<td style="display: none;"><?php echo $row['plant_id']; ?></td>
			<td>
				<button type="button" class="edit" onclick="cmdEdit('<?php echo $row["username"];?>')"></button>
				<button type="button" class="hapus" onclick="cmdHapus('<?php echo $row["username"];?>')"></button>
			</td>
			<td><button type="button" class="reset" onclick="cmdReset('<?php echo $row["username"];?>')">RESET</button></td>
			<td><a href="cpanel?ac=userdetail&id=<?php echo $row["username"];?>" class="akses">ACCESS</a></td>
		<tr>
	<?php 
		}
		mysqli_close($con);
	?>
	</tbody>
</table>
<!-- PAGER -->
page 
<?php 
	if($halaman>1) echo '<a href="control?action=user&page=1"><i class="fa fa-fast-backward"></i></a> <a href="control?action=user&page='.($halaman-1).'"><i class="fa fa-backward"></i></a> ';
	echo $halaman.' of '.$jmlhalaman; 
	if($halaman<$jmlhalaman) echo ' <a href="control?action=user&page='.($halaman+1).'"><i class="fa fa-forward"></i></a> <a href="control?action=user&page='.$jmlhalaman.'"><i class="fa fa-fast-forward"></i></a>';
?>

</div>

<!-- Pop Up Form -->
<div id='fgFrm01'>
	<div id="fgHeader">Edit User</div>
		<div id="frmInner">
			<div class='container'>
				<form action="cpanel?ac=send" method="POST">
					<ul id="form-control">
						<li><span>Username</span> <input type="text" name="username" id="iUsername" required></li>
						<li><span>Nama Lengkap</span> <input type="text" name="nama" id="iFullname" required></li>
						<li><span>Lokasi</span> <?php 
							$mPlant['']="";
							echo cmbBox('plant','','iLokasi',key($mPlant),$mPlant,'required');
						?></li>
						<li><span>Region</span> <input type="text" name="region" id="iReg" readonly></li>
						<li><span>Nik</span> <input type="text" name="nik" id="iNik" required></li>
						<li><span>Email</span> <input type="text" name="email" id="iEmail"></li>
						<li><span>Aktif</span> <?php 
							unset($mAktif['']);
							echo cmbBox('aktif','','iAktif','',$mAktif,'');
						?></li>
						<li><span>System Admin.</span> <?php 
							$mSa=array("Y"=>"Ya", "N"=>"Tidak");
							echo cmbBox('sys_adm','','iSysadm','',$mSa,'');
						?></li>
						<li><span></span>
							<button type="submit" name="nKet" id="iKet" value="iusr">Submit</button>
							<button type="button" onclick="fg_hideform('fgFrm01','bgFrm01')">Cancel</button>
						</li>
					</ul>
				</form>
			</div>
		</div>
	</div>
</div> 
<div id='bgFrm01'></div>

<script type="text/javascript">
	function cmdReset(id){
		var r = confirm("ALERT! Confirm reset password to NIK...");
		if (r == true) {
			var email = document.getElementById('iEmail').value;
			var dtRow = 'username='+id+'&nik='+nik+'&nKet=rusr&email='+email;
			$.ajax({
				type: "POST",
				url: "cpanel?ac=send",
				data: dtRow,
				cache: false,
				success: function(html){ window.location.reload(); }
			});
		}
	}

	$("#iLokasi").change(function(){
		var region = <?php echo $jsonReg; ?>;
		plant=this.value;
		document.getElementById("iReg").value=region[plant];
	});

	function cmdEdit(id){
		var region = <?php echo $jsonReg; ?>;
		var Row=$("#"+id).closest("tr");
		document.getElementById("iKet").value = "eusr";
		document.getElementById("iUsername").readOnly = true;
		document.getElementById("iUsername").value = id;
		document.getElementById("iNik").value = Row.find("td:eq(1)").text();
		document.getElementById("iFullname").value = Row.find("td:eq(2)").text();
		document.getElementById("iEmail").value = Row.find("td:eq(4)").text();
		document.getElementById("iSysadm").value = Row.find("td:eq(5)").text();
		document.getElementById("iAktif").value = Row.find("td:eq(6)").text();
		document.getElementById("iLokasi").value= Row.find("td:eq(7)").text();
		document.getElementById("iReg").value= region[Row.find("td:eq(7)").text()];
		fg_popup_form('fgFrm01','fgHeader','bgFrm01','40');
	}

	function cmdHapus(id){
		var r = confirm("ALERT! OK (Delete) or Cancel");
	  	if (r == true) $.post("cpanel?ac=send", {username:id, nKet:"dusr"}, function(html){ window.location.reload(); });
	}

	$("#new").click(function(){ 
		document.getElementById("fgHeader").innerHTML = "New User";
		document.getElementById("iUsername").readOnly = false;
		document.getElementById("iKet").value = "iusr";
		document.getElementById("iUsername").value = "";
		document.getElementById("iFullname").value= "";
		document.getElementById("iLokasi").value= "";
		document.getElementById("iNik").value= "";
		document.getElementById("iEmail").value= "";
		document.getElementById("iAktif").value = "Y";
		document.getElementById("iSysadm").value = "N";
		fg_popup_form('fgFrm01','fgHeader','bgFrm01','40');
	});
</script>