<!-- Login Pop Up -->
<script type='text/javascript' src='static/js/popup.form.js'></script>
<link type="text/css" rel="stylesheet" href="static/css/popup.form.css"/>

<!-- Sticky Header Table -->
<link rel="stylesheet" type="text/css" href="static/css/component.css" />
<script src="static/js/jquery.stickyheader.js"></script>
<script src="static/js/jquery.ba-throttle-debounce.min.js"></script>

<?php
/*
# Project : DWR
# Auth    : DamarTeduh©2020 Home, 2020-04-27 15:11
# Rev     : 
*/
# Initialisasi -------
include APP_DIR . "config/connection.php";
require APP_DIR . "assets/utility_function.php";
include APP_DIR . "/assets/sql_function.php";
require APP_DIR . "assets/static_param.php";

# Memory page ketika refresh
$_SESSION[APP_NAME]['cpanel']=$controller.'?ac='.$action;

# Get master plant dari Central Master via API
$mPlant["9000"]="HO";
$url = API_SERVER . "plant/site";
$json=@file_get_contents($url);
$rows =json_decode($json, TRUE); // echo json_last_error();
$mPlant["9000"]="HO - HEAD OFFICE";
foreach ($rows as $key => $variable) { $mPlant[$rows[$key]['nKode']]=$rows[$key]['tipe']."-".$rows[$key]['plant_name']; }
$PLANT=getPreValue("plant",key($mPlant));

# topik
$json_data = '{
		"table" : "`dbworkflow`.tbm_topik",
		"fields": ["kode", "deskripsi"],
		"where" : "enab=\'Y\'"
		}';
$mTopik = getMasterData($json_data);
$TOPIK = getPreValue("topik",key($mTopik));

# Master kategory
$json_data = '{
		"table" : "`dbworkflow`.tbm_ecar_kategori",
		"fields": ["id_kategori", "diskripsi_kategori"],
		"where" : "enab=\'Y\'"
		}';
$mKtg = getMasterData($json_data);
$KTG = getPreValue("ktg",key($mKtg));

$mSeq = array("1"=>"1", "2"=>"2", "3"=>"3", "4"=>"4", "5"=>"5", "6"=>"6", "7"=>"7", "8"=>"8");

$menu ="<form method='POST' id='formPageHeader'>";
$menu.=cmbBox("plant","","idPlant",$PLANT,$mPlant,"");
$menu.=cmbBox("topik","","idTopik",$TOPIK,$mTopik,"");
$menu.=cmbBox("ktg","","idKtg",$KTG,$mKtg,"");
$menu.="</form>";
echo topHeaderDetail("Daftar Email Notifikasi","true",$menu);
?>

<table class="table-control">
	<thead>
		<tr>
			<th>Plant</th>
			<th>Topik</th>
			<th>Kategori</th>
			<th>Urutan</th>
			<th>Nama</th>
			<th>Jabatan</th>
			<th>Email</th>
			<th>Username</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
	<?php
		$i=1;
		# Query Plant
		$str="SELECT * FROM `dbworkflow`.tbm_approval_level WHERE plant_id='{$PLANT}' AND topic='{$TOPIK}' AND kategori='{$KTG}' ORDER BY plant_id, topic, kategori, seq_appr";
		$result=mysqli_query($con,$str);
		while ($row=mysqli_fetch_assoc($result)) {
	?>
		<tr id="<?php echo $row['seq']; ?>" class="cari">
			<td><?php echo $row['plant_id']; ?></td>
			<td><?php echo $row['topic']; ?></td>
			<td><?php echo $row['kategori']; ?></td>
			<td><?php echo $row['seq_appr']; ?></td>
			<td><?php echo $row['nama']; ?></td>
			<td><?php echo $row['jabatan']; ?></td>
			<td><?php echo $row['email']; ?></td>
			<td><?php echo $row['approver_id']; ?></td>
			<td class="text-center">
				<button type="button" class="edit" onclick="cmdEdit('<?php echo $row["seq"]; ?>');"></button>
				<button type="button" class="hapus" onclick="cmdDel('<?php echo $row["seq"]; ?>');"></button>
			</td>
		</tr>
	<?php		
		}
	?>		
	</tbody>
</table>

<!-- Pop Up Form -->
<div id='fgFrm01'>
	<div id="fgHeader">Update User Email</div>
		<div id="frmInner">
			<div class='container'>
				<form action="cpanel?ac=send" method="POST">
					<input type="hidden" name="seq" id="idSeq">
					<ul id="form-control">
						<li><span>Plant</span> <?php echo cmbBox("frmplant","","idFrmPlant","",$mPlant,"required"); ?></li>
						<li><span>Topik</span> <?php echo cmbBox("frmtopik","","idFrmTopik","",$mTopik,"required"); ?></li>						
						<li><span>Kategori</span> <?php echo cmbBox("frmktg","","idFrmKtg","",$mKtg,"required"); ?></li>
						<li><span>Urutan</span> <?php echo cmbBox("frmseq","","idFrmSeq","",$mSeq,"required"); ?></li>
						<li><span>Nama</span> <input type="text" id="idFrmNama" name="frmnama" required></li>
						<li><span>Jabatan</span> <input type="text" id="idFrmJabatan" name="frmjabatan" required></li>
						<li><span>Email</span> <input type="text" id="idFrmEmail" name="frmemail" required></li>
						<li><span>Username</span> <input type="text" id="idFrmUsername" name="frmusername" required></li>
						<li><span></span>
							<button type="submit" name="nKet" id="iKet" value="uemail">Submit</button>
							<button type="button" onclick="fg_hideform('fgFrm01','bgFrm01')">Cancel</button>
						</li>
					</ul>
				</form>
			</div>
		</div>
	</div>
</div> 
<div id='bgFrm01'></div>
<div id="log"></div>

<script type="text/javascript">
	$("#idPlant").on("change",function(){ document.getElementById('formPageHeader').submit(); });
	$("#idTopik").on("change",function(){ document.getElementById('formPageHeader').submit(); });
	$("#idKtg").on("change",function(){ document.getElementById('formPageHeader').submit(); });
	$("#refresh").on("click",function(){ window.location.reload(); });

	function cmdEdit(id){
		var Row=$("#"+id).closest("tr");
		document.getElementById("idSeq").value = id;
		document.getElementById("idFrmPlant").value = Row.find("td:eq(0)").text();
		document.getElementById("idFrmTopik").value = Row.find("td:eq(1)").text();
		document.getElementById("idFrmKtg").value = Row.find("td:eq(2)").text();
		document.getElementById("idFrmSeq").value = Row.find("td:eq(3)").text();
		document.getElementById("idFrmNama").value = Row.find("td:eq(4)").text();
		document.getElementById("idFrmJabatan").value = Row.find("td:eq(5)").text();
		document.getElementById("idFrmEmail").value = Row.find("td:eq(6)").text();
		document.getElementById("idFrmUsername").value = Row.find("td:eq(7)").text();
		document.getElementById("iKet").value = "uemail";
		fg_popup_form('fgFrm01','fgHeader','bgFrm01','40');
	}

	$("#new").on("click",function(){ 
		document.getElementById("idFrmPlant").value = "";
		document.getElementById("idFrmTopik").value = "";
		document.getElementById("idFrmKtg").value = "";
		document.getElementById("idFrmSeq").value = "";
		document.getElementById("idFrmNama").value = "";
		document.getElementById("idFrmJabatan").value = "";
		document.getElementById("idFrmEmail").value = "";
		document.getElementById("idFrmUsername").value = "";
		document.getElementById("iKet").value = "iemail";
		fg_popup_form('fgFrm01','fgHeader','bgFrm01','40');
	});

	function cmdDel(id){
		var r = confirm("ALERT! Confirm delete...");
		if (r == true) { $.post("cpanel?ac=send", {seq:id, nKet:"demail"}, function(result){ window.location.reload(); }); }
	}
</script>
