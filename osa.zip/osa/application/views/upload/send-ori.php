<?php
/*
# Prject: BWG Project 1.0
# Auth  : DamarTeduh©2019
# Create: Taman Dayu | 2019-11-21 19:53
*/

$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];


//check if input file is empty
$err="";
print_r($_FILES);
// exit;

$filetitle = $_FILES['cFile']['name'];

if(!empty($_FILES['cFile']['name'])){
  $filename = $_FILES['cFile']['tmp_name'];
  $fileinfo = pathinfo($_FILES['cFile']['name']);

  //check file extension
  // if(strtolower($fileinfo['extension']) == 'csv' AND $_FILES['files']['size'] > 0){
    //check if file contains data
    $delimiter = ",";
    $delimiterb = ",";
    $file = fopen($filename, 'r');
    $fileb = fopen($filename, 'r');
    $firstLine = fgets($file);
    $tgl2 = fgetcsv($fileb, 200, $delimiterb);
    $tgl = fgetcsv($fileb, 200, $delimiterb);
    $i=0;
    

if(strpos($firstLine, ";") != FALSE) $delimiter=";";    
    while(($impData = fgetcsv($file, 200, $delimiter)) != FALSE){
        $sellout = isset($impData[6])?$impData[6]:0;
        if(strlen(trim($impData[5])) <= 0 )
          { $stock = 0; } 
        else { $stock= $impData[5]; }
        $outlet = trim($impData[3]);
        $query = "REPLACE INTO tbl_stock (stockdate, account, dc_name, outlet_id, outlet_name, stockc, stock, sellout, stockh_1,upload_date,brand) VALUES ('".$impData[0]."','".$impData[1]."','".$impData[2]."','".$outlet."','".$impData[4]."','".$impData[5]."',".$stock.",'".$sellout."',0,'".date("Y-m-d H:i:s")."','".$impData[7]."')"; 
        mysqli_query($con,$query);
        // echo $query;
        $query = "UPDATE tbl_stock SET 
         stockh_1 = (SELECT (CASE WHEN stock_simu is null THEN 0 ELSE stock_simu END) from 
         (SELECT stock_simu from tbl_stock WHERE stockdate = DATE_ADD('".$impData[0]."', INTERVAL -1 DAY) AND account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND brand = '".$impData[7]."') as b)  WHERE stockdate= '".$impData[0]."' AND account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND brand = '".$impData[7]."'";
         mysqli_query($con,$query);
       $query = "UPDATE tbl_stock SET 
         stockh_2 = (SELECT (CASE WHEN stock_simu is null THEN 0 ELSE stock_simu END) from 
         (SELECT stock_simu from tbl_stock WHERE stockdate = DATE_ADD('".$impData[0]."', INTERVAL -2 DAY) AND account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND brand = '".$impData[7]."') as b)  WHERE stockdate= '".$impData[0]."' AND account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND brand = '".$impData[7]."'";
        mysqli_query($con,$query);
        $query = "UPDATE tbl_stock SET sap_id = (SELECT sap_id from tbl_store WHERE account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND brand = '".$impData[7]."') WHERE stockdate= '".$impData[0]."' AND account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND brand = '".$impData[7]."'";
        mysqli_query($con,$query);
        $query = "UPDATE tbl_stock SET act_real = (SELECT 
        (CASE WHEN do_qty is null THEN 0 ELSE do_qty END) from tbl_realisasi WHERE account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND do_date = '".$impData[0]."' AND brand = 'AQUA') WHERE stockdate= '".$impData[0]."' AND account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND brand = '".$impData[7]."'";
        mysqli_query($con,$query);
        $i++;
    }


$str="UPDATE tbl_stock SET act_real = 0 WHERE act_real is null";
mysqli_query($con, $str);

$query = "
UPDATE tbl_stock s INNER JOIN tbl_store st ON s.outlet_id = st.outlet_id AND s.brand = st.brand
SET s.sap_id = st.sap_id
WHERE s.stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// tambahan 21 Mar
$query = "
UPDATE tbl_stock t, tbl_store ts
SET t.supplier =  ts.supplier, t.source = ts.source
WHERE t.outlet_id = ts.outlet_id AND t.brand = ts.brand AND t.stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// tambahan 21 Mar
$query = "
UPDATE tbl_stock t, tbl_masterjwk tmj
SET t.jwk = tmj.jwk
WHERE t.sap_id = tmj.id_sap AND t.brand = 'AQUA' AND stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// query untuk stock simu
$str="
DROP TEMPORARY TABLE IF EXISTS tbl_stock_yesterday;
";
mysqli_query($con, $str);

$str = "
CREATE TEMPORARY TABLE tbl_stock_yesterday
SELECT s.stockdate, s.`account`, s.outlet_id, s.brand, s.stock_simu
FROM tbl_stock s
WHERE s.stockdate = DATE_SUB('".$tgl[0]."', INTERVAL 1 DAY);
";
mysqli_query($con, $str);

$str = "
UPDATE tbl_stock ss SET stock_simu = 
(CASE 
  WHEN length(stockc) <= 0 THEN 
	(SELECT oo.stock_simu FROM
		(SELECT s.`account`, s.outlet_id, s.brand, (sy.stock_simu + s.act_real - s.spd3w) AS stock_simu 
		FROM tbl_stock s 
		INNER JOIN tbl_stock_yesterday sy
		WHERE s.stockdate = '".$tgl[0]."' AND s.`account` = sy.`account` AND s.outlet_id = sy.outlet_id AND s.brand = sy.brand) oo
	WHERE ss.`account` = oo.`account` AND ss.outlet_id = oo.outlet_id AND ss.brand = oo.brand)
  
  WHEN stock <= 0 THEN 
	(SELECT oo.stock_simu FROM
		(SELECT s.`account`, s.outlet_id, s.brand, (sy.stock_simu + s.act_real - s.spd3w) AS stock_simu 
		FROM tbl_stock s 
		INNER JOIN tbl_stock_yesterday sy
		WHERE s.stockdate = '".$tgl[0]."' AND s.`account` = sy.`account` AND s.outlet_id = sy.outlet_id AND s.brand = sy.brand) oo
	WHERE ss.`account` = oo.`account` AND ss.outlet_id = oo.outlet_id AND ss.brand = oo.brand)
	
  ELSE ss.stock  
END) 
WHERE stockdate ='".$tgl[0]."';
";
mysqli_query($con, $str);

$query = "
UPDATE tbl_stock s, tbl_spd3w spd
SET s.spd3w = spd.spd3week
WHERE s.stockdate = '".$tgl[0]."' AND s.outlet_id = spd.outlet_id AND s.brand = spd.brand;
";
mysqli_query($con, $query);

$query = "
UPDATE tbl_stock s, tbl_max_stock3w mx
SET s.max_stock3w = mx.max_stock
WHERE s.stockdate = '".$tgl[0]."' AND s.outlet_id = mx.outlet_id AND s.brand = mx.brand;
";
mysqli_query($con, $query);

// Update Data BWS
// bisa dioptimise dengan spesifik-in account nya jadi engga update semua account tiap kali upload
$query = "
UPDATE tbl_stock s, tbl_store st
SET s.bws = st.bws
WHERE s.stockdate = '".$tgl[0]."' AND s.outlet_id = st.outlet_id AND s.account = st.account;
";
mysqli_query($con, $query);

// Generate OG APOLLO
$query = "
UPDATE tbl_stock s
SET s.og_apollo = 
	CASE
		WHEN s.max_stock3w - s.stock_simu + 3*s.spd3w < 5 THEN 5 ELSE
			CASE
				WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stock_simu + 3*s.spd3w >= s.max_stock3w THEN s.max_stock3w 
        WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stock_simu + 3*s.spd3w < s.max_stock3w THEN s.max_stock3w - s.stock_simu + 3*s.spd3w
        ELSE 5
			END
	END,
	s.jenis_og =
	CASE
		WHEN s.max_stock3w - s.stock_simu + 3*s.spd3w < 5 THEN 'OG Minimal 5' ELSE 
      CASE
        WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stock_simu + 3*s.spd3w >= s.max_stock3w THEN 'OG ORI' 
        WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stock_simu + 3*s.spd3w < s.max_stock3w THEN 'OG ORI'
        ELSE 'OG Minimal 5'
      END
	END
WHERE s.stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// Generate rhh, rh1, ph2, ph3 from tbl_data_sap
$query = "
UPDATE dbdump.tbl_stock s
SET s.rhh_sat =
	CASE
		WHEN s.account = 'IDM' THEN 0 ELSE 
			(SELECT oo.rhhfinal 
			FROM
				(SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.rhh_sat :=
					CASE
						WHEN DATE_ADD(s.stockdate, INTERVAL 0 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
					END AS rhhfinal
				FROM dbdump.tbl_stock s, dbdump.tbl_data_sap o
				WHERE s.stockdate = '".$tgl[0]."' AND (o.bill_block = '' AND o.rejection_code = '') AND s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 0 DAY) = o.req_deliv_date
				GROUP BY s.sap_id) oo
			WHERE s.sap_id = oo.sap_id)
	END,
	s.rh1 =
		(SELECT oo.rh1final 
		FROM
			(SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.rh1 :=
				CASE
					WHEN DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
				END AS rh1final
			FROM dbdump.tbl_stock s, dbdump.tbl_data_sap o
			WHERE s.stockdate = '".$tgl[0]."' AND (o.bill_block = '' AND o.rejection_code = '') AND s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date
			GROUP BY s.sap_id) oo
		WHERE s.sap_id = oo.sap_id),
	s.ph2 =
		(SELECT oo.ph2final 
		FROM
			(SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.ph2 :=
				CASE
					WHEN DATE_ADD(s.stockdate, INTERVAL 2 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
				END AS ph2final
			FROM dbdump.tbl_stock s, dbdump.tbl_data_sap o
			WHERE s.stockdate = '".$tgl[0]."' AND o.rejection_code = '' AND s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 2 DAY) = o.req_deliv_date
			GROUP BY s.sap_id) oo
		WHERE s.sap_id = oo.sap_id),	
	s.ph3 =
		(SELECT oo.ph3final 
		FROM
			(SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.ph3 :=
				CASE
					WHEN DATE_ADD(s.stockdate, INTERVAL 3 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
				END AS ph3final
			FROM dbdump.tbl_stock s, dbdump.tbl_data_sap o
			WHERE s.stockdate = '".$tgl[0]."' AND o.rejection_code = '' AND s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 3 DAY) = o.req_deliv_date
			GROUP BY s.sap_id) oo
		WHERE s.sap_id = oo.sap_id)
WHERE s.stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// Generate stockdate0 for OOS
$query = "
UPDATE tbl_stock s
SET s.stockdate0 = 
	CASE
		WHEN s.account = 'IDM' THEN s.stock_simu ELSE 
			CASE 
				WHEN s.stock_simu + s.rhh_sat - s.spd3w < 0 THEN 0 ELSE s.stock_simu + s.rhh_sat - s.spd3w
			END
	END
WHERE s.stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// Generate OOS
$query = "
UPDATE tbl_stock s
SET s.oos =
	CASE 
		WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
			CASE
				WHEN s.stockdate0 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'YES'
				WHEN s.stockdate0 > 10 AND s.stockdate0 <= s.spd3w*3 + 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'Resiko OOS'
				ELSE 'NO'
			END
		WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
			CASE
				WHEN s.stockdate0 < 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'YES'
				WHEN s.stockdate0 > 5 AND s.stockdate0 <= s.spd3w*3 + 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'Resiko OOS' 
				ELSE 'NO'
			END
		WHEN s.brand = 'VIT' AND s.stockdate0 < 2 AND s.stockh_1 < 2 AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'YES'
		WHEN s.brand = 'VIT' AND s.stockdate0 <= spd3w*3 AND s.stockh_1 > 2 AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'Resiko OOS'
		ELSE 'NO'
	END
WHERE s.stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// Generate OG Urgent
$query = "
UPDATE tbl_stock s
SET s.og_urgent =
	CASE
		WHEN s.brand = 'AQUA' AND (s.oos = 'YES' OR s.oos = 'Resiko OOS') THEN 
			CASE
				WHEN s.spd3w < 0 THEN 5 ELSE 
					CASE
						WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
					END
			END
		WHEN s.brand = 'VIT' AND (s.oos = 'YES' OR s.oos = 'Resiko OOS') THEN 5 ELSE 0
	END
WHERE s.stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// Generate Estimation Stock
$query = "
UPDATE tbl_stock s
SET s.stockdate1 = 
	CASE
		WHEN s.stockdate0 + s.rh1 - s.spd3w < 0 THEN 0 ELSE s.stockdate0 + s.rh1 - s.spd3w
	END,
	s.stockdate2 =
	CASE
		WHEN s.stockdate1 + s.ph2 - s.spd3w < 0 THEN 0 ELSE s.stockdate1 + s.ph2 - s.spd3w
	END,
	s.stockdate3 = 
	CASE
		WHEN s.stockdate2 + s.ph3 - s.spd3w + s.og_urgent < 0 THEN 0 ELSE s.stockdate2 + s.ph3 - s.spd3w + s.og_urgent
	END,
	s.stockdate4 = 
	CASE
		WHEN s.stockdate3 + s.og_apollo - s.spd3w < 0 THEN 0 ELSE s.stockdate3 + s.og_apollo - s.spd3w
	END
WHERE s.stockdate = '".$tgl[0]."';
";
mysqli_query($con, $query);

// Logging Uploader User
$str="INSERT INTO tbl_log (user,total_rows,filename,upload) VALUES ('".$USER."','".$i."','".$filetitle."','stock')";
mysqli_query($con, $str);

}

echo "<script>location.replace('upload?ac=index');</script>";
?>

