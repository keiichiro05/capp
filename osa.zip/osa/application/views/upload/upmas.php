<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php

$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/upload/tab.php';

# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];

// $mDN = array("CMP" => "Complete");
// $str="SELECT * FROM tbm_dn_pending where reason_type = 'INV' or reason_type = 'LTG' order by reason_type";
// $result = mysqli_query($con, $str);
// while($row = mysqli_fetch_assoc($result)){ $mDN[$row['pdn_code']]=$row['description']; }


$DN=getPreValue("dn","");

$judul = "Check Master Customer";
// $otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload Bill Doc (ZFR2SD01106)</a>";
$otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload Master Customer</a>";
// DATA JWK
$otherMenu .= "<a href='upload?ac=sendDataJwk' id='jwkUploaderBtn'><i class='fa fa-upload'></i>Upload JWK</a>";
// DATA BWS
$otherMenu .= "<a href='upload?ac=sendDataBws' id='bwsUploaderBtn'><i class='fa fa-upload'></i>Upload BWS</a>";
// DATA Quadrant
$otherMenu .= "<a href='upload?ac=sendDataQuadrant' id='quadrantUploaderBtn'><i class='fa fa-upload'></i>Upload Quadrant</a>";
// DATA SAP
$otherMenu .= "<a href='upload?ac=sendDataSAP' id='sapUploaderBtn'><i class='fa fa-upload'></i>Upload Data SAP</a>";
// Data Truck Capacity
$otherMenu .= "<a href='upload?ac=sendDataTruck' id='truckCapacityUploaderBtn'><i class='fa fa-upload'></i>Upload Data Truck Capacity</a>";
// DATA FORECAST
$otherMenu .= "<a href='upload?ac=sendDataForecast' id='forecastUploaderBtn'><i class='fa fa-upload'></i>Upload Data Forecast</a>";
// DATA PKM
$otherMenu .= "<a href='upload?ac=sendDataPkm' id='pkmUploaderBtn'><i class='fa fa-upload'></i>Upload Data PKM</a>";
// $otherMenu .= "<input type='text' name='dn' id='txBarcode' placeholder='&#xf002; Cari DN' style='font-family:Arial, FontAwesome' autofocus onfocus='this.select();'>";
$otherMenu.= cariKey();

echo tableHeader($judul, $otherMenu);

// Handle MD Uploader
echo newUpload("fgFrm04","btn1","Upload Master Customer","upload?ac=send1");

// masalah uploader harus di buat dulu case nya di upload.php kayak logdeletion
// echo newUpload("popupJwk","jwkUploaderBtn","Upload Data JWK","upload?ac=sendDataJwk");
// echo newUpload("popupQuadrant","quadrantUploaderBtn","Upload Data Quadrant","upload?ac=sendDataQuadrant");
// echo newUpload("popupSap","sapUploaderBtn","Upload Data SAP","upload?ac=sendDataSAP");
// echo newUpload("popupTruck","truckCapacityUploaderBtn","Upload Data Truck Capacity","upload?ac=sendDataTruck");
// echo newUpload("popupForecast","forecastUploaderBtn","Upload Data Forecast","upload?ac=sendDataForecast");

// Handle SAP Uploader

// echo uploadFile("Upload Bill Doc","bseco?ac=send");
// echo uploadFile2("Upload Amount SAP","bseco?ac=send1");
$plant = $_SESSION['Customer Solution']['plant'];


// $str = "SELECT  tbl_stock.account, tbl_stock.outlet_id, tbl_stock.outlet_name as outlet, branch FROM tbl_stock LEFT JOIN
// tbl_store ON concat(tbl_stock.account,tbl_stock.outlet_id) = CONCAT(tbl_store.account,tbl_store.outlet_id)
// WHERE concat(tbl_stock.account,tbl_stock.outlet_id) NOT IN (select concat(account,outlet_id) FROM tbl_store) 
// GROUP BY account, outlet_id, outlet LIMIT 100";
$str = "SELECT  tbl_store_stock.account, tbl_store_stock.outlet_id, tbl_store_stock.outlet_name, tbl_store_stock.brand as brand
FROM tbl_store_stock WHERE concat(tbl_store_stock.account,tbl_store_stock.outlet_id,tbl_store_stock.brand) NOT IN (select concat(account,outlet_id,brand) FROM tbl_store)";
$result = mysqli_query($con, $str);
?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>


<i> Check Master Data </i>
<div class="row">
  <div class="col-lg-12" id="frameparent">
<table class="table-control" id="myTable">
        <thead>
          <tr>
            <th>Source</th>
            <th>Branch</th>
            <th>Outlet_id</th>
            <th>SAP_id</th>
            <th>Outlet_name</th>
            <th>Region</th>
            <th>Account</th>
            <th>Remark</th>
            <th>Supplier</th>
            <th>Region_sales</th>
            <th>Active (Y/N)</th>
            <th>Brand</th>
          </tr>
        </thead>
        <tbody>
          <?php while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td></td>
            <td></td>
            <td><?php echo $row['outlet_id']; ?></td>
            <td></td>
            <td><?php echo $row['outlet']; ?></td>
            <td></td>
            <td><?php echo $row['account']; ?></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td><?php echo $row['brand']; ?></td>
          </tr>
            <?php } ?>
        </tbody>
    </table> 
  </div>
  </div>

      <!-- <table class="table-control">
        <thead>
          <tr>
            <th>No</th>
            <th>Account</th>
            <th>Outlet ID</th>
            <th>Outlet Name</th>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><?php echo $i; ?></td>
            <td><?php echo $row['account']; ?></td>
            <td><?php echo $row['outlet_id']; ?></td>
            <td><?php echo $row['outlet']; ?></td>
          </tr>
          <?php $i++;} ?>
        </tbody>
    </table>  -->


 
