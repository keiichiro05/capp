<?php
/*
# Prject: billingtracker
# User  : Jefry (phoa.permana@danone.com)
# Auth  : DamarTeduh©2020
# Create: BOGOR | 2020-05-13 13:27
*/
switch($action){
	case 'index':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
	case 'masterstore':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
	case 'logdeletion':
		$navtop = 'navtop.php';
		$navside= 'navside.php';
		require 'master.php';
		break;
	case 'upmas':		# 20200125 10:37 AM, KOPI TUGOH BOGOR
		$navside= 'navside.php';
		$navtop = 'navtop.php';
		require 'master.php';
		break;
	case 'send1':
	case 'send':
	case 'sendDataJwk':
		$navtop = 'navtop.php';
		$navside= 'navside.php';
		require 'master.php';
		break;
	case 'sendDataBws':
		$navtop = 'navtop.php';
		$navside= 'navside.php';
		require 'master.php';
		break;
	case 'sendDataQuadrant':
		$navtop = 'navtop.php';
		$navside= 'navside.php';
		require 'master.php';
		break;
	case 'sendDataSAP':
		$navtop = 'navtop.php';
		$navside= 'navside.php';
		require 'master.php';
		break;
	case 'sendDataTruck':
		$navtop = 'navtop.php';
		$navside= 'navside.php';
		require 'master.php';
		break;
	case 'sendDataForecast':
		$navtop = 'navtop.php';
		$navside= 'navside.php';
		require 'master.php';
		break;
	case 'sendDataPkm':
		$navtop = 'navtop.php';
		$navside= 'navside.php';
		require 'master.php';
		break;
	require 'master.php';
		break;
}
?>