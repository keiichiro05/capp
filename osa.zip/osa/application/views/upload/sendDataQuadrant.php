<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
}

</style>

<?php
$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';

$judul = "UPLOAD ";
// $otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload Data JWK</a>";

function newUploadQuadrant($id,$btn,$judul,$action){
	$kode = '<div style="position: relative; top: 50%; -webkit-transform: translateY(50%); -ms-transform: translateY(50%); transform: translateY(50%);  border-style: double; width: 50%; margin: auto auto" id="'.$id.'"><div id=""><h1 style="margin-left: 30%; " class=""> '.$judul.'</h1></div><div id=""><form style="margin-left: 40%; " action="'.$action.'" method="POST" name="'.$id.'" enctype="multipart/form-data"><div class="dt-form-group"><br><label>Select File (txt)</label><br><input type="file" name="cFile" required></div><div class="dt-form-group"><label></label><br><button type="submit" name="submit" >Submit</button> <button id="cmdCancel">Cancel</button></div></form><br></div></div><div id="bgFrm01"></div><br>';
	$kode .= '<script type="text/javascript">$(document).ready(function(){$("#'.$btn.'").click(function(){ fg_popup_form("'.$id.'","frmInner","bgFrm01","100"); }); $("#cmdCancel").click(function(){ fg_hideform("'.$id.'","bgFrm01"); }); }); </script>';
	return $kode;
}

// echo newUpload("fgFrm04","btn1","Upload Data Otif","/data-otif-upload/upload/send.php");
echo newUploadQuadrant("","btn1","Upload Data Quadrant","");

if (isset($_SESSION['successfullUpload']) and ($_SESSION['successfullUpload'] == true)) {
  echo '<h2 style="color: blue; text-align: center; align-items: center; padding-top: 80px;">Upload Berhasil!</h2>'; 
  $_SESSION['successfullUpload'] = false;
}

if (isset($_POST['submit'])) {
  $filetitle = $_FILES['cFile']['name'];

  if(!empty($_FILES['cFile']['name'])){
    $filename = $_FILES['cFile']['tmp_name'];
    $fileinfo = pathinfo($_FILES['cFile']['name']);

    //check if file contains data
    $delimiter = ",";
    $delimiterb = ",";
    $file = fopen($filename, 'r');
    $fileb = fopen($filename, 'r');
    $firstLine = fgets($file);
    $i=0;

    if(strpos($firstLine, ";") != FALSE) $delimiter=";";    
    if (($impData = fgets($file)) != FALSE){
      $lines = file($filename);

      $query = "
      TRUNCATE TABLE tbl_quadrant;
      ";
      mysqli_query($con, $query);

      for ($i = 1; $i < count($lines); $i++) {
        $namaKolom = explode("\t", $lines[$i]);
        // print_r($namaKolom);
        if (isset($namaKolom[0])) {
        // stlh pre processing
          $query = "
          REPLACE INTO tbl_quadrant (outlet_id, `account`, brand, quadrant)
          VALUES ('".((!$namaKolom[0]) ? 'NULL' : $namaKolom[0])."', 
                  '".((!$namaKolom[1]) ? 'NULL' : $namaKolom[1])."',
                  '".((!$namaKolom[2]) ? 'NULL' : $namaKolom[2])."',
                  '".((!$namaKolom[3]) ? 'NULL' : $namaKolom[3])."')
          ";
          mysqli_query($con, $query);
        }    
      }
      $query = "
      UPDATE tbl_quadrant
      SET quadrant = TRIM(quadrant)
      ";
      mysqli_query($con, $query);

      $query = "
      UPDATE tbl_store t, tbl_quadrant q
      SET t.quadrant = q.quadrant
      WHERE t.outlet_id = q.outlet_id AND t.`account` = q.`account`;
      ";
      mysqli_query($con, $query);   
      
      $_SESSION['successfullUpload'] = true;
    }
  }
  echo "<script>location.replace('upload?ac=sendDataQuadrant');</script>";
}