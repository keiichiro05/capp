<?php
/*
# Prject: BWG Project 1.0
# Auth  : DamarTeduh©2019
# Create: Taman Dayu | 2019-11-21 19:53
*/

$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];


//check if input file is empty
$err="";
print_r($_FILES);
// exit;

$filetitle = $_FILES['cFile']['name'];

if(!empty($_FILES['cFile']['name'])){
  $filename = $_FILES['cFile']['tmp_name'];
  $fileinfo = pathinfo($_FILES['cFile']['name']);

  //check file extension
  // if(strtolower($fileinfo['extension']) == 'csv' AND $_FILES['files']['size'] > 0){
    //check if file contains data
  $delimiter = ",";
  $delimiterb = ",";
  $file = fopen($filename, 'r');
  $fileb = fopen($filename, 'r');
  $firstLine = fgets($file);
  $tgl2 = fgetcsv($fileb, 200, $delimiterb);
  $tgl = fgetcsv($fileb, 200, $delimiterb);
  $i=0;
    

  if(strpos($firstLine, ";") != FALSE) $delimiter=";";    
  $values = '';
    
  while(($impData = fgetcsv($file, 200, $delimiter)) != FALSE){
      $sellout = isset($impData[6])?$impData[6]:0;
      if(strlen(trim($impData[5])) <= 0 )
        { $stock = 0; } 
      else { $stock= $impData[5]; }
      $outlet = trim($impData[3]);

      if($i++ != 0) { $values .= ',' ;}
      $value = '(' . '"' . trim($impData[0]) . '"' .  ',' .  '"' . trim($impData[1]) .  '"' . ',' .  '"' . trim($impData[2]) .  '"' . ',' .  '"' . $outlet .  '"' . ',' .  '"' . trim($impData[4]) .  '"' . ',' .  '"' . trim($impData[5]) .  '"' . ',' .  '"' . $stock .  '"' . ',' .  '"' . $sellout .  '"' . ',' .  '"' . '0' .  '"' . ',' .  '"' . date("Y-m-d H:i:s") .  '"' . ',' .  '"' . trim($impData[7]) .  '"' . ',' . '"' .   $stock .  '"' . ')';
      $values .= $value; 
      $i++;
  }

  $query = "REPLACE INTO tbl_stock (stockdate, account, dc_name, outlet_id, outlet_name, stockc, stock, sellout, stockh_1,upload_date,brand, stock_simu) VALUES $values ";
  mysqli_query($con,$query);

  // Logging Uploader User
  $str="INSERT INTO tbl_log (user,total_rows,filename,upload) VALUES ('".$USER."','".$i."','".$filetitle."','stock')";
  mysqli_query($con, $str);

}

echo "<script>location.replace('upload?ac=index');</script>";
?>

