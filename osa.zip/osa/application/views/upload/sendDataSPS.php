<?php

$execution_time_limit = 1200;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];

$filetitle = $_FILES['cFile']['name'];

if(!empty($_FILES['cFile']['name'])) {
    $filename = $_FILES['cFile']['tmp_name'];
    $fileinfo = pathinfo($_FILES['cFile']['name']);
    $i = 0;

    $delimiter = ",";
    $file = fopen($filename, 'r');
    $firstLine = fgets($file);
    if(strpos($firstLine, ";") != FALSE) $delimiter=";";
    while(($impData = fgetcsv($file, 200, $delimiter)) != FALSE) {
        $query = "REPLACE INTO tbl_sps (`year`,`month`,`date`,account, branch, cust_id, store_name, sku, stock_qty, stock_rp, sales_qty, sales_rp)
        VALUES ('".$impData[0]."','".$impData[1]."','".$impData[2]."','".$impData[3]."','".$impData[4]."','".$impData[5]."','".$impData[6]."','".$impData[7]."','".$impData[8]."','".$impData[9]."','".$impData[10]."','".$impData[11]."')";
        $result = mysqli_query($con_176, $query);
        $i++;
    }
    $str = "INSERT INTO tbl_log (user,total_rows,filename,upload) VALUES ('".$USER."','".$i."','".$filetitle."','sps')";
    $log = mysqli_query($con_176, $str);
    if ($log) echo "Log Done";
    else echo "Log Error";
}

echo "<script>location.replace('upload?ac=up_sps');</script>";

?>