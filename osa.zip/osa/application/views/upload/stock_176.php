<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php

include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/upload/tab.php';

# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];

// $mDN = array("CMP" => "Complete");
// $str="SELECT * FROM tbm_dn_pending where reason_type = 'INV' or reason_type = 'LTG' order by reason_type";
// $result = mysqli_query($con, $str);
// while($row = mysqli_fetch_assoc($result)){ $mDN[$row['pdn_code']]=$row['description']; }


$DN=getPreValue("dn","");

$judul = "Stock 176";
$otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload Stock B2B</a>";
// $otherMenu .= "<a href='#' id='btn2'><i class='fa fa-upload'></i>Upload Amount (FBL5N)</a>";
// $otherMenu .= "<input type='text' name='dn' id='txBarcode' placeholder='&#xf002; Cari DN' style='font-family:Arial, FontAwesome' autofocus onfocus='this.select();'>";
$otherMenu.= cariKey();

echo tableHeader($judul, $otherMenu);


echo newUpload("fgFrm04","btn1","Upload Stock B2B","upload?ac=sendDataStock176");
// echo uploadFile("Upload Bill Doc","bseco?ac=send");
// echo uploadFile2("Upload Amount SAP","bseco?ac=send1");
$str = "SELECT seq, user, total_rows, upload_date, filename  FROM tbl_log WHERE upload = 'b2b' GROUP BY upload_date order by seq desc";
$result = mysqli_query($con_176, $str);
?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>



<i> Data Log Upload B2B Server 176</i>
<div class="row">
  <div class="col-lg-12" id="frameparent">
      <table class="table-control" id="myTable">
        <thead>
          <tr>
            <th>No</th>
            <th>user</th>
            <th>total_row</th>
            <th>Upload Date</th>
            <th>File Name</th>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><?php echo $i; ?></td>
            <td><?php echo $row['user']; ?></td>
            <td><?php echo $row['total_rows']; ?> Rows</td>
            <td><?php echo $row['upload_date']; ?></td>
            <td><?php echo $row['filename']; ?></td>
          </tr>
          <?php $i++;} ?>
        </tbody>
    </table> 
  </div>
 </div>
