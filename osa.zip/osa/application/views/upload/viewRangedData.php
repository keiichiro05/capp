<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php

include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/upload/tab.php';

# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];

// $mDN = array("CMP" => "Complete");
// $str="SELECT * FROM tbm_dn_pending where reason_type = 'INV' or reason_type = 'LTG' order by reason_type";
// $result = mysqli_query($con, $str);
// while($row = mysqli_fetch_assoc($result)){ $mDN[$row['pdn_code']]=$row['description']; }


$DN=getPreValue("dn","");

$judul = "View Ranged Data";
$otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i></a>";
// $otherMenu .= "<a href='#' id='btn2'><i class='fa fa-upload'></i>Upload Amount (FBL5N)</a>";
// $otherMenu .= "<input type='text' name='dn' id='txBarcode' placeholder='&#xf002; Cari DN' style='font-family:Arial, FontAwesome' autofocus onfocus='this.select();'>";
$otherMenu.= cariKey();

echo tableHeader($judul, $otherMenu);

echo '<h2>Ranged Data</h2>';

echo '
        <html><head>
        <link href="css/jquery.tablesorter.min.css" rel="stylesheet">
        <!-- Pop Up form -->
        <script src="js/popup.form.js" type="text/javascript"></script>
        <link href="css/popup.form.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script>
        $(function() {
            $("#startdate").datepicker();
            $("#enddate").datepicker();
        });
        </script>
        </head>
        <body>
        <form action="#" method="post">
        <input type="submit" name="downloadAllSPS" id="downloadAllSPS" value="Download All SPS Data"/>
        <input type="submit" name="downloadDataOGAccuracy" id="downloadDataOGAccuracy" value="Download All OG Accuracy Data"/>
        <h2>Data</h2>
            <select name="data">
            <option value="sps">Data SPS</option>
            <option value="stock">Data Stock 176</option>
            </select>
        <br>
        <br>
        <p>Start Date: <input type="text" name="startdate" id="startdate" value=' . (isset($_POST['startdate']) ? $_POST['startdate'] : '') . '></p>
        <p>End Date: <input type="text" name = "enddate" id="enddate" value='. (isset($_POST['enddate']) ? $_POST['enddate'] : '') .'></p>
        <input type="submit" name="getdata" id="getdata" value="Get Data"/>
        </form></body></html>';

// echo uploadFile("Upload Bill Doc","bseco?ac=send");
// echo uploadFile2("Upload Amount SAP","bseco?ac=send1");
?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>

<?php
        if (isset($_POST['downloadAllSPS'])) {
            echo "<script>location.replace('unduh_csv?ac=downloadDataSPS176');</script>";
        };
        if (isset($_POST['downloadDataOGAccuracy'])) {
            echo "<script>location.replace('unduh_csv?ac=downloadDataOGAccuracy');</script>";
        };
        if (isset($_POST['getdata'])) {
            if (isset($_POST['startdate']) && isset($_POST['enddate']) && isset($_POST['data'])) {
                $startdate = $_POST['startdate'];
                $enddate = $_POST['enddate'];
                $startdate = date('Y-m-d', strtotime($startdate));
                $enddate = date('Y-m-d', strtotime($enddate));
                var_dump($startdate);
                var_dump($enddate);
                if (isset($_POST['data']) == 'stock') {
                    $strStock176 = "SELECT source_name, account, branch, supplier_name, po_number, po_date, po_expired, product_name, qty, `value`, `week`, `month`, `year`, source, so_farmindo, so_sap, remark, sales_region FROM tbl_stock WHERE po_date BETWEEN '$startdate' AND '$enddate'";
                    $resultStock176 = mysqli_query($con_176, $strStock176);
                    echo "
                    <div class='row'>
                    <div class='col-lg-12' id='frameparent'>
                        <table class='table-control' id='myTable'>
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Source Name</th>
                                <th>Account</th>
                                <th>Branch</th>
                                <th>Supplier Name</th>
                                <th>PO Number</th>
                                <th>PO Date</th>
                                <th>PO Expired</th>
                                <th>Product Name</th>
                                <th>Qty</th>
                                <th>Value</th>
                                <th>Week</th>
                                <th>Month</th>
                                <th>Year</th>
                                <th>Source</th>
                                <th>SO Farmindo</th>
                                <th>SO SAP</th>
                                <th>Remark</th>
                                <th>Sales Region</th>
                            </tr>
                            </thead>
                            <tbody>";
                    $i=1; 
                    while($row = mysqli_fetch_assoc($resultStock176)) {
                            echo "<tr class='cari'>";
                            echo "<td>$i</td>";
                            echo "<td>".$row['source_name']."</td>";
                            echo "<td>".$row['account']."</td>";
                            echo "<td>".$row['branch']."</td>";
                            echo "<td>".$row['supplier_name']."</td>";
                            echo "<td>".$row['po_number']."</td>";
                            echo "<td>".$row['po_date']."</td>";
                            echo "<td>".$row['po_expired']."</td>";
                            echo "<td>".$row['product_name']."</td>";
                            echo "<td>".$row['qty']."</td>";
                            echo "<td>".$row['value']."</td>";
                            echo "<td>".$row['week']."</td>";
                            echo "<td>".$row['month']."</td>";
                            echo "<td>".$row['year']."</td>";
                            echo "<td>".$row['source']."</td>";
                            echo "<td>".$row['so_farmindo']."</td>";
                            echo "<td>".$row['so_sap']."</td>";
                            echo "<td>".$row['remark']."</td>";
                            echo "<td>".$row['sales_region']."</td>";
                            echo "</tr>";
                            $i+=1;
                    }
                }
                if (isset($_POST['data']) == 'sps') {
                    $strSPS = "SELECT `year`,`month`,`date`,account, branch, cust_id, store_name, sku, stock_qty, stock_rp, sales_qty, sales_rp FROM tbl_sps WHERE `date` BETWEEN '$startdate' AND '$enddate' LIMIT 1000";
                    $resultSPS = mysqli_query($con_176, $strSPS);
                    echo "
                    <div class='row'>
                    <div class='col-lg-12' id='frameparent'>
                        <table class='table-control' id='myTable'>
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Year</th>
                                <th>Month</th>
                                <th>Date</th>
                                <th>Account</th>
                                <th>Branch</th>
                                <th>Cust ID</th>
                                <th>Store Name</th>
                                <th>SKU</th>
                                <th>Stock (qty)</th>
                                <th>Stock (rp)</th>
                                <th>Sales (qty)</th>
                                <th>Sales (rp)</th>
                            </tr>
                            </thead>
                            <tbody>";
                    $i=1; 
                    while($row = mysqli_fetch_assoc($resultSPS)) {
                            echo "<tr class='cari'>";
                            echo "<td>$i</td>";
                            echo "<td>".$row['year']."</td>";
                            echo "<td>".$row['month']."</td>";
                            echo "<td>".$row['date']."</td>";
                            echo "<td>".$row['account']."</td>";
                            echo "<td>".$row['branch']."</td>";
                            echo "<td>".$row['cust_id']."</td>";
                            echo "<td>".$row['store_name']."</td>";
                            echo "<td>".$row['sku']."</td>";
                            echo "<td>".$row['stock_qty']."</td>";
                            echo "<td>".$row['stock_rp']."</td>";
                            echo "<td>".$row['sales_qty']."</td>";
                            echo "<td>".$row['sales_rp']."</td>";
                            echo "</tr>";
                            $i+=1;
                    }
                }
            }
            echo "
                    </tbody>
                </table> 
            </div>
            </div>";
        }