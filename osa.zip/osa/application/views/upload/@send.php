<?php
/*
# Prject: BWG Project 1.0
# Auth  : DamarTeduh©2019
# Create: Taman Dayu | 2019-11-21 19:53
*/

$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];


//check if input file is empty
$err="";
// print_r($_FILES);
// exit;

if(!empty($_FILES['cFile']['name'])){
  $filename = $_FILES['cFile']['tmp_name'];
  $fileinfo = pathinfo($_FILES['cFile']['name']);

  //check file extension
  // if(strtolower($fileinfo['extension']) == 'csv' AND $_FILES['files']['size'] > 0){
    //check if file contains data
    $delimiter = ",";
    $file = fopen($filename, 'r');
    $firstLine = fgets($file);
    $tgl = fgetcsv($file, 200, $delimiter);
    $i=0;
    if(strpos($firstLine, ";") != FALSE) $delimiter=";";    
    while(($impData = fgetcsv($file, 200, $delimiter)) != FALSE){
        $sellout = isset($impData[6])?$impData[6]:0;
        $outlet = trim($impData[3]);
        $query = "REPLACE INTO tbl_stock (stockdate, account, dc_name, outlet_id, outlet_name, stockc, stock, sellout, stockh_1,upload_date) VALUES ('".$impData[0]."','".$impData[1]."','".$impData[2]."','".$outlet."','".$impData[4]."','".$impData[5]."','".$impData[5]."','".$sellout."',0,'".date("Y-m-d H:i:s")."')"; 
        mysqli_query($con,$query);
        $query = "UPDATE tbl_stock SET 
         stockh_1 = (SELECT (CASE WHEN stock_simu is null THEN 0 ELSE stock_simu END) from 
         (SELECT stock_simu from tbl_stock WHERE stockdate = DATE_ADD('".$impData[0]."', INTERVAL -1 DAY) AND account = '".$impData[1]."' AND outlet_id = '".$outlet."') as b)  WHERE stockdate= '".$impData[0]."' AND account = '".$impData[1]."' AND outlet_id = '".$outlet."'";
         mysqli_query($con,$query);
       $query = "UPDATE tbl_stock SET 
         stockh_2 = (SELECT (CASE WHEN stock_simu is null THEN 0 ELSE stock_simu END) from 
         (SELECT stock_simu from tbl_stock WHERE stockdate = DATE_ADD('".$impData[0]."', INTERVAL -2 DAY) AND account = '".$impData[1]."' AND outlet_id = '".$outlet."') as b)  WHERE stockdate= '".$impData[0]."' AND account = '".$impData[1]."' AND outlet_id = '".$outlet."'";
        mysqli_query($con,$query);
        $query = "UPDATE tbl_stock SET sap_id = (SELECT sap_id from tbl_store WHERE account = '".$impData[1]."' AND outlet_id = '".$outlet."') WHERE stockdate= '".$impData[0]."' AND account = '".$impData[1]."' AND outlet_id = '".$outlet."'";
        mysqli_query($con,$query);
        $query = "UPDATE tbl_stock SET act_real = (SELECT 
        (CASE WHEN do_qty is null THEN 0 ELSE do_qty END) from tbl_realisasi WHERE account = '".$impData[1]."' AND outlet_id = '".$outlet."' AND do_date = '".$impData[0]."') WHERE stockdate= '".$impData[0]."' AND account = '".$impData[1]."' AND outlet_id = '".$outlet."'";
        mysqli_query($con,$query);
        $i++;
    }


$str="UPDATE tbl_stock SET act_real = 0 WHERE act_real is null";
mysqli_query($con, $str);

$str="UPDATE tbl_stock SET code1 = (CASE WHEN stockc = '' THEN 'B' WHEN CAST(stockc as SIGNED) <= 0 THEN 'K' WHEN CAST(stockc as SIGNED) > 0 THEN 'N' END), 
code2= (CASE WHEN act_real = 0 THEN 'N' ELSE 'Y' END),code3= (CASE WHEN stockh_1 <= 0 THEN 'K' ELSE 'N' END) WHERE stockdate ='".$tgl[0]."'";
mysqli_query($con, $str);


$str="UPDATE tbl_stock SET stock_simu = 
(CASE 
  WHEN code1 = 'K'  AND code2 = 'Y' AND code3 = 'N' THEN act_real+stockh_1-sellout
  WHEN code1 = 'B'  AND code2 = 'Y' AND code3 = 'N' THEN act_real+stockh_1-sellout 
  WHEN code1 = 'N'  AND code2 = 'Y' AND code3 = 'N' THEN act_real+stockh_1-sellout
  WHEN code1 = 'N'  AND code2 = 'N' AND code3 = 'N' THEN stock-sellout
  WHEN code1 = 'N'  AND code2 = 'N' AND code3 = 'K' THEN stock-sellout
  WHEN code1 = 'K'  AND code2 = 'Y' AND code3 = 'K' THEN act_real-sellout 
  WHEN code1 = 'N'  AND code2 = 'Y' AND code3 = 'K' THEN act_real-sellout 
  WHEN code1 = 'B'  AND code2 = 'Y' AND code3 = 'K' THEN act_real-sellout
  WHEN code1 = 'B'  AND code2 = 'N' AND code3 = 'N' THEN stockh_1-sellout 
  WHEN code1 = 'K'  AND code2 = 'N' AND code3 = 'N' THEN stockh_1-sellout
  WHEN code1 = 'K'  AND code2 = 'N' AND code3 = 'K' THEN stockh_1-sellout
  WHEN code1 = 'B'  AND code2 = 'N' AND code3 = 'K' THEN stockh_1-sellout 
  END) WHERE stockdate ='".$tgl[0]."'";
mysqli_query($con, $str);

$str="UPDATE tbl_stock SET stock_simu = stock WHERE (stock_simu < stock or stock_simu is null) AND stockdate = '".$tgl[0]."'";
mysqli_query($con, $str);

$str="UPDATE tbl_stock SET osa = (CASE WHEN stock_simu > 4 THEN 1 ELSE 0 END) WHERE stockdate  = '".$tgl[0]."'";
mysqli_query($con, $str);
}


$str="INSERT INTO tbl_log (user,total_rows,upload) VALUES ('".$USER."','".$i."','stock')";
$result=mysqli_query($con, $str);

echo "<script>location.replace('upload?ac=index');</script>";
?>

