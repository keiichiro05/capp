<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
} 

</style>

<?php
$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
// include APP_DIR.'/views/upload/tab.php';

# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];

$str = "SELECT tahun,minggu from tbl_store_status GROUP BY tahun,minggu order by minggu";
$result = mysqli_query($con,$str);
while($row=mysqli_fetch_assoc($result)){
  $mWk[$row['minggu']]=$row['minggu'];
  $mThn[$row['tahun']]=$row['tahun'];
}

$fieldWk  = getPreValue("cmdWk",key($mWk));
$fieldYr  = getPreValue("cmdYr",key($mThn));

$judul = "Upload Store Status";
$otherMenu= "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload Store Status</a>";
$otherMenu.= cmbBox("cmdWk","","cmdWk",$fieldWk,$mWk,"");
$otherMenu.= cmbBox("cmdYr","","cmdYr",$fieldYr,$mThn,"");
$otherMenu.= "<button type='submit' name='submit' >Submit</button>  &nbsp;";
$otherMenu.= cariKey();
echo tableHeader($judul, $otherMenu);


echo newUpload("fgFrm04","btn1","Upload Store Status","bseco?ac=send");


$str = "SELECT source, branch, outlet_id, sap_id, account, tahun, minggu, `status`, brand FROM tbl_store_status st WHERE tahun = '$fieldYr' AND minggu = '$fieldWk' ORDER BY `status` ";
$result = mysqli_query($con, $str);
?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>


<i> Check Store Status </i>
<div class="row">
  <div class="col-lg-12" id="frameparent">
<table class="table-control" id="myTable">
        <thead>
          <tr>
            <th>Source</th>
            <th>Branch</th>
            <th>Outlet_id</th>
            <th>SAP_id</th>
            <th>Account</th>
            <th>Tahun</th>
            <th>Minggu</th>
            <th>Status</th>
            <th>Brand</th>
          </tr>
        </thead>
        <tbody>
          <?php while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><?php echo $row['source']; ?></td>
            <td><?php echo $row['branch']; ?></td>
            <td><?php echo $row['outlet_id']; ?></td>
            <td><?php echo $row['sap_id']; ?></td>
            <td><?php echo $row['account']; ?></td>
            <td><?php echo $row['tahun']; ?></td>
            <td><?php echo $row['minggu']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['brand']; ?></td>
            <td></td>
          </tr>
            <?php } ?>
        </tbody>
    </table> 
  </div>
  </div>

 
