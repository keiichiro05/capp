<?php

$execution_time_limit = 1200;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];

$filetitle = $_FILES['cFile']['name'];

if(!empty($_FILES['cFile']['name'])) {
    $filename = $_FILES['cFile']['tmp_name'];
    $fileinfo = pathinfo($_FILES['cFile']['name']);
    $i = 0;

    $delimiter = ",";
    $file = fopen($filename, 'r');
    $firstLine = fgets($file);
    if(strpos($firstLine, ";") != FALSE) $delimiter=";";
    while(($impData = fgetcsv($file, 200, $delimiter)) != FALSE) {
        if (strlen($impData[0]) > 25) {
            $impData[7] = mysqli_real_escape_string($con_176, $impData[7]);
            $query = "INSERT INTO tbl_stock (source_name,`account`,branch,supplier_name,po_number,po_date,po_expired,product_name,qty,`value`,`week`,`month`,`year`,source,so_farmindo,so_sap,remark,sales_region)
            VALUES ('".$impData[0]."','".$impData[1]."','".$impData[2]."',
            '".$impData[3]."','".$impData[4]."','".$impData[5]."',
            '".$impData[6]."','".$impData[7]."','".$impData[8]."',
            '".$impData[9]."','".$impData[10]."','".$impData[11]."',
            '".$impData[12]."','".$impData[13]."','".$impData[14]."',
            '".$impData[15]."','".$impData[16]."','".$impData[17]."')";
            echo $impData[0];
            echo $impData[7];
            echo $impData[17];
            echo $i;
            echo '<br>';
            $result = mysqli_query($con_176, $query);
            $i++;
        } 
    }
    $str = "INSERT INTO tbl_log (user,total_rows,filename,upload) VALUES ('".$USER."','".$i."','".$filetitle."','b2b')";
    $log = mysqli_query($con_176, $str);
    if ($log) echo "Log Done";
    else echo "Log Error";
}

// echo "<script>location.replace('upload?ac=stock_176');</script>";

?>