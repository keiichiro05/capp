<?php
$execution_time_limit = 36000;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/upload/tab.php';

if(isset($_POST['submit_all_data']))
{
  echo "<script>location.replace('unduh_csv?ac=downloadDataStore');</script>";
}

if(isset($_POST['export_data'])){
  $result = mysqli_query($con, "SELECT source,branch, outlet_id, sap_id, outlet_name, quadrant, region, account, remark, supplier, jwk,bws,region_sales, active, brand  FROM tbl_store");

  header("Content-Type: application/force-download");
  header("Content-Type: application/octet-stream");
  header("Content-Type: application/download");
  header("Content-Disposition: attachment;filename=\"export_table.csv\"");
  header("Content-Transfer-Encoding: binary");
  header("Pragma: public");
  header("Expires: 0");
  header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate, post-check=0, pre-check=0");
  header("Cache-Control: private",false);
  ob_end_flush();
  $output = fopen('php://output', 'w');
  
      fputcsv($output, array('source','branch', 'outlet_id', 'sap_id', 'outlet_name', 'quadrant', 'region', 'account', 'remark', 'supplier', 'jwk','bws','region_sales', 'active', 'brand'));
  
  while ($row = mysqli_fetch_assoc($result))
  {
  fputcsv($output, $row);
  }
  
  fclose($output);
  mysqli_free_result($result);
}
?>

<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php
# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];


$DN=getPreValue("dn","");

$judul = "List Master Customer";
$otherMenu = "";
$otherMenu .= cariKey();
$otherMenu .= "<a class='tab-menu' href='upload?ac=logdeletion'>Check Log Deletion</a>";

echo tableHeader($judul, $otherMenu);

$plant = $_SESSION['Customer Solution']['plant'];

if (isset($_POST['dataToko'])) {
  
  $dataToko = (explode(';', $_POST['dataToko'][0]));
  $kodeToko = $dataToko[0];
  $sapId = $dataToko[1];
  $outletName = $dataToko[2];
  $account = $dataToko[3];
  $brand = $dataToko[4];

  $str = "
  DELETE FROM tbl_store
  WHERE outlet_id = '".$kodeToko."' AND account = '".$account."' AND brand = '".$brand."'
  ";
  mysqli_query($con, $str);

  $str = "
  INSERT INTO tbl_log_deletion (user, outlet_id, sap_id, outlet_name, account, brand)
  VALUES ('".$USER."', '".$kodeToko."', '".$sapId."', '".$outletName."', '".$account."', '".$brand."')
  ";
  mysqli_query($con, $str);

  echo "<script>location.replace('upload?ac=masterstore');</script>";
}

?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>

<i> Filter Data Master Customer </i>
<form method="POST" >
  <select id="cmbAccount" name="Account"     onchange="document.getElementById('selected_text').value=this.options[this.selectedIndex].text">
    <option value=""></option>
    <option value="IDM">IDM</option>
    <option value="SAT">SAT</option>
    <option value="MIDI">MIDI</option>
    <option value="TBC">TBC</option>
  </select>
  <select id="cmbBrand" name="Brand"     onchange="document.getElementById('selected_text2').value=this.options[this.selectedIndex].text">
    <option value=""></option>
    <option value="AQUA">AQUA</option>
    <option value="VIT">VIT</option>
  </select>
  <input type="hidden" name="selected_text" id="selected_text" value="" />
  <input type="hidden" name="selected_text2" id="selected_text2" value="" />
  <input type="submit" name="submit_master" value="Submit"/>
  <input type="submit" name="export_data" value="Download"/>
  <input type="submit" name="submit_all_data" value="All Data"/>

</form>

<br/>
<i> List Master Customer for account :  <?php if(isset($_POST['submit_master'])) { $account= mysqli_real_escape_string($con, $_POST['selected_text']); echo $account;} ?> and brand : <?php if(isset($_POST['submit_master'])) { $brand= mysqli_real_escape_string($con, $_POST['selected_text2']); echo $brand;} ?></i>
<?php
if(isset($_POST['submit_master']))
{

    $makerAccount = $_POST['Account']; // account value
    $makerAccount = $_POST['Brand']; // brand value

    $account = mysqli_real_escape_string($con, $_POST['selected_text']); // get the selected text
    $brand = mysqli_real_escape_string($con, $_POST['selected_text2']);

    $str = "SELECT * FROM tbl_store WHERE account = '$account' AND brand = '$brand';";
    $result = mysqli_query($con, $str);
    
}
 ?>
<br/>



<div class="row">
  <div class="col-lg-12" id="frameparent">
    <table class="table-control" id="myTable">
        <thead>
          <tr>
            <th></th>
            <th>Source</th>
            <th>Branch</th>
            <th>Outlet_id</th>
            <th>SAP_id</th>
            <th>Outlet_name</th>
            <th>Quadrant</th>
            <th>Region</th>
            <th>Account</th>
            <th>Remark</th>
            <th>Supplier</th>
            <th>JWK</th>
            <th>BWS</th>
            <th>Region_sales</th>
            <th>Active (Y/N)</th>
            <th>Brand</th>
          </tr>
        </thead>
        <tbody>
          <?php 
          if(isset($_POST['submit_master'])){
          while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><form onSubmit="return confirm('Yakin ingin hapus?')" method="POST"><button class='btnDelete' style="background-color: red; color: white;" type='submit' name='dataToko[]' value='<?php echo $row['outlet_id'].';'.$row['sap_id'].';'.$row['outlet_name'].';'.$row['account'].';'.$row['brand']  ?>'>Delete</button></form></td>
            <td><?php echo $row['source']; ?></td>
            <td><?php echo $row['branch']; ?></td>
            <td><?php echo $row['outlet_id']; ?></td>
            <td><?php echo $row['sap_id']; ?></td>
            <td><?php echo $row['outlet_name']; ?></td>
            <td><?php echo $row['quadrant']; ?></td>
            <td><?php echo $row['region']; ?></td>
            <td><?php echo $row['account']; ?></td>
            <td><?php echo $row['remark']; ?></td>
            <td><?php echo $row['supplier']; ?></td>
            <td><?php echo $row['jwk']; ?></td>
            <td><?php echo $row['bws']; ?></td>
            <td><?php echo $row['region_sales']; ?></td>
            <td><?php echo $row['active']; ?></td>
            <td><?php echo $row['brand']; ?></td>
          </tr>
            <?php } }?>
        </tbody>
      </table> 
    </div>
  </div>



 
