<?php
/*
# Prject: BWG Project 1.0
# Auth  : DamarTeduh©2019
# Create: Taman Dayu | 2019-11-21 19:53
*/

$execution_time_limit = 1200;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];

//check if input file is empty
$err="";
// print_r($_FILES);
// exit;

// Notification Success: 19 April 2022
if (isset($_SESSION['successfullUpload']) and ($_SESSION['successfullUpload'] == true)) {
  echo '<h2 style="color: blue; text-align: center; align-items: center; padding-top: 80px;">Upload Berhasil!</h2>'; 
  $_SESSION['successfullUpload'] = false;
}

if(!empty($_FILES['cFile']['name'])){
  $filename = $_FILES['cFile']['tmp_name'];
  $fileinfo = pathinfo($_FILES['cFile']['name']);

  //check file extension
  // if(strtolower($fileinfo['extension']) == 'csv' AND $_FILES['files']['size'] > 0){
    //check if file contains data
  $delimiter = ",";
  $file = fopen($filename, 'r');
  $firstLine = fgets($file);
  if(strpos($firstLine, ";") != FALSE) $delimiter=";";    
  while(($impData = fgetcsv($file, 200, $delimiter)) != FALSE){
      $outlet = trim($impData[2]);
      $query = "REPLACE INTO tbl_store (source, branch, outlet_id, sap_id, outlet_name, region, account, remark, supplier, region_sales, active, brand) VALUES ('".$impData[0]."','".$impData[1]."','".$outlet."','".$impData[3]."','".$impData[4]."','".$impData[5]."','".$impData[6]."','".$impData[7]."','".$impData[8]."','".$impData[9]."','".$impData[10]."','".$impData[11]."')"; 
      mysqli_query($con,$query);

  if (strlen($impData[3]>2)) {
    $query = "UPDATE tbl_realisasi SET outlet_id=(select outlet_id from tbl_store where sap_id = '".$impData[3]."'),
    account=(select account from tbl_store where sap_id = '".$impData[3]."') where ship_to = '".$impData[3]."' ";
    mysqli_query($con,$query);
      }
      
  }
  $_SESSION['successfullUpload'] = true;
}


echo "<script>location.replace('upload?ac=upmas');</script>";
// header("location:main".$err);
?>

