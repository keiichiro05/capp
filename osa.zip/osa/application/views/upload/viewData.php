<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php

include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/upload/tab.php';

# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];

// $mDN = array("CMP" => "Complete");
// $str="SELECT * FROM tbm_dn_pending where reason_type = 'INV' or reason_type = 'LTG' order by reason_type";
// $result = mysqli_query($con, $str);
// while($row = mysqli_fetch_assoc($result)){ $mDN[$row['pdn_code']]=$row['description']; }


$DN=getPreValue("dn","");

$judul = "View Data";
$otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i></a>";
// $otherMenu .= "<a href='#' id='btn2'><i class='fa fa-upload'></i>Upload Amount (FBL5N)</a>";
// $otherMenu .= "<input type='text' name='dn' id='txBarcode' placeholder='&#xf002; Cari DN' style='font-family:Arial, FontAwesome' autofocus onfocus='this.select();'>";
$otherMenu.= cariKey();

echo tableHeader($judul, $otherMenu);

echo "<div>
        <h2>Data</h2>
        <form action='' method='post'>
            <select name='data'>
            <option value='pkm'>PKM</option>
            <option value='maxstock3w'>Max Stock3W</option>
            <option value='sap'>Data SAP</option>
            </select>
            <input type='submit' name='submit' value='Get Data'/>
        </form>
</div>";
// echo uploadFile("Upload Bill Doc","bseco?ac=send");
// echo uploadFile2("Upload Amount SAP","bseco?ac=send1");
?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>

<?php
    if (isset($_POST['submit'])) {
        $strPKM = "SELECT outlet_id, account, brand, pkm FROM tbl_pkm";
        $resultPKM = mysqli_query($con, $strPKM);
        if ($_POST['data'] == 'pkm') {
            echo "
            <i> Data PKM</i>
            <div class='row'>
            <div class='col-lg-12' id='frameparent'>
                <table class='table-control' id='myTable'>
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>outlet_id</th>
                        <th>account</th>
                        <th>brand</th>
                        <th>pkm</th>
                    </tr>
                    </thead>
                    <tbody>";
            $i=1; while($row = mysqli_fetch_assoc($resultPKM)) {
                    echo "<tr class='cari'>";
                    echo "<td>$i</td>";
                    echo "<td>".$row['outlet_id']."</td>";
                    echo "<td>".$row['account']."</td>";
                    echo "<td>".$row['brand']."</td>";
                    echo "<td>".$row['pkm']."</td>";
                    echo "</tr>";
                    $i++;
            }
            echo "
                    </tbody>
                </table> 
            </div>
            </div>";
        }
        else if ($_POST['data'] == 'maxstock3w') {
            $strMaxStock = "SELECT account, sap_id, outlet_id, brand, max_stock FROM tbl_max_stock3w ORDER BY sap_id DESC";
            $resultMaxStock = mysqli_query($con, $strMaxStock);
            echo "
            <i> Data Maxstock</i>
            <div class='row'>
            <div class='col-lg-12' id='frameparent'>
                <table class='table-control' id='myTable'>
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Account</th>
                        <th>SAP ID</th>
                        <th>Outlet ID</th>
                        <th>Brand</th>
                        <th>Max Stock</th>
                    </tr>
                    </thead>
                    <tbody>";
            $i=1; 
            while($row = mysqli_fetch_assoc($resultMaxStock)) {
                    echo "<tr class='cari'>";
                    echo "<td>$i</td>";
                    echo "<td>".$row['account']."</td>";
                    echo "<td>".$row['sap_id']."</td>";
                    echo "<td>".$row['outlet_id']."</td>";
                    echo "<td>".$row['brand']."</td>";
                    echo "<td>".$row['max_stock']."</td>";
                    echo "</tr>";
                    $i+=1;
            }
        }
            else if ($_POST['data'] == 'sap') {
                $query = "SELECT record_id, ship_to, sold_to, order_number, req_deliv_date, po_qty, do_qty FROM tbl_data_sap";
                $resultSAP = mysqli_query($con, $query);
                echo "
                <i> Data SAP</i>
                <div class='row'>
                <div class='col-lg-12' id='frameparent'>
                    <table class='table-control' id='myTable'>
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Record ID</th>
                            <th>Ship To</th>
                            <th>Sold To</th>
                            <th>Order Number</th>
                            <th>Req Deliv Date</th>
                            <th>PO Qty</th>
                            <th>DO Qty</th>
                        </tr>
                        </thead>
                        <tbody>";
                $i=1; 
                while($row = mysqli_fetch_assoc($resultSAP)) {
                        echo "<tr class='cari'>";
                        echo "<td>$i</td>";
                        echo "<td>".$row['record_id']."</td>";
                        echo "<td>".$row['ship_to']."</td>";
                        echo "<td>".$row['sold_to']."</td>";
                        echo "<td>".$row['order_number']."</td>";
                        echo "<td>".$row['req_deliv_date']."</td>";
                        echo "<td>".$row['po_qty']."</td>";
                        echo "<td>".$row['do_qty']."</td>";
                        echo "</tr>";
                        $i+=1;
                }
            }
        }
            if (isset($_POST['getdata'])) {
                    $startdate = $_POST['startdate'];
                    $enddate = $_POST['enddate'];
                    $startdate = date('Y-m-d', strtotime($startdate));
                    $enddate = date('Y-m-d', strtotime($enddate));
                    var_dump($startdate);
                    var_dump($enddate);
                    $strSPS = "SELECT `year`,`month`,`date`,account, branch, cust_id, store_name, sku, stock_qty, stock_rp, sales_qty, sales_rp FROM tbl_sps WHERE `date` BETWEEN '$startdate' AND '$enddate'";
                    $resultSPS = mysqli_query($con_176, $strSPS);
                    echo "
                    <i> Data SPS</i>
                    <div class='row'>
                    <div class='col-lg-12' id='frameparent'>
                        <table class='table-control' id='myTable'>
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Year</th>
                                <th>Month</th>
                                <th>Date</th>
                                <th>Account</th>
                                <th>Branch</th>
                                <th>Cust ID</th>
                                <th>Store Name</th>
                                <th>SKU</th>
                                <th>Stock (qty)</th>
                                <th>Stock (rp)</th>
                                <th>Sales (qty)</th>
                                <th>Sales (rp)</th>
                            </tr>
                            </thead>
                            <tbody>";
                    $i=1; 
                    while($row = mysqli_fetch_assoc($resultSPS)) {
                            echo "<tr class='cari'>";
                            echo "<td>$i</td>";
                            echo "<td>".$row['year']."</td>";
                            echo "<td>".$row['month']."</td>";
                            echo "<td>".$row['date']."</td>";
                            echo "<td>".$row['account']."</td>";
                            echo "<td>".$row['branch']."</td>";
                            echo "<td>".$row['cust_id']."</td>";
                            echo "<td>".$row['store_name']."</td>";
                            echo "<td>".$row['sku']."</td>";
                            echo "<td>".$row['stock_qty']."</td>";
                            echo "<td>".$row['stock_rp']."</td>";
                            echo "<td>".$row['sales_qty']."</td>";
                            echo "<td>".$row['sales_rp']."</td>";
                            echo "</tr>";
                            $i+=1;
                    }
                    echo "
                            </tbody>
                        </table> 
                    </div>
                    </div>";
                }
            echo "
                    </tbody>
                </table> 
            </div>
            </div>";
?>


