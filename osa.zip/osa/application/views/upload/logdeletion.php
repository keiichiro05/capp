<?php 

include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/upload/tab.php';

$str = "SELECT seq, user, delete_date, outlet_id, sap_id, outlet_name, account, brand FROM tbl_log_deletion GROUP BY delete_date order by seq desc";
$result = mysqli_query($con, $str);

?>


<i> Data Log Deletion </i>
<div class="row">
  <div class="col-lg-12" id="frameparent">
      <table class="table-control" id="myTable">
        <thead>
          <tr>
            <th>No</th>
            <th>User</th>
            <th>Delete Date</th>
            <th>Outlet ID</th>
            <th>SAP ID</th>
            <th>Outlet Name</th>
            <th>Account</th>
            <th>Brand</th>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><?php echo $i; ?></td>
            <td><?php echo $row['user']; ?></td>
            <td><?php echo $row['delete_date']; ?></td>
            <td><?php echo $row['outlet_id']; ?></td>
            <td><?php echo $row['sap_id']; ?></td>
            <td><?php echo $row['outlet_name']; ?></td>
            <td><?php echo $row['account']; ?></td>
            <td><?php echo $row['brand']; ?></td>
          </tr>
          <?php $i++;} ?>
        </tbody>
    </table> 
  </div>
 </div>