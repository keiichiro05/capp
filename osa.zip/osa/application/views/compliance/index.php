<html>
    <head>
        <link href="css/jquery.tablesorter.min.css" rel="stylesheet">
        <!-- Pop Up form -->
        <script src='js/popup.form.js' type='text/javascript'></script>
        <link href="css/popup.form.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    </head>
    <body>
        <div class="container">
            <h2>Compliance Uploader</h2>
            <p>Customer Solution uploader for OG Compliance</p>

            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#home">OG Apollo Uploader</a></li>
                <li><a data-toggle="tab" href="#menu1">OG Urgent Uploader</a></li>
                <li><a data-toggle="tab" href="#menu2">OG IOD Uploader</a></li>
                <li><a data-toggle="tab" href="#menu3">MD IOD Uploader</a></li>
            </ul>

            <div class="tab-content">
                <div id="home" class="tab-pane fade in active">
                    <h3>OG Apollo Uploader</h3>
                    <form method="post" action="" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="uploaded-file">Upload CSV</label>
                            <input type="hidden" id="uploader" name="uploader" value="og-apollo">
                            <input type="file" id="uploaded-file" name="uploaded-file" required accept="text/csv">
                        </div>
                        <button type="submit" class="btn btn-default" id="submitform" name="submitform">Submit</button>
                    </form>
                </div>
                <div id="menu1" class="tab-pane fade">
                    <h3>OG Urgent Uploader</h3>
                    <form method="post" action="" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="uploaded-file">Upload CSV</label>
                            <input type="hidden" id="uploader" name="uploader" value="og-urgent">
                            <input type="file" id="uploaded-file" name="uploaded-file" required accept="text/csv">
                        </div>
                        <button type="submit" class="btn btn-default" id="submitform" name="submitform">Submit</button>
                    </form>
                </div>
                <div id="menu2" class="tab-pane fade">
                    <h3>OG IOD Uploader</h3>
                    <form method="post" action="" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="uploaded-file">Upload CSV</label>
                            <input type="hidden" id="uploader" name="uploader" value="og-iod">
                            <input type="file" id="uploaded-file" name="uploaded-file" required accept="text/csv">
                        </div>
                        <button type="submit" class="btn btn-default" id="submitform" name="submitform">Submit</button>
                    </form>
                </div>

                <div id="menu3" class="tab-pane fade">
                    <h3>MD IOD Uploader</h3>
                    <form method="post" action="" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="uploaded-file">Upload CSV</label>
                            <input type="hidden" id="uploader" name="uploader" value="md-iod">
                            <input type="file" id="uploaded-file" name="uploaded-file" required accept="text/csv">
                        </div>
                        <button type="submit" class="btn btn-default" id="submitform" name="submitform">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>

<?php
require_once APP_DIR.'config/connection.php';


function upload_success($additional_message = ""){
    echo "<script>alert(`berhasil melakukan upload ".$additional_message."`)</script>";
}

include_once (APP_DIR."controllers/ComplianceUploader.php");
if(isset($_POST["uploader"]) && isset($_POST["submitform"])){
    $choice = $_POST["uploader"];
    $selected_csv = $_FILES["uploaded-file"];
    $complianceUpdater = new ComplianceUploader();
    switch ($choice){
        case "og-apollo":
            try{
                $complianceUpdater->csv_reader($selected_csv["tmp_name"]);
                $complianceUpdater->verify(["og_date", "sap_id", "outlet_id", "outlet_name", "og_apollo"]);
                $q = $complianceUpdater->get_query("tbl_og_apollo","og_date, sap_id, outlet_id, outlet_name, og_apollo");
                $ra = $complianceUpdater->execute_sql($con, $q);
                upload_success("tabel og apollo, row affected: ".$ra);
            }catch (Error $e){
                var_dump($e);
            }
            break;
        case "og-urgent":
            try{
                $complianceUpdater->csv_reader($selected_csv["tmp_name"]);
                $complianceUpdater->verify(["og_urgent_date", "sap_id", "outlet_id", "outlet_name", "og_urgent"]);
                $q = $complianceUpdater->get_query("tbl_og_urgent","og_urgent_date, sap_id, outlet_id, outlet_name, og_urgent");
                $ra = $complianceUpdater->execute_sql($con, $q);
                upload_success("tabel og apollo, row affected: ".$ra);
            }catch (Error $e){
                var_dump($e);
            }
            break;
        case "og-iod":
            try{
                $complianceUpdater->csv_reader($selected_csv["tmp_name"]);
                $complianceUpdater->verify(["og_aws_date", "sap_id", "sap_name", "og_iod"]);
                $q = $complianceUpdater->get_query("tbl_og_iod","og_aws_date, sap_id, sap_name, og_iod");

                $ra = $complianceUpdater->execute_sql($con, $q);
                upload_success("tabel og apollo, row affected: ".$ra);
            }catch (Error $e){
                var_dump($e);
            }
            break;
        case "md-iod":
            try{ 
//                echo "<br>uhuyyy<br>";
                $complianceUpdater->csv_reader($selected_csv["tmp_name"]);
                $complianceUpdater->verify(["sap_id","brand", "sap_name", "source", "supplier", "region", "region_sales", "active", "segment", "remarks", "jwk"]);
                $q = $complianceUpdater->get_query("tbl_md_iod","sap_id, brand, sap_name, source, supplier, region, region_sales, active, segment, remarks, jwk");
                $ra = $complianceUpdater->execute_sql($con, $q);
                upload_success("tabel md iod , row affected: ".$ra);
            }catch (Error $e){
                var_dump($e);
            }
            break;
        default:
            return;
    }
}

?>