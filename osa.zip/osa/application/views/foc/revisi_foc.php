<?php session_start(); ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<?php
$dom = new DOMDocument();

include '../assets/utility_function.php';

// connection to db
$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

// echo 'hello world';
if(!empty($_GET['a1'])){ $selected = $_GET['a1'];}
else{ $selected = 'home';}

$teks = $dom -> getElementById('r-text');

$str = "SELECT p.prd_diskripsi FROM db_depo.tbm_product p";
$result = mysqli_query($con,$str);
while($row=mysqli_fetch_assoc($result)){
	$mProduk[$row['prd_diskripsi']]=$row['prd_diskripsi'];
}
// array_unshift($mProduk, '');
array_push($mProduk, 'Others');

// $namaProduk = getPreValue("cmdProduk", key($mProduk));
$namaProduk = '';
// echo $namaProduk;

function cmbBoxFoc($name,$class,$id,$ref,$dataCat,$other){
	$kode='<select class="'.$class.'" name="'.$name.'" id="'.$id.'" '.$other.' required>'."\n";
    $kode .= '<option value=""></option>';
	foreach ($dataCat AS $row) {
		$kode .='<option value="'.key($dataCat).'"';
		if(key($dataCat)==$ref) {
        	$kode .=' selected';
        }
		$kode .='>'.$row.'</option>'."\n";
		next($dataCat);
		}
		$kode .='</select>'."\n";
		return $kode;
}

$menuProduk = cmbBoxFoc("cmdProduk[]","","cmdsProduk",$namaProduk,$mProduk,"");

// List variable POST dari form
// $idForm = isset($_POST['idForm']) ? $_POST['idForm'] : '';
// $reqEmail = isset($_POST['reqEmail']) ? $_POST['reqEmail'] : '';
// $divisi = isset($_POST['cmbBoxDivisi']) ? $_POST['cmbBoxDivisi'] : '';
// $reqType = isset($_POST['reqType']) ? $_POST['reqType'] : '';
// $idReq = isset($_POST['idReq']) ? $_POST['idReq'] : '';
// $delivDate = isset($_POST['delivDate']) ? $_POST['delivDate'] : '';
// $cc = isset($_POST['cc']) ? $_POST['cc'] : '';
// $produk = isset($_POST['cmdProduk']) ? $_POST['cmdProduk'] : '';
// $qty = isset($_POST['qty']) ? $_POST['qty'] : '';
// $picName = isset($_POST['picName']) ? $_POST['picName'] : '';
// $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
// $provinsi = isset($_POST['provinsi']) ? (explode(':', $_POST['provinsi'])) : '';
// $kota = isset($_POST['kabupaten']) ? (explode(':', $_POST['kabupaten'])) : '';
// $address = isset($_POST['address']) ? $_POST['address'] : '';
// $note = isset($_POST['note']) ? $_POST['note'] : '';



// Get POST value from form
$reqEmail = isset($_POST['reqEmail']) ? $_POST['reqEmail'] : '';
$divisi = isset($_POST['cmbBoxDivisi']) ? $_POST['cmbBoxDivisi'] : '';
$reqType = isset($_POST['reqType']) ? $_POST['reqType'] : '';
$idReq = isset($_POST['idReq']) ? $_POST['idReq'] : '';
$delivDate = isset($_POST['delivDate']) ? $_POST['delivDate'] : '';
$cc = isset($_POST['cc']) ? $_POST['cc'] : '';
$produk = isset($_POST['cmdProduk']) ? $_POST['cmdProduk'] : '';
$qty = isset($_POST['qty']) ? $_POST['qty'] : '';
$picName = isset($_POST['picName']) ? $_POST['picName'] : '';
$contact = isset($_POST['contact']) ? $_POST['contact'] : '';
$provinsi = isset($_POST['provinsi']) ? (explode(':', $_POST['provinsi'])) : '';
$kota = isset($_POST['kabupaten']) ? (explode(':', $_POST['kabupaten'])) : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';
$note = isset($_POST['note']) ? $_POST['note'] : '';

if (isset($_POST['submit'])) {
    // Get POST value from form
    $reqEmail = isset($_POST['reqEmail']) ? $_POST['reqEmail'] : '';
    $divisi = isset($_POST['cmbBoxDivisi']) ? $_POST['cmbBoxDivisi'] : '';
    $reqType = isset($_POST['reqType']) ? $_POST['reqType'] : '';
    $idReq = isset($_POST['idReq']) ? $_POST['idReq'] : '';
    $delivDate = isset($_POST['delivDate']) ? $_POST['delivDate'] : '';
    $cc = isset($_POST['cc']) ? $_POST['cc'] : '';
    $produk = isset($_POST['cmdProduk']) ? $_POST['cmdProduk'] : '';
    $qty = isset($_POST['qty']) ? $_POST['qty'] : '';
    $picName = isset($_POST['picName']) ? $_POST['picName'] : '';
    $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
    $provinsi = isset($_POST['provinsi']) ? (explode(':', $_POST['provinsi'])) : '';
    $kota = isset($_POST['kabupaten']) ? (explode(':', $_POST['kabupaten'])) : '';
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $note = isset($_POST['note']) ? $_POST['note'] : '';

    $delivDateToString = str_replace('-', '', $delivDate);

    // $query = "
    // SELECT
    //     CASE 
    //         WHEN MAX(id) IS NULL THEN @max_id := 1 ELSE @max_id := (MAX(id) + 1)
    //     END AS max_id
    // FROM dbdump.tbl_foc;
    // ";
    // $result = mysqli_query($con, $query);

    // while($row=mysqli_fetch_assoc($result)){
    //     $maxID[$row['max_id']]=$row['max_id'];
    //     foreach ($maxID as $key => $value) {
    //         $id = $value;
    //     }
    // };
    
    $counter = 0;
    foreach ($produk as $key => $value) {
        $query = "
        INSERT INTO dbdump.tbl_foc (id, req_email, divisi, req_type, id_req, deliv_date, cc, product, qty, pic_name, contact_number, provinsi, kota, detail_address, note)
        VALUES ('".$idReq.$delivDateToString."', '".$reqEmail."', '".$divisi."', '".$reqType."', '".$idReq."', 
        '".$delivDate."', '".$cc."', '".$value."', '".$qty[$counter++]."', '".$picName."', 
        '".$contact."', '".$provinsi[1]."', '".$kota[1]."', '".$address."', '".$note."')
        ";
        mysqli_query($con, $query);
    }
    echo $query;

    // echo $_POST['provinsi'];

    $query = "
    SELECT mp.area, mp.to_pic_cs, mp.cc_pic_cs
    FROM dbdump.tbl_matrix_area ma, dbdump.tbl_matrix_pic mp
    WHERE ma.detail_region = UPPER('".explode(':', $_POST['provinsi'])[1]."') AND ma.area = mp.area
    ";
    $result = mysqli_query($con, $query);

    // Handle PIC and CC
    $email_pic = array();
    $cc_email_pic = array();

    while($row=mysqli_fetch_assoc($result)){
        $to_pic[$row['to_pic_cs']]=$row['to_pic_cs'];
        foreach ($to_pic as $key => $valuePic) {
            array_push($email_pic, $valuePic);
        }
        $cc_pic[$row['cc_pic_cs']]=$row['cc_pic_cs'];
        foreach ($cc_pic as $key => $valueCCPic) {
            array_push($cc_email_pic, $valueCCPic);
        } 
    };

    // print_r(array_unique($email_pic));
    // print_r(array_unique($cc_email_pic));

    $_SESSION['idForm']    = $idReq.$delivDateToString;
    $_SESSION['reqEmail']  = isset($_POST['reqEmail'] ) ? $_POST['reqEmail'] : '';
    $_SESSION['divisi']    = isset($_POST['cmbBoxDivisi']   ) ? $_POST['cmbBoxDivisi']   : '';
    $_SESSION['reqType']   = isset($_POST['reqType']  ) ? $_POST['reqType']  : '';
    $_SESSION['idReq']     = isset($_POST['idReq']    ) ? $_POST['idReq']    : '';
    $_SESSION['delivDate'] = isset($_POST['delivDate']) ? $_POST['delivDate']: '';
    $_SESSION['cc']        = isset($_POST['cc']       ) ? $_POST['cc']       : '';
    $_SESSION['produk']    = isset($_POST['cmdProduk']   ) ? $_POST['cmdProduk']   : '';
    $_SESSION['qty']       = isset($_POST['qty']      ) ? $_POST['qty']      : '';
    $_SESSION['picName']   = isset($_POST['picName']  ) ? $_POST['picName']  : '';
    $_SESSION['contact']   = isset($_POST['contact']  ) ? $_POST['contact']  : '';
    $_SESSION['provinsi']  = isset($_POST['provinsi'] ) ? (explode(':', $_POST['provinsi']))[1] : '';
    $_SESSION['kota']      = isset($_POST['kabupaten']     ) ? (explode(':', $_POST['kabupaten']))[1]     : '';
    $_SESSION['address']   = isset($_POST['address']  ) ? $_POST['address']  : '';
    $_SESSION['note']      = isset($_POST['note']     ) ? $_POST['note']     : '';
    
    echo(empty($_FILES['uploadFile']['name'][0]) ? 'empty' : $_FILES['uploadFile']['name'][0]);


    $_SESSION['fileName'] = array();
    // foreach ($_FILES['uploadFile']['name'] as $key => $value) {
    //     array_push($_SESSION['fileName'], $value); 
         
    // }

    print_r($_SESSION['fileName']);

    $_SESSION['to_pic'] = array();
    array_push($_SESSION['to_pic'], array_unique($email_pic));
    $_SESSION['cc_pic'] = array();
    array_push($_SESSION['cc_pic'], array_unique($cc_email_pic));

    print_r($_SESSION['to_pic']);
    print_r($_SESSION['cc_pic']);


    // print_r($_SESSION['fileName']);


    // print_r($_SESSION);
    // function printProduct() {
    //     $i = 0;
    //     foreach($_SESSION['produk'] as $key => $value) {
    //         echo $value.' Qty: '.$_SESSION['qty'][$i++].'<br>';
    //     }
    // }

    

    // printProduct();
    // foreach($_SESSION['qty'] as $key => $value) echo $key;

    echo "<script> location.href='./test-email.php'; </script>";
    // exit;
}



// // print_r($qty);

// if ($produk != '') {
//     $counter = 0;
//     foreach ($produk as $key => $value) {
//         $query = "
//         INSERT INTO dbdump.tbl_foc
//         VALUES ('".$id."', '".$reqEmail."', '".$divisi."', '".$reqType."', '".$idReq."', 
//         '".$delivDate."', '".$cc."', '".$value."', '".$qty[$counter++]."', '".$picName."', 
//         '".$contact."', '".$provinsi[1]."', '".$kota[1]."', '".$address."', '".$note."')
//         ";
//         mysqli_query($con, $query);
//     }
// }
?>

<html>
    <div id='foc-form'>
        <form action="" method="POST" enctype="multipart/form-data">

            <label for="reqEmail">Requester Email</label><br>
            <input type="email" id="reqEmail" name="reqEmail" required><br>
            
            <label for="cmbBoxDivisi">Division</label><br>
            <select id="cmbBoxDivisi" name="cmbBoxDivisi" required>
                <option value=""></option>
                <option value="General Secretary">General Secretary</option>
                <option value="Marketing">Marketing</option>
                <option value="HR">HR</option>
                <option value="Sales Ops">Sales Ops</option>
                <option value="Sales Strategy Planning">Sales Strategy Planning</option>
                <option value="R&I">R&I</option>
                <option value="Operation">Operation</option>
                <option value="Finance">Finance</option>
                <option value="Quality Food Safety">Quality Food Safety</option>
                <option value="Lainnya">Lainnya</option>
            </select><br>

            <label for="reqType">Type of Request</label><br>
            <select name="reqType" id="reqType" required>
                <option value=""></option>
                <option value="AKP">AKP</option>
                <option value="BRIGHT">BRIGHT</option>
                <option value="FOC">FORM FOC</option>
            </select><br>

            <label for="idReq">ID Request (Bright/AKP/Form FOC Produk)</label><br>
            <input type="text" id="idReq" name="idReq" required><br>

            <!-- nanti taruh ke CS  -->
            <!-- <label for="typeCust">Type of Customer</label><br>
            <input type="radio" id="typeCust1" name="typeCust" value='Depo'>Depo<br>
            <input type="radio" id="typeCust2" name="typeCust" value='Not Depo'>Not Depo<br>

            <span id="r-text">
                php echo $selected;
            </span>
            <script>
                $('#r-text').html('Type of Delivery');
                $('input[type=radio]').click(function(e) {//jQuery works on clicking radio box
                    let value = $(this).val(); //Get the clicked checkbox value
                    if (value == 'Depo') {
                        $('#delivMethod').html('<input type="radio" id="typeDeliv1" name="typeDeliv" value="byDepo">By Depo<br><input type="radio" id="typeDeliv2" name="typeDeliv" value="byOther">By Other<br>');
                    }
                    else {
                        $('#delivMethod').html('<input type="radio" id="typeDeliv1" name="typeDeliv" value="byRex">By REX<br>');
                    }
                });
            </script> -->

            <!-- <div id='delivMethod'>
                <input type="radio" id="typeDeliv1" name="typeDeliv" value="byDepo">By Depo<br>
                <input type="radio" id="typeDeliv2" name="typeDeliv" value="byDistributor">By Distributor<br>
                <input type="radio" id="typeDeliv3" name="typeDeliv" value="byREX">By REX<br>
                <input type="radio" id="typeDeliv4" name="typeDeliv" value="byOther">By Other<br>
            </div> -->

            <label for="delivDate">Delivery/Pickup Date</label><br>
            <input type="date" id="delivDate" name="delivDate" min="<?php echo date("Y-m-d") ?>" required><br>

            <label for="cc">Cost Centre</label><br>
            <input type="text" id="cc" name="cc" required><br>

            <!-- product -->
            <div class='wrapper'>
                <div class='input-box'>
                    <label for="product">Product</label><br>
                    <?php echo $menuProduk; ?>
                    <!-- <label for="qty">Quantity</label> -->
                    <input type="number" id="qty" name="qty[]" min="1" placeholder="Qty..." required><br>
                    <!-- <input type="text" id="product" name="product[]"> -->
                    <button class="btn add-btn">Add More</button>
                </div>
            </div>

            

            <label for="picName">Name PIC FOC Receiver</label><br>
            <input type="text" id="picName" name="picName" required><br>

            <label for="contact">Contact Number PIC FOC</label><br>
            <input type="text" id="contact" name="contact" required><br>

            <label>Provinsi</label>
			<select class="form-control" name="provinsi" id="provinsi" required>
				<option value=""> Pilih Provinsi</option>
			</select>

            <label>Kabupaten</label>
			<select class="form-control" name="kabupaten" id="kabupaten" required>
				<option value=""></option>
			</select>

            <label for="">Detail Address FOC</label><br>
            <input type="text" id="address" name="address" style="width: 100%" required><br>

            <label for="note"></label>Additional Note<br>
            <input type="text" id="note" name="note" style="width: 100%" required><br>

            <label for='uploadFile'>Upload Attachment(s)</label>
            <input type='file' id='uploadFile' name='uploadFile[]' multiple accept="application/pdf, application/msword, application/vnd.ms-excel, application/zip, application/x-rar-compressed, image/*" required><br>
            <?php 
                // $_SESSION['fileName'] = array();
                $allowedTypes = array('application/pdf', 'application/msword', 'application/vnd.ms-excel', 'application/zip', 'application/x-rar-compressed', 'image/png', 'image/jpg', 'image/jpeg');
                if (isset($_FILES["uploadFile"])) {
                    $countFile = 0;
                    foreach ($_FILES["uploadFile"]["type"] as $fileType) {
                        if (in_array($fileType, $allowedTypes)) {
                            $fileName = $_FILES["uploadFile"]["tmp_name"][$countFile];
                            $fileExtension = explode('/', $fileType)[1];

                            $path = '../storage/soluform '.$_SESSION['idForm'];
                            if ( !is_dir($path)) {
                                mkdir($path);
                            }
                            move_uploaded_file($fileName, '../storage/soluform '.$_SESSION['idForm'].'/'.$_SESSION['reqType'].' '.$_SESSION['idReq'].' ('.($countFile+1).') '.'.'.$fileExtension);
                            array_push($_SESSION['fileName'], $_SESSION['reqType'].' '.$_SESSION['idReq'].' ('.($countFile+1).') '.'.'.$fileExtension);
                            echo '<p>Successfully uploaded for '.$_FILES["uploadFile"]["name"][$countFile].'</p>';
                            // array_push($_SESSION['fileName'], $_FILES["uploadFile"]["name"][$countFile]);
                            $countFile++;
                        } 
                        else {
                            echo 'File type not allowed!';
                        }
                    } 
                }
                // print_r($_FILES['uploadFile']['name'][0]);           
            ?>

            <!-- <input id="submitBtn" formaction="./test-email.php" type="submit" value='submit'> -->
            <input id="submitBtn" type="submit" name="submit" value='submit'>
            
        </form>
    </div>

    <script type="text/javascript">
        
        $(document).ready(function () {
    
        // allowed maximum input fields
        let max_input = 999;
    
        // initialize the counter for textbox
        let x = 1;
    
        // handle click event on Add More button
        $('.add-btn').click(function (e) {
            e.preventDefault();
            if (x < max_input) { // validate the condition
            x++; // increment the counter
            $('.wrapper').append(`
                <div class="input-box">
                <?php echo $menuProduk; ?>
                <input type="number" id="qty" name="qty[]" placeholder="Qty..." required><br>
                <a href="#" class="remove-lnk">Remove</a>
                </div>
            `); // add input field
            }
        });
    
        // handle click event of the remove link
        $('.wrapper').on("click", ".remove-lnk", function (e) {
            e.preventDefault();
            $(this).parent('div').remove();  // remove input field
            x--; // decrement the counter
        });

        // handle provinsi dan kota
        $.ajax({
                type: 'POST',
                url: "./get_provinsi.php",
                cache: false, 
                success: function(msg){
                $("#provinsi").html(msg);
                }
            });
    
            $("#provinsi").change(function(){
            var provinsi = $("#provinsi").val();
                $.ajax({
                    type: 'POST',
                    url: "get_kabupaten.php",
                    data: {provinsi: provinsi},
                    cache: false,
                    success: function(msg){
                    $("#kabupaten").html(msg);
                    }
                });
            });
    
            $("#kabupaten").change(function(){
            var kabupaten = $("#kabupaten").val();
                $.ajax({
                    type: 'POST',
                    url: "get_kecamatan.php",
                    data: {kabupaten: kabupaten},
                    cache: false,
                    success: function(msg){
                    $("#kecamatan").html(msg);
                    }
                });
            });
 
            $("#kecamatan").change(function(){
            var kecamatan = $("#kecamatan").val();
                $.ajax({
                    type: 'POST',
                    url: "get_kelurahan.php",
                    data: {kecamatan: kecamatan},
                    cache: false,
                    success: function(msg){
                    $("#kelurahan").html(msg);
                    }
                });
            });
            
        });
    </script>

    <style>
        #foc-form {
            margin: auto;
            width: 50%;
            border: 3px solid green;
            padding: 10px;
        }

        .remove-lnk {
            color: red;
        }

        .add-btn {
            color: green;
        }
    </style>
</html>