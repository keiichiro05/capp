<?php
session_start();

function alertMsg($comment){
	$kode = "<div style='margin-top: 20px;padding: 20px;border:dotted 1px gray;color: #f44336;'><b>ERROR!</b> ".$comment."</div>";
	return $kode;
}

// connection to db
$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

// unset($_SESSION['prevLink']);
// $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
// $_SESSION['prevLink'] = $actual_link;

// // unset($_SESSION['nama_user']);

// if(!isset($_SESSION['nama_user']) or empty($_SESSION['nama_user'])) {
//   header("location: login.php");
// }

include './tab.php';
echo '<br>';

$str = "SELECT id, id_req, divisi, deliv_date, deliv_method, depo_name, sold_to, req_email, pic_name, `status`, suggested_depo FROM dbdump.tbl_foc";
$result = mysqli_query($con,$str);
while($row=mysqli_fetch_assoc($result)){
	$sId[$row['id']]=$row['id'];
	$sId_req[$row['id_req']]=$row['id_req'];
	$sDivisi[$row['divisi']]=$row['divisi'];
	$sDeliv_date[$row['deliv_date']]=$row['deliv_date'];
	$sDeliv_method[$row['deliv_method']]=$row['deliv_method'];
	$sDepo_name[$row['depo_name']]=$row['depo_name'];
	$sSold_to[$row['sold_to']]=$row['sold_to'];
	$sReq_email[$row['req_email']]=$row['req_email'];
	$sPic_name[$row['pic_name']]=$row['pic_name'];
	$sStatus[$row['status']]=$row['status'];
  $sSuggested[$row['suggested_depo']]=$row['suggested_depo'];
}

function cmbBoxFoc($name,$class,$id,$ref,$dataCat, $def, $other){
	$kode='<select class="chosen-select '.$class.'" name="'.$name.'" id="'.$id.'" '.$other.' data-placeholder="'.$def.'" multiple>'."\n";
    $kode .= '<option value="">'.$def.'</option>';
	foreach ($dataCat AS $row) {
		$kode .='<option value="'.key($dataCat).'"';
		// if(key($dataCat)==$ref) {
    //     	$kode .=' selected';
    //     }
		$kode .='>'.$row.'</option>'."\n";
		next($dataCat);
		}
		$kode .='</select>'."\n";
		return $kode;
}

$refId = '';
$refId_req = '';
$refDivisi = '';
$refDeliv_date = '';
$refDeliv_method = '';
$refDepo_name = '';
$refSold_to = '';
$refReq_email = '';
$refPic_name = '';
$refStatus = '';
$refSuggested = '';

$defRefId = 'Select ID SoluForm';
$defRefId_req = 'Select ID Request Type';
$defRefDivisi = 'Select Divisi';
$defRefDeliv_date = 'Select Date';
$defRefDeliv_method = 'Select Delivery Method';
$defRefDepo_name = 'Select Depo Name';
$defRefSold_to = 'Select Sold To';
$defRefReq_email = 'Select Requester Email';
$defRefPic_name = 'Select PIC Name';
$defRefStatus = 'Select Status';
$defSuggested = 'Select Suggested Depo';

$menuId = cmbBoxFoc("id[]","","cmdsId", $refId,$sId,$defRefId,"");
$menuId_req = cmbBoxFoc("id_req[]","","cmdsId_req", $refId_req,$sId_req,$defRefId_req,"");
$menuDivisi = cmbBoxFoc("divisi[]","","cmdsDivisi", $refDivisi,$sDivisi,$defRefDivisi,"");
$menuDeliv_date = cmbBoxFoc("deliv_date[]","","cmdsDeliv_date", $refDeliv_date,$sDeliv_date,$defRefDeliv_date,"");
$menuDeliv_method = cmbBoxFoc("deliv_method[]","","cmdsDeliv_method", $refDeliv_method,$sDeliv_method,$defRefDeliv_method,"");
$menuDepo_name = cmbBoxFoc("depo_name[]","","cmdsDepo_name", $refDepo_name,$sDepo_name,$defRefDepo_name,"");
$menuSold_to = cmbBoxFoc("sold_to[]","","cmdsSold_to", $refSold_to,$sSold_to,$defRefSold_to,"");
$menuReq_email = cmbBoxFoc("req_email[]","","cmdsReq_email", $refReq_email,$sReq_email,$defRefReq_email,"");
$menuPic_name = cmbBoxFoc("pic_name[]","","cmdsPic_name", $refPic_name,$sPic_name,$defRefPic_name,"");
$menuStatus = cmbBoxFoc("status[]","","cmdsStatus", $refStatus,$sStatus,$defRefStatus,"");
$menuSuggested = cmbBoxFoc("suggested_depo[]","","cmdsSuggested", $refSuggested,$sSuggested,$defSuggested,"");

// echo '<br><br><br>';
// echo $_POST['dates'];

if (isset($_POST['dates']) and ($_POST['dates'] != '')) {
  if (empty($_POST['id']) and empty($_POST['id_req']) and empty($_POST['pic_name'])) {
    echo '<br><br><br>';
    echo alertMsg('Please enter ID Soluform/ ID Req Type/ PIC Name');
  }
  else {
    $query = "
    SELECT timestamp_req, id, req_email, divisi, req_type, id_req, deliv_date, cc, product, qty, pic_name, status, contact_number, provinsi, kota, detail_address, note, sold_to, deliv_method, so_number, plant_type, depo_name, distributor_name, rex_info, pickup_by, final_deliv_date, additional_comment, email_receiver_feedback, name_pic_feedback, timestamp_feedback, suggested_depo FROM dbdump.tbl_foc
    ";

    if (isset($_POST['dates'])) {
      $dates = $_POST['dates'];
    }

    // echo '<br><br><br>';
    unset($_POST['dates']);
    // print_r($_POST);

    $filtered_get = array_filter($_POST);
    array_pop($filtered_get);
    $lastKey = array_key_last($filtered_get);

    // array_splice($filtered_get['dates'], 0, 1);

    // echo '<br><br><br>';
    // print_r($filtered_get);
    // echo (count($filtered_get));

    if (count($filtered_get) > 0) {
        $query .= " WHERE";

        $keynames = array_keys($filtered_get); 

        foreach($filtered_get as $key => $value)
        {
          $query .= " $key IN ('$value[0]'";
          foreach ($value as $keyValue => $valueValue) {
            $query .= ",'".$valueValue."'";
          }
          $query .= ")";
          if (count($filtered_get) > 1 && ($key != $lastKey)) {
              $query .= " AND";
          }
        }
    }
    if (isset($dates) and ($dates != '')) {
      // echo 'tanggal: '.$_POST['dates'];

      $arrDate = explode(' - ', $dates);
      $trimmed_date = array_map('trim', $arrDate);
      // print_r($trimmed_date);
      if (count($filtered_get) > 0) {
        $query .= " AND deliv_date >= '".$trimmed_date[0]."' AND deliv_date <= '".$trimmed_date[1]."'";
      }
      else {
        $query .= "WHERE deliv_date >= '".$trimmed_date[0]."' AND deliv_date <= '".$trimmed_date[1]."'";
      }
    }
    $query .= ";";
    // echo '<br><br><br>';
    // echo $query;
    $result = mysqli_query($con, $query);
  }
}
else if (isset($_POST['id']) or isset($_POST['id_req']) or isset($_POST['pic_name'])) {
  $query = "
  SELECT timestamp_req, id, req_email, divisi, req_type, id_req, deliv_date, cc, product, qty, pic_name, status, contact_number, provinsi, kota, detail_address, note, sold_to, deliv_method, so_number, plant_type, depo_name, distributor_name, rex_info, pickup_by, final_deliv_date, additional_comment, email_receiver_feedback, name_pic_feedback, timestamp_feedback, suggested_depo FROM dbdump.tbl_foc
  ";

  if (isset($_POST['dates'])) {
    $dates = $_POST['dates'];
  }

  // echo '<br><br><br>';
  unset($_POST['dates']);
  // print_r($_POST);

  $filtered_get = array_filter($_POST);
  array_pop($filtered_get);
  $lastKey = array_key_last($filtered_get);

  // array_splice($filtered_get['dates'], 0, 1);

  // echo '<br><br><br>';
  // print_r($filtered_get);
  // echo (count($filtered_get));

  if (count($filtered_get) > 0) {
      $query .= " WHERE";

      $keynames = array_keys($filtered_get); 

      foreach($filtered_get as $key => $value)
      {
        $query .= " $key IN ('$value[0]'";
        foreach ($value as $keyValue => $valueValue) {
          $query .= ",'".$valueValue."'";
        }
        $query .= ")";
        if (count($filtered_get) > 1 && ($key != $lastKey)) {
            $query .= " AND";
        }
      }
  }
  if (isset($dates) and ($dates != '')) {
    // echo 'tanggal: '.$_POST['dates'];

    $arrDate = explode(' - ', $dates);
    $trimmed_date = array_map('trim', $arrDate);
    // print_r($trimmed_date);
    if (count($filtered_get) > 0) {
      $query .= " AND deliv_date >= '".$trimmed_date[0]."' AND deliv_date <= '".$trimmed_date[1]."'";
    }
    else {
      $query .= "WHERE deliv_date >= '".$trimmed_date[0]."' AND deliv_date <= '".$trimmed_date[1]."'";
    }
  }
  $query .= ";";
  // echo '<br><br><br>';
  // echo $query;
  $result = mysqli_query($con, $query);
}

echo '<br><br><br>';


// echo downloadExcel();
?>

<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css" rel="stylesheet">
  
  <link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css" rel="stylesheet">
  
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">

</head>

<body>
<form action="" method="POST" enctype="multipart/form-data">
  <?php
    echo $menuId;
    echo $menuId_req;
    // echo $menuDivisi;
    // echo $menuDeliv_date;
    // echo $menuDeliv_method;
    // echo $menuDepo_name;
    // echo $menuSold_to;
    // echo $menuReq_email;
    echo $menuPic_name;  
    // echo $menuStatus;  
    echo '<br>';
    echo '<br>';
    echo "<input name='dates' type='text' values='' placeholder='Select Date'>";
    echo '<br>';
    echo '<br>';
  ?>
  <input id="submitBtn" type="submit" name="submit" value='submit'>
</form>

<div style="margin: 0 auto;">
  <div class="row">
    <div class="col-lg-12" id="frameparent">
        <h1>Full Summary FOC</h1>
        <table style="text-align: center; margin: 0 auto; width: 100%;" class="table-control" id="myTable">
          <thead>
            <tr>
              <th>Date</th>
              <th>ID Soluform</th>
              <th>Status</th>
              <th>Requester Email</th>
              <th>Divisi</th>
              <th>ID Request Type</th>
              <th>Request Type</th>
              <th>Delivery Date</th>
              <th>CC</th>
              <th>Product</th>
              <th>Quantity</th>
              <th>PIC Name</th>
              <th>Contact Number</th>
              <th>Provinsi</th>
              <th>Kota</th>
              <th>Detail Address</th>
              <th>Note</th>
              <th>Sold To</th>
              <th>Delivery Method</th>
              <th>SO Number</th>
              <th>Plant Type</th>
              <th>Depo Name</th>
              <th>Distributor Name</th>
              <th>Rex Info</th>
              <th>Pickup By</th>
              <th>Final Delivery Date</th>
              <th>Additional Comment</th>
              <th>Email Receiver Feedback</th>
              <th>Name PIC Feedback</th>
              <th>Timestamp Feedback</th>
              <th>Suggested Depo Delivery</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=1; while($row = mysqli_fetch_assoc($result)) { ?>
            <tr class="cari">
              <td><?php echo $row['timestamp_req']; ?></td>
              <td><a href="http://localhost/osa-dev/osa/application/views/foc/final-feedback.php?idfoc=<?php echo $row['id'] ?>"><?php echo $row['id']; ?></a></td>
              <td class='statusClass'><?php echo $row['status']; ?></td>
              <td><?php echo $row['req_email']; ?></td>
              <td><?php echo $row['divisi']; ?></td>
              <td><?php echo $row['id_req']; ?></td>
              <td><?php echo $row['req_type']; ?></td>
              <td><?php echo $row['deliv_date']; ?></td>
              <td><?php echo $row['cc']; ?></td>
              <td><?php echo $row['product']; ?></td>
              <td><?php echo $row['qty']; ?></td>
              <td><?php echo $row['pic_name']; ?></td>
              <td><?php echo $row['contact_number']; ?></td>
              <td><?php echo $row['provinsi']; ?></td>
              <td><?php echo $row['kota']; ?></td>
              <td><?php echo $row['detail_address']; ?></td>
              <td><?php echo $row['note']; ?></td>
              <td><?php echo $row['sold_to']; ?></td>
              <td><?php echo $row['deliv_method']; ?></td>
              <td><?php echo $row['so_number']; ?></td>
              <td><?php echo $row['plant_type']; ?></td>
              <td><?php echo $row['depo_name']; ?></td>
              <td><?php echo $row['distributor_name']; ?></td>
              <td><?php echo $row['rex_info']; ?></td>
              <td><?php echo $row['pickup_by']; ?></td>
              <td><?php echo $row['final_deliv_date']; ?></td>
              <td><?php echo $row['additional_comment']; ?></td>
              <td><?php echo $row['email_receiver_feedback']; ?></td>
              <td><?php echo $row['name_pic_feedback']; ?></td>
              <td><?php echo $row['timestamp_feedback']; ?></td>
              <td><?php echo $row['suggested_depo']; ?></td>
            </tr>
            <?php $i++;} ?>
          </tbody>
      </table> 
    </div>
  </div>
</div>

<style>
  html {
    padding: 20px;
  }

  tr:nth-child(even) {
     background-color: #f2f2f2;
  }

  th {
     padding-top: 12px;
     padding-bottom: 12px;
     text-align: center;
     background-color: blue;
     color: white;
  }

  td, th {
     border: 1px solid #ddd;
     padding: 8px;
  }

  table tbody tr td input.inputnew{
      width: 100%;
      border: 0;
      padding: 0;
      height: 24px;
      font-size: 12px;
      font-weight: 500;
      background: none;
      border-radius: 0;
      color: #223254;
  }

  iframe#lpbframe{
    overflow: none;
    height: 500px;
    border: none;
    background-color: lightblue;
  } 

  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>

<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

<script>
$(document).ready(function() {
    $('#myTable').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'csv', 'excel', 'pdf'
        ]
    } );
} );
</script>
</body>
</html>

<script type="text/javascript">
$(function() {

  $('input[name="dates"]').daterangepicker({
      autoUpdateInput: false,
      locale: {
          cancelLabel: 'Clear'
      }
  });

  $('input[name="dates"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('YYYY-MM-DD') + ' - ' + picker.endDate.format('YYYY-MM-DD'));
  });

  $('input[name="dates"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
  });

});
</script>

<script>
  $(".chosen-select").chosen();

  let status = document.getElementsByClassName('statusClass');
	let tabel = document.getElementById('myTable');
	let rows = tabel.getElementsByTagName('tr');
	for (let i = 0; i < status.length; i++) {
		if (status[i].innerHTML == 'Finished')  {
			rows[i+1].style.backgroundColor = '#90EE90';
		}
		else {
			rows[i+1].style.backgroundColor = '#FFCCCB';
		}
	} 
</script>
