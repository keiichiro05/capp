<?php
session_start();
//Import PHPMailer classes into the global namespace

require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';
require 'vendor/phpmailer/phpmailer/src/Exception.php';

//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require '/xampp/htdocs/osa-dev/osa/application/assets/Spout/Autoloader/autoload.php';

//Create an instance; passing `true` enables exceptions
//$mail = new PHPMailer\PHPMailer\PHPMailer();
$mail = new PHPMailer(true);

// connection to db
$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

// print_r($_SESSION);

try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    //$mail->Username   = 'danonecustomersolution@gmail.com';                     //SMTP username
    $mail->Username   = 'erfarianinabilah@gmail.com';                     //SMTP username
    //$mail->Password   = 'danone2021';                               //SMTP password
    $mail->Password   = 'Anakif1234';                               //SMTP password
    $mail->SMTPSecure = "tls";            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    //$mail->setFrom('danonecustomersolution@gmail.com', 'CSOM DANONE');
    $mail->setFrom('erfarianinabilah@gmail.com', 'CSOM DANONE');
    foreach ($_SESSION['to_pic'][0] as $key => $value) {
        $mail->addAddress(''.$value.'', '');     //Add a recipient
    }

    $mail->addCC(''.$_SESSION['reqEmail'].'', 'Requester');
    
    foreach ($_SESSION['cc_pic'][0] as $key => $value) {
        $mail->addCC(''.$value.'', '');     //Add a recipient
    }
    // $mail->addAddress('ellen@example.com');               //Name is optional
    // $mail->addReplyTo('info@example.com', 'Information');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    // Attachments
    $i = 0;

    echo 'INI FILENAME'.empty($_SESSION['fileName']) ? 'true': 'false';

    if (!empty($_SESSION['fileName'][0])) {
        foreach ($_SESSION['fileName'] as $key => $value) {
            echo $value;
            $mail->addAttachment('../storage/'.$value.'');         //Add attachments
        }
    }

    $path    = '/xampp/htdocs/osa-dev/osa/application/storage/soluform '.$_SESSION['idForm'];
    $files = scandir($path);
    
    $files = array_diff(scandir($path), array('.', '..'));
    
    foreach ($files as $key => $value) {
        $mail->addAttachment($path.'/'.$value);         //Add attachments

    }

    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Request SoluForm FOC - ID SoluForm: '.$_SESSION['idForm'].' - Type Request: '.$_SESSION['reqType'].' - ID Request: '.$_SESSION['idReq'].'';
    
    function printProduct() {
        $i = 0;
        $listProduk = '';
        foreach($_SESSION['produk'] as $key => $value) {
            $listProduk .= '- '.$value.' Qty: '.$_SESSION['qty'][$i++].'<br>';
        }
        return $listProduk;
    }

    $bodyEmail = "
    <table style='width:50%' rules='all'>
        <tr>
            <th>ID SoluForm</th>
            <td>".$_SESSION['idForm']."</td>
        </tr>
        <tr>
            <th>Email Req</th>
            <td>".$_SESSION['reqEmail']."</td>
        </tr>
        <tr>
            <th>Division</th>
            <td>".$_SESSION['divisi']."</td>
        </tr>
        <tr>
            <th>Type of Request</th>
            <td>".$_SESSION['reqType']."</td>
        </tr>
        <tr>
            <th>ID Request</th>
            <td>".$_SESSION['idReq']."</td>
        </tr>
        <tr>
            <th>Delivery Date</th>
            <td>".$_SESSION['delivDate']."</td>
        </tr>
        <tr>
            <th>Cost Centre</th>
            <td>".$_SESSION['cc']."</td>
        </tr>
        <tr>
            <th>Nomor MO</th>
            <td>".$_SESSION['noMo']."</td>
        </tr>
        <tr>
            <th>Sold To</th>
            <td>".$_SESSION['soldTo']."</td>
        </tr>
        <tr>
            <th>Product</th>
            <td>".printProduct()."</td>
        </tr>
        <tr>
            <th>Name PIC</th>
            <td>".$_SESSION['picName']."</td>
        </tr>
        <tr>
            <th>Contact Number PIC</th>
            <td>".$_SESSION['contact']."</td>
        </tr>
        <tr>
            <th>Province</th>
            <td>".$_SESSION['provinsi']."</td>
        </tr>
        <tr>
            <th>City</th>
            <td>".$_SESSION['kota']."</td>
        </tr>
        <tr>
            <th>Address</th>
            <td>".$_SESSION['address']."</td>
        </tr>
        <tr>
            <th>Note</th>
            <td>".$_SESSION['note']."</td>
        </tr>
    </table>
    ";
    // ID SoluForm: ".$_SESSION['idForm']   ."<br>
    // Email Req: ".$_SESSION['reqEmail'] ."<br>
    // Division: ".$_SESSION['divisi']   ."<br>
    // Type of Request: ".$_SESSION['reqType']  ."<br>
    // ID Request: ".$_SESSION['idReq']    ."<br>
    // Delivery Date: ".$_SESSION['delivDate']."<br>
    // Cost Centre: ".$_SESSION['cc']       ."<br>
    // Product: ".printProduct()."
    // Name PIC: ".$_SESSION['picName']  ."<br>
    // Contact Number PIC: ".$_SESSION['contact']  ."<br>
    // Province: ".$_SESSION['provinsi'] ."<br>
    // City: ".$_SESSION['kota']     ."<br>
    // Address: ".$_SESSION['address']  ."<br>
    // Note: ".$_SESSION['note']     ."<br>
    
    $url = "http://localhost/osa-dev/osa/application/views/foc/feedback.php?idfoc=".$_SESSION['idForm'];

    $mail->Body    = $bodyEmail;
    $mail->Body    .= 'Form Summary: '.$url;
    // $mail->AltBody = 'Form Summary: '.$url;

    $mail->send();
    echo 'Message has been sent';

    // echo $bodyEmail;
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
echo "<script> location.href='./foc.php'; </script>";
exit;

// header("Location: ./foc.php");
?>

<html>
    <style>
        table, th, td {
            border: 1px solid black;
        }
    </style>
</html>