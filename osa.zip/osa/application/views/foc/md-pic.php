<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript" src="./jquery.tabledit.js"></script>
<script type="text/javascript" src="./custom_table_edit.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php
echo '<br><br><br><br>';
session_start();

// connection to db
$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

unset($_SESSION['prevLink']);
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$_SESSION['prevLink'] = $actual_link;

// unset($_SESSION['nama_user']);

if(!isset($_SESSION['nama_user']) or empty($_SESSION['nama_user'])) {
  header("location: login.php");
}

include './tab.php';

$query = "
SELECT id, area, to_pic_cs, cc_pic_cs FROM dbdump.tbl_matrix_pic
ORDER BY id ASC
";
$result = mysqli_query($con, $query);

if(isset($_POST['deleteMd'])) {
    $query = "
    DELETE FROM dbdump.tbl_matrix_pic
    WHERE id = ".$_POST['deleteMd']."
    ";
    mysqli_query($con, $query);
    echo "<script>location.replace('./md-pic.php');</script>";
}

if(isset($_POST['addPicBtn'])) {
    $area = isset($_POST['area']) ? $_POST['area'] : '';
    $to_pic_cs = isset($_POST['toPic']) ? $_POST['toPic'] : '';
    $cc_pic_cs = isset($_POST['ccPic']) ? $_POST['ccPic'] : '';

    $query = "
    INSERT INTO dbdump.tbl_matrix_pic (area, to_pic_cs, cc_pic_cs)
    VALUES ('".$area."', '".$to_pic_cs."', '".$cc_pic_cs."')
    ";
    mysqli_query($con, $query);
    echo "<script>location.replace('./md-pic.php');</script>";
}

echo '<br><br><br><br>';
?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>
<div style="display: flex;">
    <div id="upper">
        <form action="" method="POST" style="border: 1px solid black; padding: 12px; ">
            <h3>Add New PIC</h3>

            <label for="area">Area</label><br>
            <input type="text" id="area" name="area" value="" required><br><br>

            <label for="toPic">To PIC CS</label><br>
            <input type="email" id="toPic" name="toPic" value="" required><br><br>

            <label for="ccPic">CC PIC CS</label><br>
            <input type="email" id="ccPic" name="ccPic" value="" required><br><br>

            <input id="addPicBtn" type="submit" name="addPicBtn" value='submit'>
        </form>
    </div>

    <div style="margin: 0 auto; width: 50%;">
        <div class="row">
            <div class="col-lg-12" id="frameparent">
                <table style="text-align: center; margin: 0 auto; width: 100%;" class="table-control" id="myTable">
                <h1>Master Data PIC</h1>
                <thead>
                    <tr>
                    <th>No</th>
                    <th>Area</th>
                    <th>TO PIC CS</th>
                    <th>CC PIC CS</th>
                    <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i=1; while($row = mysqli_fetch_assoc($result)) { ?>
                    <tr class="cari" id="<?php echo $row['id']; ?> ">
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['area']; ?></td>
                    <td><?php echo $row['to_pic_cs']; ?></td>
                    <td><?php echo $row['cc_pic_cs']; ?></td>
                    <td><form onSubmit="return confirm('Yakin ingin hapus?')" method="POST"><button class='btnDelete' style="background-color: red; color: white;" type='submit' name='deleteMd' value='<?php echo $row['id']; ?>'>Delete</button></form></td>
                    </tr>
                    <?php $i++;} ?>
                </tbody>
            </table> 
            </div>
        </div>
    </div>
</div>

<style>
  html {
      padding: 10px;
  }
  tr:nth-child(even) {
     background-color: #f2f2f2;
  }

  th {
     padding-top: 12px;
     padding-bottom: 12px;
     text-align: center;
     background-color: blue;
     color: white;
  }

  td, th {
     border: 1px solid #ddd;
     padding: 8px;
  }
</style>
