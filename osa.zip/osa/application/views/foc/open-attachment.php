<?php

// get id FOC
$idFoc = $_GET['idfoc'];
$filename = $_GET['filename'];

// echo $filename;

// $filename = "/xampp/htdocs/osa/application/storage/soluform 120220422/AKP 1 (1) .pdf";
  

// Header content type
header("Content-type: application/pdf");
  
header("Content-Length: " . filesize($filename));
  
// Send the file to the browser.
readfile($filename);

?>