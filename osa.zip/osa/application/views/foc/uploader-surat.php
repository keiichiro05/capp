<?php session_start(); ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<?php

include '/xampp/htdocs/osa-dev/osa/application/assets/utility_function.php';

if(!empty($_GET['a1'])){ $selected = $_GET['a1'];}
else{ $selected = 'home';}

// get id FOC
$idFoc = $_GET['idfoc'];
// echo $idFoc;
// echo $_SESSION['idfoc'];

// connection to db
$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

$query = "
SELECT * FROM dbdump.tbl_foc
WHERE id = '".$idFoc."'
";
$result = mysqli_query($con, $query);

$arrProduct = array();
$arrQty = array();

while($row=mysqli_fetch_assoc($result)){
    
    // echo $row['product'];
	$id             [0] =$row['id'];
	$reqEmail       [0] =$row['req_email'];
	$divisi         [0] =$row['divisi'];
	$req_type       [0] =$row['req_type'];
	$id_req         [0] =$row['id_req'];
	$deliv_date     [0] =$row['deliv_date'];
	$cc             [0] =$row['cc'];
	$noMo             [0] =$row['no_mo'];
	$sold_to             [0] =$row['sold_to'];
    array_push($arrProduct, $row['product']);
    array_push($arrQty, $row['qty']);
	// $product        [0] =$row['product'];
	// $qty            [0] =$row['qty'];
	$pic_name       [0] =$row['pic_name'];
	$contact_number [0] =$row['contact_number'];
	$provinsi       [0] =$row['provinsi'];
	$kota           [0] =$row['kota'];
	$detail_address [0] =$row['detail_address'];
	$note           [0] =$row['note'];
}

$_SESSION['idForm']    = $id            [0]    ;  
$_SESSION['reqEmail']  = $reqEmail      [0]    ;
$_SESSION['divisi']    = $divisi        [0]    ;
$_SESSION['reqType']   = $req_type      [0]    ;
$_SESSION['idReq']     = $id_req        [0]    ;
$_SESSION['delivDate'] = $deliv_date    [0]    ;
$_SESSION['cc']        = $cc            [0]    ;
$_SESSION['noMo']        = $no_mo            [0]    ;
$_SESSION['soldTo']        = $sold_to            [0]    ;
$_SESSION['produk']    = $arrProduct           ;
$_SESSION['qty']       = $arrQty               ;
$_SESSION['picName']   = $pic_name      [0]    ;
$_SESSION['contact']   = $contact_number[0]    ; 
$_SESSION['provinsi']  = $provinsi      [0]    ;
$_SESSION['kota']      = $kota          [0]    ;
$_SESSION['address']   = $detail_address[0]    ;
$_SESSION['note']      = $note          [0]    ;

if ($req_type[0] == 'BRIGHT') {
    $soldTo = '950042237';
}
else if ($req_type[0] == 'AKP') {
    foreach ($arrProduct as $key => $value) {
        if (strpos($value, 'MIZONE') !== false) {
            $soldTo = '950042247';
            break;
        }
        else {
            $soldTo = '950042246';
        }
    }
}
else if ($req_type[0] == 'BLUE PLANNER') {
    $soldTo = $sold_to[0];
}

$query = "
SELECT s.plant_name
FROM db_depo.tbm_plant s
WHERE s.plant_type = 'DEPO'
";
$result = mysqli_query($con, $query);
$arrDepo = array();
while($row=mysqli_fetch_assoc($result)){
    array_push($arrDepo, $row['plant_name']);
}
array_unshift($arrDepo, '');

$query = "
SELECT s.plant_name
FROM db_depo.tbm_plant s
WHERE s.plant_type <> 'DEPO'
";
$result = mysqli_query($con, $query);
$arrPlant = array();
while($row=mysqli_fetch_assoc($result)){
    array_push($arrPlant, $row['plant_name']);
}
array_unshift($arrPlant, '');

// print_r($arrDepo);

// if (isset($_POST['submit']) and $_POST['submit'] == 'Send Back') {
//     echo 'send back';
// }

if (isset($_POST['submit'])) {
    $soldTo         = isset($_POST['soldTo']         ) ? $_POST['soldTo']          : '';
    $delivMethod    = isset($_POST['typeDeliv']    ) ? $_POST['typeDeliv']     : '';
    $soNumber       = isset($_POST['soNumber']       ) ? $_POST['soNumber']        : '';
    $plantType      = isset($_POST['plantType']      ) ? $_POST['plantType']       : '';
    $depoName       = isset($_POST['depoName']       ) ? $_POST['depoName']        : '';
    $distName       = isset($_POST['distributorName']) ? $_POST['distributorName'] : '';
    $rexInfo        = isset($_POST['byRex']          ) ? $_POST['byRex']           : '';
    $otherInfo      = isset($_POST['otherInfo']      ) ? $_POST['otherInfo']       : '';
    $finalDelivDate = isset($_POST['finalDelivDate'] ) ? $_POST['finalDelivDate']  : '';
    $emailReceiver  = isset($_POST['emailReceiver']  ) ? $_POST['emailReceiver']   : '';
    $picName        = isset($_POST['picName']        ) ? $_POST['picName']         : '';  
    $add_note       = isset($_POST['note']           ) ? $_POST['note']            : '';
    
    $_SESSION['soldTo'] = $soldTo        ;
    $_SESSION['delivMethod'] = $delivMethod   ;
    $_SESSION['soNumber'] = $soNumber      ;
    $_SESSION['plantType'] = $plantType     ;
    $_SESSION['depoName'] = $depoName      ;
    $_SESSION['distName'] = $distName      ;
    $_SESSION['rexInfo'] = $rexInfo       ;
    $_SESSION['otherInfo'] = $otherInfo     ;
    $_SESSION['finalDelivDate'] = $finalDelivDate;
    $_SESSION['emailReceiver'] = $emailReceiver ;
    $_SESSION['picName'] = $picName       ;
    $_SESSION['add_note'] = $add_note      ;

    $_SESSION['fileName'] = array();

    echo "<script> location.href='./final-email.php'; </script>";
}

?>

<html>
    <table>
        <tr>
            <th>ID SoluForm</th>
            <td><?php echo $id[0]; ?></td>
        </tr>
        <tr>
            <th>Email Req</th>
            <td><?php echo $reqEmail[0]; ?></td>
        </tr>
        <tr>
            <th>Division</th>
            <td><?php echo $divisi[0]; ?></td>
        </tr>
        <tr>
            <th>Type of Request</th>
            <td><?php echo $req_type[0]; ?></td>
        </tr>
        <tr>
            <th>ID Request</th>
            <td><?php echo $id_req[0]; ?></td>
        </tr>
        <tr>
            <th>Delivery Date</th>
            <td><?php echo $deliv_date[0]; ?></td>
        </tr>
        <tr>
            <th>Cost Centre</th>
            <td><?php echo $cc[0]; ?></td>
        </tr>
        <tr>
            <th>Product</th>
            <td>
            <?php 
            $i = 0;
            // print_r($product);
            foreach ($arrProduct as $key => $value) {
                // echo $value;
                echo $value.' Qty: '.$arrQty[$i++].'</br>';
            }
            ?>
            </td>          
        </tr>
        <tr>
            <th>Name PIC</th>
            <td><?php echo $pic_name[0]; ?></td>
        </tr>
        <tr>
            <th>Contact Number PIC</th>
            <td><?php echo $contact_number[0]; ?></td>
        </tr>
        <tr>
            <th>Province</th>
            <td><?php echo $provinsi[0]; ?></td>
        </tr>
        <tr>
            <th>City</th>
            <td><?php echo $kota[0]; ?></td>
        </tr>
        <tr>
            <th>Address</th>
            <td><?php echo $detail_address[0]; ?></td>
        </tr>
        <tr>
            <th>Note</th>
            <td><?php echo $note[0]; ?></td>
        </tr>
    </table>

    <div id='feedback-form'>
        <h1>ID FORM: <?php echo $id[0]; ?></h1>
        <form action="" method="POST" enctype="multipart/form-data">
            <label for='uploadFile'>Upload Attachment(s)</label>
            <input type='file' id='uploadFile' name='uploadFile[]' multiple accept="application/pdf, application/msword, application/vnd.ms-excel, application/zip, application/x-rar-compressed, image/*" required><br>
            <?php 
                // $_SESSION['fileName'] = array();
                $allowedTypes = array('application/pdf', 'application/msword', 'application/vnd.ms-excel', 'application/zip', 'application/x-rar-compressed', 'image/png', 'image/jpg', 'image/jpeg');
                if (isset($_FILES["uploadFile"])) {
                    $countFile = 0;
                    foreach ($_FILES["uploadFile"]["type"] as $fileType) {
                        if (in_array($fileType, $allowedTypes)) {
                            $fileName = $_FILES["uploadFile"]["tmp_name"][$countFile];
                            $fileExtension = explode('/', $fileType)[1];

                            $path = '/xampp/htdocs/osa-dev/osa/application/storage/soluform '.$_SESSION['idForm'];
                            if ( !is_dir($path)) {
                                mkdir($path);
                            }
                            move_uploaded_file($fileName, '/xampp/htdocs/osa-dev/osa/application/storage/soluform '.$_SESSION['idForm'].'/Surat Penunjukkan '.$_SESSION['reqType'].' '.$_SESSION['idReq'].' ('.($countFile+1).') '.'.'.$fileExtension);
                            array_push($_SESSION['fileName'], 'Surat Penunjukkan '.$_SESSION['reqType'].' '.$_SESSION['idReq'].' ('.($countFile+1).') '.'.'.$fileExtension);
                            echo '<p>Successfully uploaded for '.$_FILES["uploadFile"]["name"][$countFile].'</p>';
                            // array_push($_SESSION['fileName'], $_FILES["uploadFile"]["name"][$countFile]);
                            $countFile++;
                        } 
                        else {
                            echo 'File type not allowed!';
                        }
                    } 
                }
                // print_r($_FILES['uploadFile']['name'][0]);           
            ?>

            <input id="submitBtn" type="submit" name="submit" value='submit'>
        </form>
    </div>

    <style>
        html {
            padding: 20px;
        }

        #feedback-form {
            margin: auto;
            width: fit-content;
            border: 3px solid green;
            padding: 10px;
            float: right;
            padding: 10px;
            display: block;
            width: 68%;
        }

        table {
            margin: auto;
            float: left;
            padding: 10px;
            display: block;
            width: 28%;
        }

        table, th, td {
            border: 1px solid black;
        }

        .remove-lnk {
            color: red;
        }

        .add-btn {
            color: green;
        }
    </style>
</html>