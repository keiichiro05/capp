<?php
session_start();

$provinsi = $_SESSION['provinsi'];
    
    // Buat Koneksinya
    $db1 = new mysqli('localhost', 'root', '', 'dbdump');
 
	echo "<option value=''>Pilih Provinsi</option>";
 
	$query = "SELECT * FROM provinsi ORDER BY nama ASC";
	$dewan1 = $db1->prepare($query);
	$dewan1->execute();
	$res1 = $dewan1->get_result();
	while ($row = $res1->fetch_assoc()) {
		if ($provinsi == $row['nama']) {
			echo "<option selected='selected' value='" . $row['id_prov'].':'.$row['nama'] . "'>" . $row['nama'] . "</option>";
		}
		else if ($provinsi != $row['nama']) {
			echo "<option value='" . $row['id_prov'].':'.$row['nama'] . "'>" . $row['nama'] . "</option>";
		}
	}
?>