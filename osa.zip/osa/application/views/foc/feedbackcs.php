<?php session_start(); ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<?php
unset($_SESSION['prevLink']);
// unset($_SESSION['nama_user']);
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$_SESSION['prevLink'] = $actual_link;

// unset($_SESSION['nama_user']);

if(!isset($_SESSION['nama_user']) or empty($_SESSION['nama_user'])) {
  header("location: login.php");
}

include '/xampp/htdocs/osa-dev/osa/application/assets/utility_function.php';
include './tab.php';

if(!empty($_GET['a1'])){ $selected = $_GET['a1'];}
else{ $selected = 'home';}

// get id FOC
$idFoc = $_GET['idfoc'];
// echo $idFoc;
// echo $_SESSION['idfoc'];

// connection to db
$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

$query = "
SELECT * FROM dbdump.tbl_foc
WHERE id = '".$idFoc."'
";
$result = mysqli_query($con, $query);

$arrProduct = array();
$arrQty = array();

while($row=mysqli_fetch_assoc($result)){
    
    // echo $row['product'];
	$id             [0] =$row['id'];
	$reqEmail       [0] =$row['req_email'];
	$divisi         [0] =$row['divisi'];
	$req_type       [0] =$row['req_type'];
	$id_req         [0] =$row['id_req'];
	$deliv_date     [0] =$row['deliv_date'];
	$cc             [0] =$row['cc'];
	$noMo             [0] =$row['no_mo'];
	$sold_to           [0] =$row['sold_to'];
    array_push($arrProduct, $row['product']);
    array_push($arrQty, $row['qty']);
	// $product        [0] =$row['product'];
	// $qty            [0] =$row['qty'];
	$pic_name       [0] =$row['pic_name'];
	$contact_number [0] =$row['contact_number'];
	$provinsi       [0] =$row['provinsi'];
	$kota           [0] =$row['kota'];
	$detail_address [0] =$row['detail_address'];
	$note           [0] =$row['note'];
}

$_SESSION['idForm']    = $id            [0]    ;  
$_SESSION['reqEmail']  = $reqEmail      [0]    ;
$_SESSION['divisi']    = $divisi        [0]    ;
$_SESSION['reqType']   = $req_type      [0]    ;
$_SESSION['idReq']     = $id_req        [0]    ;
$_SESSION['delivDate'] = $deliv_date    [0]    ;
$_SESSION['cc']        = $cc            [0]    ;
$_SESSION['noMo']        = $noMo            [0]    ;
$_SESSION['soldTo']        = $sold_to            [0]    ;
$_SESSION['produk']    = $arrProduct           ;
$_SESSION['qty']       = $arrQty               ;
$_SESSION['picName']   = $pic_name      [0]    ;
$_SESSION['contact']   = $contact_number[0]    ; 
$_SESSION['provinsi']  = $provinsi      [0]    ;
$_SESSION['kota']      = $kota          [0]    ;
$_SESSION['address']   = $detail_address[0]    ;
$_SESSION['note']      = $note          [0]    ;

if ($req_type[0] == 'BRIGHT') {
    $soldTo = '950042237';
}
else if ($req_type[0] == 'AKP') {
    foreach ($arrProduct as $key => $value) {
        if (strpos($value, 'MIZONE') !== false) {
            $soldTo = '950042247';
            break;
        }
        else {
            $soldTo = '950042246';
        }
    }
}
else if ($req_type[0] == 'BLUE PLANNER') {
    $soldTo = $sold_to[0];
}

$query = "
SELECT s.plant_name
FROM db_depo.tbm_plant s
WHERE s.plant_type = 'DEPO'
";
$result = mysqli_query($con, $query);
$arrDepo = array();
while($row=mysqli_fetch_assoc($result)){
    array_push($arrDepo, $row['plant_name']);
}
array_unshift($arrDepo, '');

$query = "
SELECT s.plant_name
FROM db_depo.tbm_plant s
WHERE s.plant_type <> 'DEPO'
";
$result = mysqli_query($con, $query);
$arrPlant = array();
while($row=mysqli_fetch_assoc($result)){
    array_push($arrPlant, $row['plant_name']);
}
array_unshift($arrPlant, '');

// print_r($arrDepo);

// if (isset($_POST['submit']) and $_POST['submit'] == 'Send Back') {
//     echo 'send back';
// }

if (isset($_POST['submit'])) {
    $soldTo         = isset($_POST['soldTo']         ) ? $_POST['soldTo']          : '';
    $delivMethod    = isset($_POST['typeDeliv']    ) ? $_POST['typeDeliv']     : '';
    $soNumber       = isset($_POST['soNumber']       ) ? $_POST['soNumber']        : '';
    $plantType      = isset($_POST['plantType']      ) ? $_POST['plantType']       : '';
    $depoName       = isset($_POST['depoName']       ) ? $_POST['depoName']        : '';
    $distName       = isset($_POST['distributorName']) ? $_POST['distributorName'] : '';
    $rexInfo        = isset($_POST['byRex']          ) ? $_POST['byRex']           : '';
    $otherInfo      = isset($_POST['otherInfo']      ) ? $_POST['otherInfo']       : '';
    $finalDelivDate = isset($_POST['finalDelivDate'] ) ? $_POST['finalDelivDate']  : '';
    $emailReceiver  = isset($_POST['emailReceiver']  ) ? $_POST['emailReceiver']   : '';
    $picName        = isset($_POST['picName']        ) ? $_POST['picName']         : '';  
    $add_note       = isset($_POST['note']           ) ? $_POST['note']            : '';
    
    $_SESSION['soldTo'] = $soldTo        ;
    $_SESSION['delivMethod'] = $delivMethod   ;
    $_SESSION['soNumber'] = $soNumber      ;
    $_SESSION['plantType'] = $plantType     ;
    $_SESSION['depoName'] = $depoName      ;
    $_SESSION['distName'] = $distName      ;
    $_SESSION['rexInfo'] = $rexInfo       ;
    $_SESSION['otherInfo'] = $otherInfo     ;
    $_SESSION['finalDelivDate'] = $finalDelivDate;
    $_SESSION['emailReceiver'] = $emailReceiver ;
    $_SESSION['picName'] = $picName       ;
    $_SESSION['add_note'] = $add_note      ;

    $query = "
    UPDATE dbdump.tbl_foc 
    SET 
    id = '".$idFoc."', 
    sold_to = '".$soldTo."', 
    deliv_method = '".$delivMethod."', 
    so_number = '".$soNumber."', 
    plant_type = '".$plantType."', 
    depo_name = '".$depoName."', 
    distributor_name = '".$distName."', 
    rex_info = '".$rexInfo."', 
    pickup_by = '".$otherInfo."', 
    final_deliv_date = '".$finalDelivDate."', 
    email_receiver_feedback = '".$emailReceiver."', 
    name_pic_feedback = '".$picName."', 
    additional_comment = '".$add_note."'
    WHERE id = '".$idFoc."'
    ";
    mysqli_query($con, $query);


    $_SESSION['fileName'] = array();
    foreach ($_FILES['uploadFile']['name'] as $key => $value) {
        array_push($_SESSION['fileName'], $value); 
    }

    if ($_POST['submit'] == 'submit') {
        echo "<script> location.href='./final-email.php'; </script>";
    }
    else {
        echo "<script> location.href='./email-upload-surat.php'; </script>";
    }
}

if (isset($_POST['revisiBtn'])) {
    // echo 'matched';
    echo "<script> location.href='./foc-revisi.php?idfoc=".$idFoc."'; </script>";
}
echo '<br><br><br>';
?>

<html>
    <div style="display: flex;">
        <div id="upper">
            <table>
                <tr>
                    <th>ID SoluForm</th>
                    <td><?php echo $id[0]; ?></td>
                </tr>
                <tr>
                    <th>Email Req</th>
                    <td><?php echo $reqEmail[0]; ?></td>
                </tr>
                <tr>
                    <th>Division</th>
                    <td><?php echo $divisi[0]; ?></td>
                </tr>
                <tr>
                    <th>Type of Request</th>
                    <td><?php echo $req_type[0]; ?></td>
                </tr>
                <tr>
                    <th>ID Request</th>
                    <td><?php echo $id_req[0]; ?></td>
                </tr>
                <tr>
                    <th>Delivery Date</th>
                    <td><?php echo $deliv_date[0]; ?></td>
                </tr>
                <tr>
                    <th>Cost Centre</th>
                    <td><?php echo $cc[0]; ?></td>
                </tr>
                <tr>
                    <th>Nomor MO</th>
                    <td><?php echo $noMo[0]; ?></td>
                </tr>
                <tr>
                    <th>Sold To</th>
                    <td><?php echo $sold_to[0]; ?></td>
                </tr>
                <tr>
                    <th>Product</th>
                    <td>
                    <?php 
                    $i = 0;
                    // print_r($product);
                    foreach ($arrProduct as $key => $value) {
                        // echo $value;
                        echo $value.' Qty: '.$arrQty[$i++].'</br>';
                    }
                    ?>
                    </td>          
                </tr>
                <tr>
                    <th>Name PIC</th>
                    <td><?php echo $pic_name[0]; ?></td>
                </tr>
                <tr>
                    <th>Contact Number PIC</th>
                    <td><?php echo $contact_number[0]; ?></td>
                </tr>
                <tr>
                    <th>Province</th>
                    <td><?php echo $provinsi[0]; ?></td>
                </tr>
                <tr>
                    <th>City</th>
                    <td><?php echo $kota[0]; ?></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td><?php echo $detail_address[0]; ?></td>
                </tr>
                <tr>
                    <th>Note</th>
                    <td><?php echo $note[0]; ?></td>
                </tr>
                <?php 
                $folder = "/xampp/htdocs/osa-dev/osa/application/storage/soluform ".$idFoc;
                echo "<tr>";
                echo "<th>Attachment</th>";
                echo "<td>";
                foreach(glob($folder.'/*.*') as $file) {
                    $url = "http://localhost/osa-dev/osa/application/views/foc/open-attachment.php?idfoc=".$idFoc."&filename=".$file.""; 
                    echo
                    "
                    <a target='_blank' id='linkCs' href='".$url."'>See attachment</a><br>
                    ";
                }
                echo "<td>";
                echo "</tr>";
            
                ?>
            </table>
            <form action="" method="POST" enctype="multipart/form-data" style="text-align: center;">
                <input id="revisiBtn" type="submit" name="revisiBtn" value='Revisi'>
            </form>
        </div>

        <div id='feedback-form'>
            <h1>ID FORM: <?php echo $id[0]; ?></h1>
            <form action="" method="POST" enctype="multipart/form-data">
                <label for="soldTo">Sold To</label><br>
                <input type="text" id="soldTo" name="soldTo" style="width: 100%" value="<?php echo $soldTo; ?>" required><br> 

                <!-- <label for="stock">Konfirmasi jumlah stock</label><br>
                <input type="number" id="stock" name="stock"><br> -->

                <label for="typeDeliv">Pickup By</label><br>
                <div id='delivMethod'>
                    <input type="radio" id="typeDeliv1" name="typeDeliv" value="byDepo" required>By Depo<br>
                    <input type="radio" id="typeDeliv2" name="typeDeliv" value="byDistributor" required>By Distributor<br>
                    <input type="radio" id="typeDeliv3" name="typeDeliv" value="byREX" required>By REX<br>
                    <input type="radio" id="typeDeliv4" name="typeDeliv" value="byOther" required>By Other<br>
                </div>

                <span id="r-text"></span>
                <div id='delivInfo'></div>

                <script>
                    $('input[type=radio]').click(function(e) {//jQuery works on clicking radio box
                        $('#r-text').html('Delivery Information');
                        let value = $(this).val(); //Get the clicked checkbox value
                        if (value == 'byDepo') {
                            $('#delivInfo').html('<label for="soNumber">SO Number</label><br><input type="text" id="soNumber" name="soNumber" required><br><label for="plantType">Plant Type</label><br><select name="plantType" id="plantType" required><option value=""></option><option value="depo">DEPO</option><option value="plant">NOT DEPO</option></select><br><label for="depoName">Depo Name</label><br><select name="depoName" id="depoName" required><option value=""></option></select><br>');
                            $('#plantType').change(function() {
                                let plantType = $('#plantType').val();
                                $('#depoName').html('');
                                if ((plantType) === 'depo') {
                                    let $optionDepo = $('#depoName');
                                    let listDepo = <?php echo json_encode($arrDepo); ?>;
                                    for (const namaDepo of listDepo) {
                                        $optionDepo.append(`<option value='${namaDepo}'>${namaDepo}</option>`);
                                    }
                                }
                                else if ((plantType) === 'plant') {
                                    let $optionDepo = $('#depoName');
                                    let listDepo = <?php echo json_encode($arrPlant); ?>;
                                    for (const namaDepo of listDepo) {
                                        $optionDepo.append(`<option value='${namaDepo}'>${namaDepo}</option>`);
                                    }
                                }
                            });
                        }
                        else if (value == 'byDistributor') {
                            $('#delivInfo').html('<label for="distributorName">Distributor Name</label><br><input type="text" id="distributorName" name="distributorName" required><br>');
                            $('#checkboxSurat').html('<input type="checkbox" id="suratDist" name="suratDist" value="suratDist"><label for="suratDist">Minta Surat Penunjukkan</label><br>');
                            let checkboxSurat = document.getElementById('suratDist');
                            $('#suratDist').change(function() {
                                if (checkboxSurat.checked) {
                                    $('#submitBtn').prop('value', 'Send Back'); 
                                }
                                else {
                                    $('#submitBtn').prop('value', 'submit'); 
                                }
                            });
                        }
                        else if (value == 'byREX') {
                            $('#delivInfo').html('<input type="radio" id="rexInfo" name="rexInfo" value="byRex" required>By REX<br>');
                        }
                        else {
                            $('#delivInfo').html('<label for="otherInfo">Pickup By</label><br><input type="text" id="otherInfo" name="otherInfo" required><br>');
                        }
                    });
                </script>

                <label for="finalDelivDate">Final Delivery/Pickup Date</label><br>
                <input type="date" id="finalDelivDate" name="finalDelivDate" min="<?php echo date("Y-m-d") ?>" required><br>

                <label for="emailReceiver">Email Feedback Receiver</label><br>
                <input type="email" id="emailReceiver" name="emailReceiver" style="width: 100%" placeholder="Dipisahkan dengan ; (titik koma)" required><br>

                <label for="picName">Name PIC Feedback</label><br>
                <input type="text" id="picName" style="width: 100%" name="picName" required><br>

                <label for="note"></label>Additional Comment<br>
                <input type="text" id="note" name="note" style="width: 100%" required><br><br>

                <label for='uploadFile'>Upload Attachment(s)</label>
                <input type='file' id='uploadFile' name='uploadFile[]' multiple accept="application/pdf, application/msword, application/vnd.ms-excel, application/zip, application/x-rar-compressed, image/*"><br>
                <?php 
                    // $_SESSION['fileName'] = array();
                    $allowedTypes = array('application/pdf', 'application/msword', 'application/vnd.ms-excel', 'application/zip', 'application/x-rar-compressed', 'image/png', 'image/jpg', 'image/jpeg');
                    if (isset($_FILES["uploadFile"])) {
                        $countFile = 0;
                        foreach ($_FILES["uploadFile"]["type"] as $fileType) {
                            if (in_array($fileType, $allowedTypes)) {
                                $fileName = $_FILES["uploadFile"]["tmp_name"][$countFile];
                                $fileExtension = explode('/', $fileType)[1];

                                $path = '/xampp/htdocs/osa-dev/osa/application/storage/soluform '.$_SESSION['idForm'];
                                if ( !is_dir($path)) {
                                    mkdir($path);
                                }
                                move_uploaded_file($fileName, '/xampp/htdocs/osa-dev/osa/application/storage/soluform '.$_SESSION['idForm'].'/Surat Penunjukkan '.$_SESSION['reqType'].' '.$_SESSION['idReq'].' ('.($countFile+1).') '.'.'.$fileExtension);
                                array_push($_SESSION['fileName'], 'Surat Penunjukkan '.$_SESSION['reqType'].' '.$_SESSION['idReq'].' ('.($countFile+1).') '.'.'.$fileExtension);
                                echo '<p>Successfully uploaded for '.$_FILES["uploadFile"]["name"][$countFile].'</p>';
                                // array_push($_SESSION['fileName'], $_FILES["uploadFile"]["name"][$countFile]);
                                $countFile++;
                            } 
                            else {
                                echo 'File type not allowed!';
                            }
                        } 
                    }
                    // print_r($_FILES['uploadFile']['name'][0]);           
                ?>
                <div id='checkboxSurat'></div>
                <input id="submitBtn" type="submit" name="submit" value='submit'>
            </form>
        </div>
    </div>

    <style>
        html {
            padding: 10px;
        }

        #feedback-form {
            margin: auto;
            width: fit-content;
            border: 3px solid green;
            padding: 10px;
            /* float: right; */
            padding: 10px;
            display: block;
            width: 50%;
        }

        /* #upper {
            clear: left;
            float: left;
        } */

        table {
            margin: auto;
            /* float: left; */
            padding: 10px;
            display: block;
            /* width: 28%; */
        }

        table, th, td {
            border: 1px solid black;
        }

        .remove-lnk {
            color: red;
        }

        .add-btn {
            color: green;
        }
    </style>
</html>