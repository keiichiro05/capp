<?php 

$path    = '../storage/soluform 99920220222';
$files = scandir($path);

$files = array_diff(scandir($path), array('.', '..'));

print_r($files);

?>