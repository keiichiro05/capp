<?php

// connection to db
$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

$input = filter_input_array(INPUT_POST);
if ($input['action'] == 'edit') {
$update_field='';
if(isset($input['area'])) {
$update_field.= "area='".$input['area']."'";
} else if(isset($input['to_pic_cs'])) {
$update_field.= "to_pic_cs='".$input['to_pic_cs']."'";
} else if(isset($input['cc_pic_cs'])) {
$update_field.= "cc_pic_cs='".$input['cc_pic_cs']."'";
} 
if($update_field && $input['id']) {
$sql_query = "UPDATE dbdump.tbl_matrix_pic SET $update_field WHERE id='" . $input['id'] . "'";
mysqli_query($con, $sql_query) or die("database error:". mysqli_error($con));
}
}
?>