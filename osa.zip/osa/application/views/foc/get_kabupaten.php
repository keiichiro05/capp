<?php
session_start();
$kota = $_SESSION['kota'];
    // Buat Koneksinya
    $db1 = new mysqli('localhost', 'root', '', 'dbdump');

    $provinsi = $_POST['provinsi'];
 
	echo "<option value=''>Pilih Kabupaten</option>";
 
	$query = "SELECT * FROM kabupaten WHERE id_prov=? ORDER BY nama ASC";
	$dewan1 = $db1->prepare($query);
	$dewan1->bind_param("i", $provinsi);
	$dewan1->execute();
	$res1 = $dewan1->get_result();
	while ($row = $res1->fetch_assoc()) {
		if ($kota == $row['nama']) {
			echo "<option selected='selected' value='" . $row['id_kab'].':'.$row['nama'] . "'>" . $row['nama'] . "</option>";
		}
		else if ($kota != $row['nama']) {
			echo "<option value='" . $row['id_kab'].':'.$row['nama'] . "'>" . $row['nama'] . "</option>";
		}
	}
?>