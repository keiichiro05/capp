$(document).ready(function () {
  $("#myTable").Tabledit({
    deleteButton: false,
    editButton: false,
    columns: {
      identifier: [0, "id"],
      editable: [
        [1, "area"],
        [2, "to_pic_cs"],
        [3, "cc_pic_cs"],
      ],
    },
    hideIdentifier: true,
    url: "live_edit.php",
  });
});
