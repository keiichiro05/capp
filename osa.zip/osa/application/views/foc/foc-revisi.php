<?php session_start(); ?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<?php
$dom = new DOMDocument();

include '/xampp/htdocs/osa-dev/osa/application/assets/utility_function.php';

// connection to db
$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

// echo 'hello world';
if(!empty($_GET['a1'])){ $selected = $_GET['a1'];}
else{ $selected = 'home';}

$teks = $dom -> getElementById('r-text');

$str = "SELECT p.prd_diskripsi FROM db_depo.tbm_product p";
$result = mysqli_query($con,$str);
while($row=mysqli_fetch_assoc($result)){
	$mProduk[$row['prd_diskripsi']]=$row['prd_diskripsi'];
}
// array_unshift($mProduk, '');
array_push($mProduk, 'Others');

// $namaProduk = getPreValue("cmdProduk", key($mProduk));
$namaProduk = '';
// echo $namaProduk;

function cmbBoxFoc($name,$class,$id,$ref,$dataCat,$other){
	$kode='<select class="'.$class.'" name="'.$name.'" id="'.$id.'" '.$other.' required>'."\n";
    $kode .= '<option value=""></option>';
	foreach ($dataCat AS $row) {
		$kode .='<option value="'.key($dataCat).'"';
		if(key($dataCat)==$ref) {
        	$kode .=' selected';
        }
		$kode .='>'.$row.'</option>'."\n";
		next($dataCat);
		}
		$kode .='</select>'."\n";
		return $kode;
}

$menuProduk = cmbBoxFoc("cmdProduk[]","","cmdsProduk",$namaProduk,$mProduk,"");

// List variable POST dari form
// $idForm = isset($_POST['idForm']) ? $_POST['idForm'] : '';
// $reqEmail = isset($_POST['reqEmail']) ? $_POST['reqEmail'] : '';
// $divisi = isset($_POST['cmbBoxDivisi']) ? $_POST['cmbBoxDivisi'] : '';
// $reqType = isset($_POST['reqType']) ? $_POST['reqType'] : '';
// $idReq = isset($_POST['idReq']) ? $_POST['idReq'] : '';
// $delivDate = isset($_POST['delivDate']) ? $_POST['delivDate'] : '';
// $cc = isset($_POST['cc']) ? $_POST['cc'] : '';
// $produk = isset($_POST['cmdProduk']) ? $_POST['cmdProduk'] : '';
// $qty = isset($_POST['qty']) ? $_POST['qty'] : '';
// $picName = isset($_POST['picName']) ? $_POST['picName'] : '';
// $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
// $provinsi = isset($_POST['provinsi']) ? (explode(':', $_POST['provinsi'])) : '';
// $kota = isset($_POST['kabupaten']) ? (explode(':', $_POST['kabupaten'])) : '';
// $address = isset($_POST['address']) ? $_POST['address'] : '';
// $note = isset($_POST['note']) ? $_POST['note'] : '';

// get id FOC
$idFoc = $_GET['idfoc'];

$query = "
SELECT * FROM dbdump.tbl_foc
WHERE id = '".$idFoc."'
";
$result = mysqli_query($con, $query);
$arrProduct = array();
$arrQty = array();

// print_r($row=mysqli_fetch_assoc($result));

while($row=mysqli_fetch_assoc($result)){
    
    // echo $row['product'];
	$id             [0] =isset($row['id']        ) ? $row['id'] : ''               ;
	$reqEmail       [0] =isset($row['req_email'] ) ? $row['req_email'] : ''               ;
	$divisi         [0] =isset($row['divisi']    ) ? $row['divisi'] : ''               ;
	$req_type       [0] =isset($row['req_type']  ) ? $row['req_type']: ''               ;
	$id_req         [0] =isset($row['id_req']    ) ? $row['id_req']: ''               ;
	$deliv_date     [0] =isset($row['deliv_date']) ? $row['deliv_date']: ''               ;
	$cc             [0] =isset($row['cc']        ) ? $row['cc']: ''               ;
	$noMo             [0] =isset($row['no_mo']        ) ? $row['no_mo']: ''               ;
	$sold_to             [0] =isset($row['sold_to']        ) ? $row['sold_to']: ''               ;
    array_push($arrProduct, $row['product'])                    ;
    array_push($arrQty, $row['qty']);
	$product        [0] =isset($row['product']        ) ? $row['product'] : ''       ;
	$qty            [0] =isset($row['qty']            ) ? $row['qty'] : ''       ;
	$pic_name       [0] =isset($row['pic_name']       ) ? $row['pic_name'] : ''       ;
	$contact_number [0] =isset($row['contact_number'] ) ? $row['contact_number'] : ''       ;
	$provinsi       [0] =isset($row['provinsi']       ) ? $row['provinsi'] : ''       ;
	$kota           [0] =isset($row['kota']           ) ? $row['kota'] : ''       ;
	$detail_address [0] =isset($row['detail_address'] ) ? $row['detail_address'] : ''       ;
	$note           [0] =isset($row['note']           ) ? $row['note'] : ''       ;
}



$_SESSION['provinsi'] = $provinsi[0];
$_SESSION['kota'] = $kota[0];

// print_r($arrProduct);


// // echo $idReq;
// echo $divisi[0];
// echo $req_type[0];

// print_r($row);


// Get POST value from form
// $reqEmail = isset($_POST['reqEmail']) ? $_POST['reqEmail'] : '';
// $divisi = isset($_POST['cmbBoxDivisi']) ? $_POST['cmbBoxDivisi'] : '';
// $reqType = isset($_POST['reqType']) ? $_POST['reqType'] : '';
// $idReq = isset($_POST['idReq']) ? $_POST['idReq'] : '';
// $delivDate = isset($_POST['delivDate']) ? $_POST['delivDate'] : '';
// $cc = isset($_POST['cc']) ? $_POST['cc'] : '';
// $produk = isset($_POST['cmdProduk']) ? $_POST['cmdProduk'] : '';
// $qty = isset($_POST['qty']) ? $_POST['qty'] : '';
// $picName = isset($_POST['picName']) ? $_POST['picName'] : '';
// $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
// $provinsi = isset($_POST['provinsi']) ? (explode(':', $_POST['provinsi'])) : '';
// $kota = isset($_POST['kabupaten']) ? (explode(':', $_POST['kabupaten'])) : '';
// $address = isset($_POST['address']) ? $_POST['address'] : '';
// $note = isset($_POST['note']) ? $_POST['note'] : '';

if (isset($_POST['submit'])) {
    // Get POST value from form
    $reqEmail = isset($_POST['reqEmail']) ? $_POST['reqEmail'] : '';
    $divisi = isset($_POST['cmbBoxDivisi']) ? $_POST['cmbBoxDivisi'] : '';
    $reqType = isset($_POST['reqType']) ? $_POST['reqType'] : '';
    $idReq = isset($_POST['idReq']) ? $_POST['idReq'] : '';
    $delivDate = isset($_POST['delivDate']) ? $_POST['delivDate'] : '';
    $cc = isset($_POST['cc']) ? $_POST['cc'] : '';
    $noMo = isset($_POST['noMo']) ? $_POST['noMo'] : '';
    $soldTo = isset($_POST['soldTo']) ? $_POST['soldTo'] : '';
    $produk = isset($_POST['cmdProduk']) ? $_POST['cmdProduk'] : '';
    $qty = isset($_POST['qty']) ? $_POST['qty'] : '';
    $picName = isset($_POST['picName']) ? $_POST['picName'] : '';
    $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
    $provinsi = isset($_POST['provinsi']) ? (explode(':', $_POST['provinsi'])) : '';
    $kota = isset($_POST['kabupaten']) ? (explode(':', $_POST['kabupaten'])) : '';
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $note = isset($_POST['note']) ? $_POST['note'] : '';

    $delivDateToString = str_replace('-', '', $delivDate);

    // $query = "
    // SELECT
    //     CASE 
    //         WHEN MAX(id) IS NULL THEN @max_id := 1 ELSE @max_id := (MAX(id) + 1)
    //     END AS max_id
    // FROM dbdump.tbl_foc;
    // ";
    // $result = mysqli_query($con, $query);

    // while($row=mysqli_fetch_assoc($result)){
    //     $maxID[$row['max_id']]=$row['max_id'];
    //     foreach ($maxID as $key => $value) {
    //         $id = $value;
    //     }
    // };

    $query = "
    DELETE FROM dbdump.tbl_foc
    WHERE id = '".$idFoc."'
    ";
    mysqli_query($con, $query);

    
    $counter = 0;
    foreach ($produk as $key => $value) {
        $query = "
        REPLACE INTO dbdump.tbl_foc (id, req_email, divisi, req_type, id_req, deliv_date, cc, product, qty, pic_name, contact_number, provinsi, kota, detail_address, note, timestamp_req, no_mo, sold_to)
        VALUES ('".$idReq.$delivDateToString."', '".$reqEmail."', '".$divisi."', '".$reqType."', '".$idReq."', 
        '".$delivDate."', '".$cc."', '".$value."', '".$qty[$counter++]."', '".$picName."', 
        '".$contact."', '".$provinsi[1]."', '".$kota[1]."', '".$address."', '".$note."', NOW(), '".$noMo."', '".$soldTo."')
        ";
        mysqli_query($con, $query);
    }
    echo $query;

    // echo $_POST['provinsi'];

    $query = "
    SELECT mp.area, mp.to_pic_cs, mp.cc_pic_cs
    FROM dbdump.tbl_matrix_area ma, dbdump.tbl_matrix_pic mp
    WHERE ma.detail_region = UPPER('".explode(':', $_POST['provinsi'])[1]."') AND ma.area = mp.area
    ";
    $result = mysqli_query($con, $query);

    // Handle PIC and CC
    $email_pic = array();
    $cc_email_pic = array();

    while($row=mysqli_fetch_assoc($result)){
        $to_pic[$row['to_pic_cs']]=$row['to_pic_cs'];
        foreach ($to_pic as $key => $valuePic) {
            array_push($email_pic, $valuePic);
        }
        $cc_pic[$row['cc_pic_cs']]=$row['cc_pic_cs'];
        foreach ($cc_pic as $key => $valueCCPic) {
            array_push($cc_email_pic, $valueCCPic);
        } 
    };

    // print_r(array_unique($email_pic));
    // print_r(array_unique($cc_email_pic));

    $_SESSION['idForm']    = $idReq.$delivDateToString;
    $_SESSION['reqEmail']  = isset($_POST['reqEmail'] ) ? $_POST['reqEmail'] : '';
    $_SESSION['divisi']    = isset($_POST['cmbBoxDivisi']   ) ? $_POST['cmbBoxDivisi']   : '';
    $_SESSION['reqType']   = isset($_POST['reqType']  ) ? $_POST['reqType']  : '';
    $_SESSION['idReq']     = isset($_POST['idReq']    ) ? $_POST['idReq']    : '';
    $_SESSION['delivDate'] = isset($_POST['delivDate']) ? $_POST['delivDate']: '';
    $_SESSION['cc']        = isset($_POST['cc']       ) ? $_POST['cc']       : '';
    $_SESSION['noMo']        = isset($_POST['noMo']       ) ? $_POST['noMo']       : '';
    $_SESSION['soldTo']        = isset($_POST['soldTo']       ) ? $_POST['soldTo']       : '';
    $_SESSION['produk']    = isset($_POST['cmdProduk']   ) ? $_POST['cmdProduk']   : '';
    $_SESSION['qty']       = isset($_POST['qty']      ) ? $_POST['qty']      : '';
    $_SESSION['picName']   = isset($_POST['picName']  ) ? $_POST['picName']  : '';
    $_SESSION['contact']   = isset($_POST['contact']  ) ? $_POST['contact']  : '';
    $_SESSION['provinsi']  = isset($_POST['provinsi'] ) ? (explode(':', $_POST['provinsi']))[1] : '';
    $_SESSION['kota']      = isset($_POST['kabupaten']     ) ? (explode(':', $_POST['kabupaten']))[1]     : '';
    $_SESSION['address']   = isset($_POST['address']  ) ? $_POST['address']  : '';
    $_SESSION['note']      = isset($_POST['note']     ) ? $_POST['note']     : '';
    
    echo(empty($_FILES['uploadFile']['name'][0]) ? 'empty' : $_FILES['uploadFile']['name'][0]);


    $_SESSION['fileName'] = array();
    // foreach ($_FILES['uploadFile']['name'] as $key => $value) {
    //     array_push($_SESSION['fileName'], $value); 
         
    // }

    print_r($_SESSION['fileName']);

    $_SESSION['to_pic'] = array();
    array_push($_SESSION['to_pic'], array_unique($email_pic));
    $_SESSION['cc_pic'] = array();
    array_push($_SESSION['cc_pic'], array_unique($cc_email_pic));

    print_r($_SESSION['to_pic']);
    print_r($_SESSION['cc_pic']);


    // print_r($_SESSION['fileName']);


    // print_r($_SESSION);
    // function printProduct() {
    //     $i = 0;
    //     foreach($_SESSION['produk'] as $key => $value) {
    //         echo $value.' Qty: '.$_SESSION['qty'][$i++].'<br>';
    //     }
    // }

    

    // printProduct();
    // foreach($_SESSION['qty'] as $key => $value) echo $key;

    echo "<script> location.href='./test-email.php'; </script>";
    // exit;
}



// // print_r($qty);

// if ($produk != '') {
//     $counter = 0;
//     foreach ($produk as $key => $value) {
//         $query = "
//         INSERT INTO dbdump.tbl_foc
//         VALUES ('".$id."', '".$reqEmail."', '".$divisi."', '".$reqType."', '".$idReq."', 
//         '".$delivDate."', '".$cc."', '".$value."', '".$qty[$counter++]."', '".$picName."', 
//         '".$contact."', '".$provinsi[1]."', '".$kota[1]."', '".$address."', '".$note."')
//         ";
//         mysqli_query($con, $query);
//     }
// }
?>

<html>
<div style="display: flex;">
    <div id="upper">
        <table>
            <tr>
                <th>ID SoluForm</th>
                <td><?php echo $id[0]; ?></td>
            </tr>
            <tr>
                <th>Email Req</th>
                <td><?php echo $reqEmail[0]; ?></td>
            </tr>
            <tr>
                <th>Division</th>
                <td><?php echo $divisi[0]; ?></td>
            </tr>
            <tr>
                <th>Type of Request</th>
                <td><?php echo $req_type[0]; ?></td>
            </tr>
            <tr>
                <th>ID Request</th>
                <td><?php echo $id_req[0]; ?></td>
            </tr>
            <tr>
                <th>Delivery Date</th>
                <td><?php echo $deliv_date[0]; ?></td>
            </tr>
            <tr>
                <th>Cost Centre</th>
                <td><?php echo $cc[0]; ?></td>
            </tr>
            <tr>
                <th>Nomor MO</th>
                <td><?php echo $noMo[0]; ?></td>
            </tr>
            <tr>
                <th>Sold To</th>
                <td><?php echo $sold_to[0]; ?></td>
            </tr>
            <tr>
                <th>Product</th>
                <td>
                <?php 
                $i = 0;
                // print_r($product);
                foreach ($arrProduct as $key => $value) {
                    // echo $value;
                    echo $value.' Qty: '.$arrQty[$i++].'</br>';
                }
                ?>
                </td>          
            </tr>
            <tr>
                <th>Name PIC</th>
                <td><?php echo $pic_name[0]; ?></td>
            </tr>
            <tr>
                <th>Contact Number PIC</th>
                <td><?php echo $contact_number[0]; ?></td>
            </tr>
            <tr>
                <th>Province</th>
                <td><?php echo $provinsi[0]; ?></td>
            </tr>
            <tr>
                <th>City</th>
                <td><?php echo $kota[0]; ?></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><?php echo $detail_address[0]; ?></td>
            </tr>
            <tr>
                <th>Note</th>
                <td><?php echo $note[0]; ?></td>
            </tr>
        </table>
    </div>

    <div id='foc-form'>
        <form action="" method="POST" enctype="multipart/form-data">

            <label for="reqEmail">Requester Email</label><br>
            <input type="email" id="reqEmail" name="reqEmail" value="<?php echo $reqEmail[0]; ?>" required><br>
            
            <label for="cmbBoxDivisi">Division</label><br>
            <select id="cmbBoxDivisi" name="cmbBoxDivisi" value="<?php echo $divisi[0]; ?>" required>
                <option value=""></option>
                <option <?php echo ($divisi[0] == 'General Secretary') ? 'selected' : ''; ?> value="General Secretary">General Secretary</option>
                <option <?php echo ($divisi[0] == 'Marketing') ? 'selected' : ''; ?> value="Marketing">Marketing</option>
                <option <?php echo ($divisi[0] == 'HR') ? 'selected' : ''; ?> value="HR">HR</option>
                <option <?php echo ($divisi[0] == 'Sales Ops') ? 'selected' : ''; ?> value="Sales Ops">Sales Ops</option>
                <option <?php echo ($divisi[0] == 'Sales Strategy Planning') ? 'selected' : ''; ?> value="Sales Strategy Planning">Sales Strategy Planning</option>
                <option <?php echo ($divisi[0] == 'R&I') ? 'selected' : ''; ?> value="R&I">R&I</option>
                <option <?php echo ($divisi[0] == 'Operation') ? 'selected' : ''; ?> value="Operation">Operation</option>
                <option <?php echo ($divisi[0] == 'Finance') ? 'selected' : ''; ?> value="Finance">Finance</option>
                <option <?php echo ($divisi[0] == 'Quality Food Safety') ? 'selected' : ''; ?> value="Quality Food Safety">Quality Food Safety</option>
                <option <?php echo ($divisi[0] == 'Lainnya') ? 'selected' : ''; ?> value="Lainnya">Lainnya</option>
            </select><br>

            <label for="reqType">Type of Request</label><br>
            <select name="reqType" id="reqType" onchange="changeFunc(this)" required>
                <option value=""></option>
                <option <?php echo ($req_type[0] == 'AKP') ? 'selected' : ''; ?> value="AKP">AKP</option>
                <option <?php echo ($req_type[0] == 'BRIGHT') ? 'selected' : ''; ?> value="BRIGHT">BRIGHT</option>
                <option <?php echo ($req_type[0] == 'FOC') ? 'selected' : ''; ?> value="FOC">FORM FOC</option>
                <option <?php echo ($req_type[0] == 'BLUE PLANNER') ? 'selected' : ''; ?> value="BLUE PLANNER">BLUE PLANNER</option>
            </select><br>

            <span id="r-text"></span>
            <div id='divReqType'></div>

            <script>
                
                function changeFunc(optionVal) {
                    let value = optionVal.value; //Get the clicked checkbox value
                    console.log(value);
                    if (value == 'AKP') {
                        $('#divReqType').html('<label for="noMo">Nomor MO</label><br><input type="number" id="noMo" name="noMo" value="<?php echo $noMo[0]; ?>" required><br>');
                    }
                    else if (value == 'BLUE PLANNER') {
                        $('#divReqType').html('<label for="soldTo">Sold To</label><br><input type="text" id="soldTo" name="soldTo" value="<?php echo $sold_to[0]; ?>" required><br>');
                    }
                    else {
                        $('#divReqType').html('');
                    }
                }
                $('#reqType').trigger('change');
            </script>

            <label for="idReq">ID Request (Bright/AKP/Form FOC Produk)</label><br>
            <input type="text" id="idReq" name="idReq" value="<?php echo $id_req[0]; ?>" required><br>

            <!-- nanti taruh ke CS  -->
            <!-- <label for="typeCust">Type of Customer</label><br>
            <input type="radio" id="typeCust1" name="typeCust" value='Depo'>Depo<br>
            <input type="radio" id="typeCust2" name="typeCust" value='Not Depo'>Not Depo<br>

            <span id="r-text">
                php echo $selected;
            </span>
            <script>
                $('#r-text').html('Type of Delivery');
                $('input[type=radio]').click(function(e) {//jQuery works on clicking radio box
                    let value = $(this).val(); //Get the clicked checkbox value
                    if (value == 'Depo') {
                        $('#delivMethod').html('<input type="radio" id="typeDeliv1" name="typeDeliv" value="byDepo">By Depo<br><input type="radio" id="typeDeliv2" name="typeDeliv" value="byOther">By Other<br>');
                    }
                    else {
                        $('#delivMethod').html('<input type="radio" id="typeDeliv1" name="typeDeliv" value="byRex">By REX<br>');
                    }
                });
            </script> -->

            <!-- <div id='delivMethod'>
                <input type="radio" id="typeDeliv1" name="typeDeliv" value="byDepo">By Depo<br>
                <input type="radio" id="typeDeliv2" name="typeDeliv" value="byDistributor">By Distributor<br>
                <input type="radio" id="typeDeliv3" name="typeDeliv" value="byREX">By REX<br>
                <input type="radio" id="typeDeliv4" name="typeDeliv" value="byOther">By Other<br>
            </div> -->

            <label for="delivDate">Delivery/Pickup Date</label><br>
            <input type="date" id="delivDate" name="delivDate" min="<?php echo date("Y-m-d") ?>" value="<?php echo $deliv_date[0]; ?>" required><br>

            <label for="cc">Cost Centre</label><br>
            <input type="text" id="cc" name="cc" value="<?php echo $cc[0]; ?>" required><br>

            <!-- product -->
            <div class='wrapper'>
                <div class='input-box'>
                    <label for="product">Product</label><br>
                    <?php 
                    $i = 0;
                    foreach ($arrProduct as $key => $value) {
                        echo '<div>';
                        echo cmbBoxFoc("cmdProduk[]","","cmdsProduk",$value,$mProduk,"");
                        echo '<input type="number" id="qty" name="qty[]" min="1" placeholder="Qty..." value="'.$arrQty[$i++].'" required><br>';
                        echo '<a href="#" class="remove-lnk">Remove</a>';
                        echo '</div>';
                    }
                    
                    ?>
                    <!-- <label for="qty">Quantity</label> -->
                    <!-- <input type="text" id="product" name="product[]"> -->
                    <button class="btn add-btn">Add More</button>
                </div>
            </div>

            

            <label for="picName">Name PIC FOC Receiver</label><br>
            <input type="text" id="picName" name="picName" value="<?php echo $pic_name[0]; ?>" required><br>

            <label for="contact">Contact Number PIC FOC</label><br>
            <input type="text" id="contact" name="contact" value="<?php echo $contact_number[0]; ?>" required><br>

            <label>Provinsi</label>
			<select class="form-control" name="provinsi" id="provinsi" required>
				<option value=""> Pilih Provinsi</option>
			</select>

            <label>Kabupaten</label>
			<select class="form-control" name="kabupaten" id="kabupaten" required>
				<option value=""> Pilih Kota</option>
			</select>

            <label for="">Detail Address FOC</label><br>
            <input type="text" id="address" name="address" style="width: 100%" value="<?php echo $detail_address[0]; ?>" required><br>

            <label for="note"></label>Additional Note<br>
            <input type="text" id="note" name="note" style="width: 100%" value="<?php echo $note[0]; ?>" required><br>

            <label for='uploadFile'>Upload Attachment(s)</label>
            <input type='file' id='uploadFile' name='uploadFile[]' multiple accept="application/pdf, application/msword, application/vnd.ms-excel, application/zip, application/x-rar-compressed, image/*" required><br>
            <?php 
                // $_SESSION['fileName'] = array();
                $allowedTypes = array('application/pdf', 'application/msword', 'application/vnd.ms-excel', 'application/zip', 'application/x-rar-compressed', 'image/png', 'image/jpg', 'image/jpeg');
                if (isset($_FILES["uploadFile"])) {
                    $countFile = 0;
                    foreach ($_FILES["uploadFile"]["type"] as $fileType) {
                        if (in_array($fileType, $allowedTypes)) {
                            $fileName = $_FILES["uploadFile"]["tmp_name"][$countFile];
                            $fileExtension = explode('/', $fileType)[1];

                            $path = '/xampp/htdocs/osa-dev/osa/application/storage/soluform '.$_SESSION['idForm'];
                            if ( !is_dir($path)) {
                                mkdir($path);
                            }
                            move_uploaded_file($fileName, '/xampp/htdocs/osa-dev/osa/application/storage/soluform '.$_SESSION['idForm'].'/'.$_SESSION['reqType'].' '.$_SESSION['idReq'].' ('.($countFile+1).') '.'.'.$fileExtension);
                            array_push($_SESSION['fileName'], $_SESSION['reqType'].' '.$_SESSION['idReq'].' ('.($countFile+1).') '.'.'.$fileExtension);
                            echo '<p>Successfully uploaded for '.$_FILES["uploadFile"]["name"][$countFile].'</p>';
                            // array_push($_SESSION['fileName'], $_FILES["uploadFile"]["name"][$countFile]);
                            $countFile++;
                        } 
                        else {
                            echo 'File type not allowed!';
                        }
                    } 
                }
                // print_r($_FILES['uploadFile']['name'][0]);           
            ?>

            <!-- <input id="submitBtn" formaction="./test-email.php" type="submit" value='submit'> -->
            <input id="submitBtn" type="submit" name="submit" value='submit'>
            
        </form>
    </div>
</div>

    <script type="text/javascript">
        
        $(document).ready(function () {
    
        // allowed maximum input fields
        let max_input = 999;
    
        // initialize the counter for textbox
        let x = 1;
    
        // handle click event on Add More button
        $('.add-btn').click(function (e) {
            e.preventDefault();
            if (x < max_input) { // validate the condition
            x++; // increment the counter
            $('.wrapper').append(`
                <div class="input-box">
                <?php echo $menuProduk; ?>
                <input type="number" id="qty" name="qty[]" placeholder="Qty..." required><br>
                <a href="#" class="remove-lnk">Remove</a>
                </div>
            `); // add input field
            }
        });
    
        // handle click event of the remove link
        $('.wrapper').on("click", ".remove-lnk", function (e) {
            e.preventDefault();
            $(this).parent('div').remove();  // remove input field
            x--; // decrement the counter
        });

        // handle provinsi dan kota
        $.ajax({
                type: 'POST',
                url: "./get_provinsi.php",
                cache: false, 
                success: function(msg){
                    $("#provinsi").html(msg);
                    $("#provinsi").trigger("change");
                },
                // type: 'POST',
                // url: "./get_kabupaten.php",
                // cache: false, 
                // success: function(msg){
                // $("#kabupaten").html(msg);
                // },
            });
        // $.ajax({
        //         // type: 'POST',
        //         // url: "./get_provinsi.php",
        //         // cache: false, 
        //         // success: function(msg){
        //         // $("#provinsi").html(msg);
        //         // },
        //         type: 'POST',
        //         url: "./get_kabupaten.php",
        //         cache: false, 
        //         success: function(msg){
        //         $("#kabupaten").html(msg);
        //         },
        //     });
    
            $("#provinsi").change(function(){
            var provinsi = $("#provinsi").val();
                $.ajax({
                    type: 'POST',
                    url: "get_kabupaten.php",
                    data: {provinsi: provinsi},
                    cache: false,
                    success: function(msg){
                    $("#kabupaten").html(msg);
                    }
                });
            });
    
            $("#kabupaten").change(function(){
            var kabupaten = $("#kabupaten").val();
                $.ajax({
                    type: 'POST',
                    url: "get_kecamatan.php",
                    data: {kabupaten: kabupaten},
                    cache: false,
                    success: function(msg){
                    $("#kecamatan").html(msg);
                    }
                });
            });
 
            // $("#kecamatan").change(function(){
            // var kecamatan = $("#kecamatan").val();
            //     $.ajax({
            //         type: 'POST',
            //         url: "get_kelurahan.php",
            //         data: {kecamatan: kecamatan},
            //         cache: false,
            //         success: function(msg){
            //         $("#kelurahan").html(msg);
            //         }
            //     });
            // });
            
        });
    </script>

    <style>
        html {
            padding: 20px;
        }
        #foc-form {
            margin: auto;
            width: 50%;
            border: 3px solid green;
            padding: 10px;
        }
        #feedback-form {
            margin: auto;
            width: fit-content;
            border: 3px solid green;
            padding: 10px;
            /* float: right; */
            padding: 10px;
            display: block;
            width: 50%;
        }

        /* #upper {
            clear: left;
            float: left;
        } */

        table {
            margin: auto;
            /* float: left; */
            padding: 10px;
            display: block;
            /* width: 28%; */
        }

        table, th, td {
            border: 1px solid black;
        }

        .remove-lnk {
            color: red;
        }

        .add-btn {
            color: green;
        }
    </style>
</html>