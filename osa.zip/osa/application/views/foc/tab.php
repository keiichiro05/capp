<div class="tab" id="custom-bootstrap-menu">
	<label>CSOM</label>
	<a class='tab-menu' href='./home-foc.php'>Home</a>
	<a class='tab-menu' href='./foc-summary.php'>FOC Summary for CS</a>
	<a class='tab-menu' href='./foc.php'>Form Request</a>
	<a class='tab-menu' href='./foc-summary-requester.php'>FOC Summary for Requester</a>
	<a class='tab-menu' href='./md-pic.php'>Master Data PIC</a>
</div>

<style type="text/css">
	html {
		box-sizing: border-box;
	}

	div.tab {
		position: absolute;
		display: block;
		margin-bottom: 100px;
		width: 100%;
		padding: 20px;
		top: 0;
		right: 0;
		left: 0;
	}
	.tab>a { 
		text-decoration: none; 
		color: white;
	}
	.tab>a:hover { border-bottom: 1px dotted gray; }
	.tab>a:active { font-size: 15px; }
	.tab>a::after, .tab>label::after {
	 	margin-left: 15px;
	 	margin-right: 15px;
	 	content: "|";
	 	color: gray;
	 }

	#custom-bootstrap-menu {
		color: white;
		/*background-color: #32464c;*/
		/* Permalink - use to edit and share this gradient: https://colorzilla.com/gradient-editor/#1e5799+0,2989d8+36,2989d8+75,2989d8+75,207cca+100,7db9e8+100 */
		background: #1e5799; /* Old browsers */
		background: -moz-linear-gradient(left,  #1e5799 0%, #2989d8 36%, #2989d8 75%, #2989d8 75%, #207cca 100%, #7db9e8 100%); /* FF3.6-15 */
		background: -webkit-linear-gradient(left,  #1e5799 0%,#2989d8 36%,#2989d8 75%,#2989d8 75%,#207cca 100%,#7db9e8 100%); /* Chrome10-25,Safari5.1-6 */
		background: linear-gradient(to right,  #1e5799 0%,#2989d8 36%,#2989d8 75%,#2989d8 75%,#207cca 100%,#7db9e8 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#1e5799', endColorstr='#7db9e8',GradientType=1 ); /* IE6-9 */
	}

</style>

