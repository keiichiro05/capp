<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<?php
session_start();
// connection to db
include './tab.php';
echo '<br>';

$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='';
$con = @mysqli_connect($db_host, $db_user, $db_pswd, '') or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

// get id FOC
$idFoc = $_GET['idfoc'];

$_SESSION['idfoc'] = $idFoc;

// echo $_SESSION['idfoc'];

$query = "
SELECT * FROM dbdump.tbl_foc
WHERE id = '".$idFoc."'
";
$result = mysqli_query($con, $query);

$arrProduct = array();
$arrQty = array();

while($row=mysqli_fetch_assoc($result)){
    
    // echo $row['product'];
	$id             [0] =$row['id'];
	$reqEmail       [0] =$row['req_email'];
	$divisi         [0] =$row['divisi'];
	$req_type       [0] =$row['req_type'];
	$id_req         [0] =$row['id_req'];
	$deliv_date     [0] =$row['deliv_date'];
	$cc             [0] =$row['cc'];
	$noMo             [0] =$row['no_mo'];
	$soldTo             [0] =$row['sold_to'];
    array_push($arrProduct, $row['product']);
    array_push($arrQty, $row['qty']);
	// $product        [0] =$row['product'];
	// $qty            [0] =$row['qty'];
	$pic_name       [0] =$row['pic_name'];
	$contact_number [0] =$row['contact_number'];
	$provinsi       [0] =$row['provinsi'];
	$kota           [0] =$row['kota'];
	$detail_address [0] =$row['detail_address'];
	$note           [0] =$row['note'];
}

// print_r($product);


echo '<br><br><br>';
?>

<html>  
<div>
    <table rules='all'>
            <tr>
                <th>ID SoluForm</th>
                <td><?php echo $id[0]; ?></td>
            </tr>
            <tr>
                <th>Email Req</th>
                <td><?php echo $reqEmail[0]; ?></td>
            </tr>
            <tr>
                <th>Division</th>
                <td><?php echo $divisi[0]; ?></td>
            </tr>
            <tr>
                <th>Type of Request</th>
                <td><?php echo $req_type[0]; ?></td>
            </tr>
            <tr>
                <th>ID Request</th>
                <td><?php echo $id_req[0]; ?></td>
            </tr>
            <tr>
                <th>Delivery Date</th>
                <td><?php echo $deliv_date[0]; ?></td>
            </tr>
            <tr>
                <th>Cost Centre</th>
                <td><?php echo $cc[0]; ?></td>
            </tr>
            <tr>
                <th>Nomor MO</th>
                <td><?php echo $noMo[0]; ?></td>
            </tr>
            <tr>
                <th>Sold To</th>
                <td><?php echo $soldTo[0]; ?></td>
            </tr>
            <tr>
                <th>Product</th>
                <td>
                <?php 
                $i = 0;
                // print_r($product);
                foreach ($arrProduct as $key => $value) {
                    // echo $value;
                    echo $value.' Qty: '.$arrQty[$i++].'</br>';
                }
                ?>
                </td>          
            </tr>
            <tr>
                <th>Name PIC</th>
                <td><?php echo $pic_name[0]; ?></td>
            </tr>
            <tr>
                <th>Contact Number PIC</th>
                <td><?php echo $contact_number[0]; ?></td>
            </tr>
            <tr>
                <th>Province</th>
                <td><?php echo $provinsi[0]; ?></td>
            </tr>
            <tr>
                <th>City</th>
                <td><?php echo $kota[0]; ?></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><?php echo $detail_address[0]; ?></td>
            </tr>
            <tr>
                <th>Note</th>
                <td><?php echo $note[0]; ?></td>
            </tr>
        </table>

        <?php 
        $url = "http://localhost/osa-dev/osa/application/views/foc/feedbackcs.php?idfoc=".$idFoc; 
        echo "<a id='linkCs' href='".$url."'>Isi Feedback as CS</a>"
        ?>
    </div>

    <style>
        html {
            padding: 10px;
        }
        table {
            width: 50%;
            margin: auto;
        }

        table, th, td {
            border: 1px solid black;
        }

        div #linkCs {
            width: 50%;
            text-align: right;
            position: fixed;
        }
    </style>
</html>

