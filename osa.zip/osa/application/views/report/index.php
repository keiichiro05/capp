<link href="css/jquery.tablesorter.min.css" rel="stylesheet">

<!-- Pop Up form -->
<script src='js/popup.form.js' type='text/javascript'></script>
<link href="css/popup.form.css" rel="stylesheet" type="text/css"/>

<html>
  <head>
    <link href="css/jquery.tablesorter.min.css" rel="stylesheet">

  <!-- Pop Up form -->
  <script src='js/popup.form.js' type='text/javascript'></script>
  <link href="css/popup.form.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
      $(function() {
        $("#stockdate").datepicker();
        $("#ogdate").datepicker();
        $("#urgentogdate").datepicker();
      });
    </script>
  </head>
  <body>
  <form name="form" action="" method="post">
    <p>Stock Date: <input type="text" name='stockdate' id="stockdate" value='<?php echo isset($_POST['stockdate']) ? $_POST['stockdate'] : '' ?>'></p>
    <button type='submit' name='generate' >Generate</button> 
	<button type='submit' name='download' >Download</button> 
  </form>
  <br/>
  </body>
</html>

<?php
$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';

if(isset($_POST['generate'])){
	$stockdate_1 = $_POST['stockdate'];
	$stockdate = date("Y-m-d", strtotime($stockdate_1));

	$query = "UPDATE tbl_stock s INNER JOIN tbl_realisasi sr ON s.account = sr.account AND s.outlet_id = sr.outlet_id AND sr.do_date = s.stockdate AND sr.brand = 'AQUA'
	SET s.act_real = (SELECT 
	(CASE WHEN sr.do_qty is null THEN 0 ELSE sr.do_qty END) from tbl_realisasi sr) WHERE s.stockdate= '$stockdate'";
	mysqli_query($con,$query);

	$query = "
	UPDATE tbl_stock s INNER JOIN tbl_store st ON s.outlet_id = st.outlet_id AND s.`account` = st.`account` AND s.brand = st.brand
	SET s.sap_id = st.sap_id
	WHERE s.stockdate = '$stockdate';
	";
	mysqli_query($con, $query);

	// tambahan 21 Mar
	$query = "
	UPDATE tbl_stock t INNER JOIN tbl_store ts ON t.outlet_id = ts.outlet_id AND t.`account` = ts.`account` AND t.brand = ts.brand
	SET t.supplier =  ts.supplier, t.source = ts.source
	WHERE t.stockdate = '$stockdate';
	";
	mysqli_query($con, $query);

	$query = "
	UPDATE tbl_stock SET supplier = 'TBC' WHERE stockdate = '$stockdate' AND (supplier IS NULL OR supplier = '');
	";
	mysqli_query($con, $query);

	$query = "
	UPDATE tbl_stock SET source = 'TBC' WHERE stockdate = '$stockdate' AND (source IS NULL OR source = '') ;
	";
	mysqli_query($con, $query);

	$query = "
	UPDATE tbl_stock s JOIN tbl_bws st ON s.outlet_id = st.outlet_id AND s.account = st.account
	SET s.bws = st.bws
	WHERE s.stockdate = '$stockdate';
	";
	mysqli_query($con, $query);

	if(mysqli_affected_rows($con) <= 0){
		echo "<script type=\"text/javascript\">
		alert(\"No data available at that stockdate or no data updated.\");
		window.location = \"report?ac=index\"
			</script>";
	}else{
		echo "<script type=\"text/javascript\">
		alert(\"Success update tbl_stock\");
		window.location = \"report?ac=index\"
			</script>";
	}
}

if(isset($_POST['download'])){
	$stockdate_1 = $_POST['stockdate'];
	$stockdate = date("Y-m-d", strtotime($stockdate_1));
	$stockdate0 = date('Y-m-d', strtotime($stockdate));
	$stockdate1 = date('Y-m-d', strtotime($stockdate. '+ 1 day'));
	$stockdate2 = date('Y-m-d', strtotime($stockdate. '+ 2 day'));
	$stockdate3 = date('Y-m-d', strtotime($stockdate. '+ 3 day'));
	$stockdate4 = date('Y-m-d', strtotime($stockdate. '+ 4 day'));

	$result = mysqli_query($con, "SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, stockc, stock, act_real, stock_simu, sellout, upload_date, brand, bws FROM tbl_stock
	WHERE stockdate= '$stockdate'");

	if(mysqli_affected_rows($con) <= 0){
		echo "<script type=\"text/javascript\">
		alert(\"No data available at that stockdate\");
		window.location = \"report?ac=index\"
			</script>";
	}else{
		
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Disposition: attachment;filename=\"tbl_stock.csv\"");
		header("Content-Transfer-Encoding: binary");
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: private",false);
		ob_end_flush();
		$output = fopen('php://output', 'w');
		
			fputcsv($output, array('stockdate', 'account', 'dc_name', 'outlet_id', 'outlet_name', 'sap_id', 'source', 'supplier', 'stockc', 'stock', 'act_real', 'stock_simu', 'sellout', 'upload_date', 'brand', 'bws'));
		
		while ($row = mysqli_fetch_assoc($result))
		{
		fputcsv($output, $row);
		}
		
		fclose($output);
		mysqli_free_result($result);
	}
}

?>

