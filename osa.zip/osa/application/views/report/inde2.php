<link href="css/jquery.tablesorter.min.css" rel="stylesheet">

<!-- Pop Up form -->
<script src='js/popup.form.js' type='text/javascript'></script>
<link href="css/popup.form.css" rel="stylesheet" type="text/css"/>


<?php
$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';


// # Query Data 177 ''
// $mSoff = array(''=>'All Location');
// Handle stockdate
$str = "SELECT stockdate FROM tbl_stock GROUP BY stockdate ORDER BY stockdate DESC";
$result = mysqli_query($con,$str);
while($row=mysqli_fetch_assoc($result)){
	$mDate[$row['stockdate']]=$row['stockdate'];
}

// Handle JWK
$str = "
SELECT jwk from dbosa.tbl_stock 
WHERE jwk IN ('SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUMAT', 'SABTU')
GROUP BY jwk
ORDER BY jwk = 'SABTU', jwk = 'JUMAT', jwk = 'KAMIS', jwk = 'RABU', jwk = 'SELASA', jwk = 'SENIN', jwk ASC
";
$result = mysqli_query($con,$str);
while($row=mysqli_fetch_assoc($result)){
	$mHariJWK[$row['jwk']]=$row['jwk'];
}

$fieldDate  = getPreValue("cmdDate",key($mDate));

// function dapetin jenis minggu GANJIL atau GENAP
$jenisMinggu = getJenisMinggu($con, $fieldDate);

$str = "
SELECT supplier FROM tbl_stock WHERE stockdate = '".$fieldDate."' 
AND supplier LIKE '9000%' GROUP BY supplier";
$result = mysqli_query($con,$str);
while($row=mysqli_fetch_assoc($result)){
	$mSupplier[$row['supplier']]=$row['supplier'];
}

$hariJWK  = getPreValue("cmdHariJWK",key($mHariJWK));

if (isset($mSupplier)) {
	$daftarSupplier = getPreValue("cmdSupplier",key($mSupplier));
}

$judul = "Download OSA";
$otherMenu= cmbBox("cmdDate","","cmdsDate",$fieldDate,$mDate,"");
$otherMenu.= "<button type='submit' name='refresh' >Refresh Data</button>  &nbsp;";
// $otherMenu.= cmbBox("cmdHariJWK","","cmdsHariJWK",$hariJWK,$mHariJWK,"");
// $otherMenu.= "<input type='submit' value='Submit' name='cmdKirim'> &nbsp;";
// $otherMenu .= perkalianSpd();
$otherMenu .= "<div id='container'>";

$otherMenu .= "<div class='box'>";
$otherMenu.= checkBox("cmdHariJWK","","cmdsHariJWK",$hariJWK,$mHariJWK,"");
$otherMenu.= radioModeSpd();
$otherMenu .= "</div>";

$otherMenu .= "<div class='box card'>";
$otherMenu.= checkBoxSupplier("cmdSupplier","","cmdsSupplier",$daftarSupplier,$mSupplier,"");
// $otherMenu.= perkalianSpd();
$otherMenu .= "</div>";

$otherMenu .= "<div class='box card'>";
$otherMenu.= checkBoxOGMinimal("cmdOGMinimal","","cmdsOGMinimal",$daftarSupplier,$mSupplier,"");
$otherMenu .= "</div>";

$otherMenu .= "<div class='card box'>";
$otherMenu.= checkBoxBrand();
$otherMenu.= radioMode();
$otherMenu .= "</div>";

$otherMenu .= "</div>";

$otherMenu.= "<button type='submit' name='submit' >Submit</button>  &nbsp;";
$otherMenu.= cariKey();
$otherMenu.= "</small>";
echo tableHeader($judul, $otherMenu);
// echo $_POST['checklist'][0];
$stockdate0 = date('Y-m-d', strtotime($fieldDate));
$stockdate1 = date('Y-m-d', strtotime($fieldDate. '+ 1 day'));
$stockdate2 = date('Y-m-d', strtotime($fieldDate. '+ 2 day'));
$stockdate3 = date('Y-m-d', strtotime($fieldDate. '+ 3 day'));
$stockdate4 = date('Y-m-d', strtotime($fieldDate. '+ 4 day'));

if(isset($_POST['cmdPerkalian']) and ($_POST['cmdPerkalian'] != '')) {
	$nilai_spd = intval($_POST['cmdPerkalian']);
}
else {
	$nilai_spd = 1;
}

// Handle takeout where stockdate <= 0
// data berat
$query = "
UPDATE tbl_stock s
SET s.og_urgent =
	CASE
		WHEN s.stockc <= 0 THEN 0 ELSE s.og_urgent
	END
WHERE stockdate = '".$fieldDate."'
";
mysqli_query($con, $query);

// Create temp table buat di refer untuk query2 berikut
$query = "
DROP TEMPORARY TABLE IF EXISTS `dbosa`.tbl_stock_auto;
";
mysqli_query($con, $query);

// kayanya gaperlu
$query = "
CREATE TEMPORARY TABLE `dbosa`.tbl_stock_auto
SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4
FROM tbl_stock
LIMIT 0;
";
mysqli_query($con, $query);

$query = "
INSERT INTO tbl_stock_auto
(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
FROM tbl_stock
WHERE stockdate='".$fieldDate."' AND brand = 'AQUA' OR (brand = 'VIT' AND jwk NOT LIKE '%GENAP'));
";
mysqli_query($con, $query);

// Summary
// tinggal taruh ke checklist jwk nanti where nya kasih jwk
// ambil dr tbl stock aja
$str = "
SELECT
	s.supplier,
	COUNT(s.outlet_id) AS total_toko,
	SUM(s.fc_urgent4) AS total_og,
	s.truck_capacity
FROM 
	tbl_stock_auto s 
WHERE 
	s.stockdate = '".$fieldDate."' AND s.supplier <> '' AND s.supplier LIKE '9000%'
GROUP BY 
	s.supplier
";
$resultSummary = mysqli_query($con, $str);

$rowSummary = array();
while ($row=mysqli_fetch_array($resultSummary)) {
	$rowSummary[$row['supplier']."-".$row['total_toko']."-".$row['total_og']."-".$row['truck_capacity']]=$row;
}

// Refresh Data
if (isset($_POST['refresh'])) {
	// tambahan 21 Mar
	$query = "
	UPDATE tbl_stock t LEFT JOIN tbl_masterjwk tmj ON t.sap_id = tmj.id_sap AND t.brand = tmj.brand
	SET t.jwk = tmj.jwk
	WHERE stockdate = '".$fieldDate."';
	";
	mysqli_query($con, $query);

	// query untuk stock simu
	// $str="
	// DROP TEMPORARY TABLE IF EXISTS tbl_stock_yesterday;
	// ";
	// mysqli_query($con, $str);

	// $str = "
	// CREATE TEMPORARY TABLE tbl_stock_yesterday
	// SELECT s.stockdate, s.`account`, s.outlet_id, s.brand, s.stock_simu
	// FROM tbl_stock s
	// WHERE s.stockdate = DATE_SUB('".$fieldDate."', INTERVAL 1 DAY);
	// ";
	// mysqli_query($con, $str);

	// $str = "
	// UPDATE tbl_stock ss SET stock_simu = 
	// (CASE 
	// WHEN length(stockc) <= 0 THEN 
	// 	(SELECT oo.stock_simu FROM
	// 		(SELECT s.`account`, s.outlet_id, s.brand, (sy.stock_simu + s.act_real - s.spd3w) AS stock_simu 
	// 		FROM tbl_stock s 
	// 		INNER JOIN tbl_stock_yesterday sy
	// 		WHERE s.stockdate = '".$fieldDate."' AND s.`account` = sy.`account` AND s.outlet_id = sy.outlet_id AND s.brand = sy.brand) oo
	// 	WHERE ss.`account` = oo.`account` AND ss.outlet_id = oo.outlet_id AND ss.brand = oo.brand)
	
	// WHEN stock <= 0 THEN 
	// 	(SELECT oo.stock_simu FROM
	// 		(SELECT s.`account`, s.outlet_id, s.brand, (sy.stock_simu + s.act_real - s.spd3w) AS stock_simu 
	// 		FROM tbl_stock s 
	// 		INNER JOIN tbl_stock_yesterday sy
	// 		WHERE s.stockdate = '".$fieldDate."' AND s.`account` = sy.`account` AND s.outlet_id = sy.outlet_id AND s.brand = sy.brand) oo
	// 	WHERE ss.`account` = oo.`account` AND ss.outlet_id = oo.outlet_id AND ss.brand = oo.brand)
		
	// ELSE ss.stockc  
	// END) 
	// WHERE stockdate ='".$fieldDate."';
	// ";
	// mysqli_query($con, $str);

	// $query = "
	// UPDATE tbl_stock s
	// SET s.stock_simu = 0
	// WHERE s.stockdate = '".$fieldDate."' AND (s.stock_simu < 0 OR s.stock_simu IS NULL)
	// ";
	// mysqli_query($con, $query);

	//tambahin account di where
	//2 query dibawah dijoin masing masing
	$query = "
	UPDATE tbl_stock s LEFT JOIN tbl_spd3w spd ON s.outlet_id = spd.outlet_id AND s.brand = spd.brand
	SET s.spd3w = spd.spd3week
	WHERE s.stockdate = '".$fieldDate."';
	";
	mysqli_query($con, $query);

	$query = "
	UPDATE tbl_stock s LEFT JOIN tbl_max_stock3w mx ON s.outlet_id = mx.outlet_id AND s.brand = mx.brand
	SET s.max_stock3w = mx.max_stock
	WHERE s.stockdate = '".$fieldDate."';
	";
	mysqli_query($con, $query);

	// Change to PKM: 10 April
	$query = "
	UPDATE tbl_stock s LEFT JOIN tbl_pkm mx ON s.outlet_id = mx.outlet_id AND s.account = mx.account AND s.brand = mx.brand
	SET s.max_stock3w = mx.pkm
	WHERE s.stockdate = '".$fieldDate."' AND mx.pkm <> 0;
	";
	mysqli_query($con, $query);

	// Update Data BWS
	// bisa dioptimise dengan spesifik-in account nya jadi engga update semua account tiap kali upload
	$query = "
	UPDATE tbl_stock s LEFT JOIN tbl_store st ON s.outlet_id = st.outlet_id AND s.account = st.account
	SET s.bws = st.bws
	WHERE s.stockdate = '".$fieldDate."';
	";
	mysqli_query($con, $query);

	// Generate rhh, rh1, ph2, ph3 from tbl_data_sap
	$query = "
	UPDATE dbosa.tbl_stock s
	SET s.rhh_sat =
		CASE
			WHEN s.account = 'IDM' THEN 0 ELSE 
				(SELECT oo.rhhfinal 
				FROM
					(SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.rhh_sat :=
						CASE
							WHEN DATE_ADD(s.stockdate, INTERVAL 0 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
						END AS rhhfinal
					FROM dbosa.tbl_stock s, dbosa.tbl_data_sap o
					WHERE s.stockdate = '".$fieldDate."' AND (o.bill_block = '' AND o.rejection_code = '') AND s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 0 DAY) = o.req_deliv_date
					GROUP BY s.sap_id) oo
				WHERE s.sap_id = oo.sap_id)
		END,
		s.rh1 =
			(SELECT oo.rh1final 
			FROM
				(SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.rh1 :=
					CASE
						WHEN DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
					END AS rh1final
				FROM dbosa.tbl_stock s, dbosa.tbl_data_sap o
				WHERE s.stockdate = '".$fieldDate."' AND (o.bill_block = '' AND o.rejection_code = '') AND s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date
				GROUP BY s.sap_id) oo
			WHERE s.sap_id = oo.sap_id),
		s.ph2 =
			(SELECT oo.ph2final 
			FROM
				(SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.ph2 :=
					CASE
						WHEN DATE_ADD(s.stockdate, INTERVAL 2 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
					END AS ph2final
				FROM dbosa.tbl_stock s, dbosa.tbl_data_sap o
				WHERE s.stockdate = '".$fieldDate."' AND o.rejection_code = '' AND s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 2 DAY) = o.req_deliv_date
				GROUP BY s.sap_id) oo
			WHERE s.sap_id = oo.sap_id),	
		s.ph3 =
			(SELECT oo.ph3final 
			FROM
				(SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.ph3 :=
					CASE
						WHEN DATE_ADD(s.stockdate, INTERVAL 3 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
					END AS ph3final
				FROM dbosa.tbl_stock s, dbosa.tbl_data_sap o
				WHERE s.stockdate = '".$fieldDate."' AND o.rejection_code = '' AND s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 3 DAY) = o.req_deliv_date
				GROUP BY s.sap_id) oo
			WHERE s.sap_id = oo.sap_id),
		s.stockdate0 = 
			CASE
				WHEN s.account = 'IDM' THEN s.stock_simu ELSE 
					CASE 
						WHEN s.stock_simu + s.rhh_sat - s.spd3w < 0 THEN 0 ELSE s.stock_simu + s.rhh_sat - s.spd3w
					END
			END,
		s.oos =
			CASE 
				WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
					CASE
						WHEN s.stockdate0 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'YES'
						WHEN s.stockdate0 > 10 AND s.stockdate0 <= s.spd3w*3 + 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'Resiko OOS'
						ELSE 'NO'
					END
				WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
					CASE
						WHEN s.stockdate0 < 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'YES'
						WHEN s.stockdate0 > 5 AND s.stockdate0 <= s.spd3w*3 + 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'Resiko OOS' 
						ELSE 'NO'
					END
				WHEN s.brand = 'VIT' AND s.stockdate0 < 2 AND s.stockh_1 < 2 AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'YES'
				WHEN s.brand = 'VIT' AND s.stockdate0 <= spd3w*3 AND s.stockh_1 > 2 AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh_sat=0) THEN 'Resiko OOS'
				ELSE 'NO'
			END,
		s.og_urgent =
			CASE
				WHEN s.brand = 'AQUA' AND (s.oos = 'YES' OR s.oos = 'Resiko OOS') THEN 
					CASE
						WHEN s.spd3w < 0 THEN 5 ELSE 
							CASE
								WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
							END
					END
				WHEN s.brand = 'VIT' AND (s.oos = 'YES' OR s.oos = 'Resiko OOS') THEN 5 ELSE 0
			END,
		s.stockdate1 = 
			CASE
				WHEN s.stockdate0 + s.rh1 - s.spd3w < 0 THEN 0 ELSE s.stockdate0 + s.rh1 - s.spd3w
			END,
		s.stockdate2 =
			CASE
				WHEN s.stockdate1 + s.ph2 - s.spd3w < 0 THEN 0 ELSE s.stockdate1 + s.ph2 - s.spd3w
			END,
		s.stockdate3 = 
			CASE
				WHEN s.stockdate2 + s.ph3 - s.spd3w + s.og_urgent < 0 THEN 0 ELSE s.stockdate2 + s.ph3 - s.spd3w + s.og_urgent
			END,
		s.stockdate4 = 
			CASE
				WHEN s.stockdate3 + s.og_apollo - s.spd3w < 0 THEN 0 ELSE s.stockdate3 + s.og_apollo - s.spd3w
			END
	WHERE s.stockdate = '".$fieldDate."';
	";
	mysqli_query($con, $query);

	// Update stockdate1 for stockdate-1: 10 April
	$query = "
	UPDATE tbl_stock s
	SET s.stockdate1 = 
		CASE
		WHEN s.account = 'IDM' THEN s.stock_simu ELSE 
			CASE 
				WHEN s.stock_simu + s.rh1 - s.spd3w < 0 THEN 0 ELSE s.stock_simu + s.rh1 - s.spd3w
			END
		END
	WHERE s.stockdate = DATE_SUB('".$fieldDate."', INTERVAL 1 DAY);
	";
	mysqli_query($con, $query);

	// Generate OG APOLLO - Versi Baru: 11 April
	$query = "
	UPDATE tbl_stock s
	SET s.og_apollo = 
		CASE
			WHEN s.max_stock3w - s.stockdate3 < 5 THEN 5 ELSE
				CASE
					WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN s.max_stock3w 
					WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN s.max_stock3w - s.stockdate3
					ELSE 5
				END
		END,
		s.jenis_og =
		CASE
			WHEN s.max_stock3w - s.stockdate3 < 5 THEN 'OG Minimal 5' ELSE 
		CASE
			WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN 'OG ORI' 
			WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN 'OG ORI'
			ELSE 'OG Minimal 5'
		END
		END
	WHERE s.stockdate = '".$fieldDate."' AND s.source = 'Depo';
	";
	mysqli_query($con, $query);

	// FC Urgent4
	$query = "
	UPDATE tbl_stock s
	SET s.oos4 =
		CASE 
			WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
				CASE
					WHEN s.stockdate1 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.stockdate3 + s.og_apollo - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
					ELSE 'NO'
				END
			WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
				CASE
					WHEN s.stockdate1 < 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.stockdate3 + s.og_apollo - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
					ELSE 'NO'
				END
			WHEN s.brand = 'VIT' AND s.stockdate1 < 2 AND s.stockh_1 < 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
			WHEN s.brand = 'VIT' AND s.stockdate1 <= spd3w*3 AND s.stockh_1 > 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'Resiko OOS'
			ELSE 'NO'
		END,
		s.fc_urgent4 =
		CASE
			WHEN s.brand = 'AQUA' AND (s.oos4 = 'YES' OR s.oos4 = 'Resiko OOS') THEN 
				CASE
					WHEN s.spd3w < 0 THEN 5 ELSE 
						CASE
							WHEN spd3w*4 < 5 THEN 5
							WHEN spd3w*4 >= s.max_stock3w THEN s.max_stock3w
							ELSE spd3w*4
						END
				END
			WHEN s.brand = 'VIT' AND (s.oos4 = 'YES' OR s.oos4 = 'Resiko OOS') THEN 5 ELSE 0
		END
		WHERE s.stockdate = '".$fieldDate."';
	";
	mysqli_query($con, $query);

	// Update Data Truck Capacity
	$query = "
	UPDATE tbl_stock s INNER JOIN tbl_truckcapacity t ON t.hari LIKE concat('%', s.jwk, '%')
	SET s.truck_capacity = t.truck_capacity
	WHERE s.stockdate = '".$fieldDate."';
	";
	mysqli_query($con, $query);
}

if (isset($_POST['submit'])) {
	if (empty($_POST['checklist']) and empty($_POST['checklistSupplier']) and empty($_POST['checklistSupplierOG']) and empty($_POST['checklistBrand[]']) and empty($_POST['mode']) and empty($_POST['modeSpd'])) {
		// echo 'LANGSUNG RUNNING';
		// HARUS NUNGGU ESTIMATION STOCK
		$str="
		UPDATE tbl_stock 
			SET osa = 
					(CASE WHEN stock_simu > 4 THEN 1 ELSE 0 END), 
				remark = 
					(CASE WHEN stockdate3 < 5 THEN 'Urgent' 
					WHEN stockdate3 < 9 THEN 'On Risk'
					ELSE '' END)
		WHERE stockdate  = '".$fieldDate."' AND brand = 'AQUA'";
		mysqli_query($con, $str);

		// $str="UPDATE tbl_stock SET osa = (CASE WHEN stock_simu > 1 THEN 1 ELSE 0 END), remark = 
		// (CASE WHEN stockdate3 < 2 THEN 'Urgent' 
		// WHEN stockdate3 < 4 THEN 'On Risk'
		// ELSE '' END)
		// WHERE stockdate  = '".$fieldDate."' AND brand = 'VIT'";
		// mysqli_query($con, $str);

		$str = "SELECT * FROM tbl_stock_auto";
		$result = mysqli_query($con,$str);
	} else { 
		if (isset($_POST['checklistBrand']) and isset($_POST['mode'])) {
			$itemMode = $_POST['mode'];
			// echo 'mode:'.$itemMode;
			if ($itemMode == 'maxStock') {
				foreach ($_POST['checklistBrand'] as $key => $value) {
					// echo 'brand:'.$value;
					$str = "UPDATE tbl_stock s, tbl_max_stock3w mx
					SET s.max_stock3w = mx.max_stock
					WHERE s.sap_id = mx.sap_id AND s.stockdate = '".$fieldDate."' AND s.brand = '".$value."'";
				}
				mysqli_query($con,$str);
				$query = "
				REPLACE INTO tbl_stock_auto
				(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
				FROM tbl_stock
				WHERE stockdate='".$fieldDate."' AND brand = 'AQUA')
				UNION
				(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
				FROM tbl_stock 
				WHERE stockdate='".$fieldDate."' AND brand = 'VIT' AND jwk NOT LIKE '%GENAP');
				";
				mysqli_query($con, $query);
			} 
			else {
				// echo 'PKM';
				foreach ($_POST['checklistBrand'] as $key => $value) {
					echo 'brand:'.$value;
					if ($value == 'AQUA') {
						$str = "UPDATE tbl_stock s, tbl_pkm p
						SET s.max_stock3w = p.pkm
						WHERE s.outlet_id = p.outlet_id AND s.`account` = p.`account` AND s.brand = p.brand AND s.stockdate = '".$fieldDate."' AND s.brand = '".$value."'";
						// mysqli_query($con,$str);
						// echo 'TEST AQUA';
					}
					else {
						$str = "UPDATE tbl_stock s, tbl_pkm p
						SET s.max_stock3w = p.pkm
						WHERE s.outlet_id = p.outlet_id AND s.`account` = p.`account` AND s.brand = p.brand AND s.stockdate = '".$fieldDate."' AND s.brand = '".$value."'";
						// echo 'TEST VIT';
					}
				}
				mysqli_query($con,$str);
				$query = "
				REPLACE INTO tbl_stock_auto
				(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
				FROM tbl_stock
				WHERE stockdate='".$fieldDate."' AND brand = 'AQUA')
				UNION
				(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
				FROM tbl_stock 
				WHERE stockdate='".$fieldDate."' AND brand = 'VIT' AND jwk NOT LIKE '%GENAP');
				";
				mysqli_query($con, $query);
			}
			// calculate og apollo sesuai pilihan mode dan brand tadi
			$str = "UPDATE tbl_stock s
			SET s.og_apollo = 
			CASE
				WHEN s.max_stock3w - s.stockdate3 < 5 THEN 5 ELSE
					CASE
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN s.max_stock3w 
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN s.max_stock3w - s.stockdate3
						ELSE 5
					END
			END,
			s.jenis_og =
			CASE
				WHEN s.max_stock3w - s.stockdate3 < 5 THEN 'OG Minimal 5' ELSE 
			CASE
				WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN 'OG ORI' 
				WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN 'OG ORI'
				ELSE 'OG Minimal 5'
			END
			END
			WHERE s.stockdate = '".$fieldDate."' AND s.source = 'Depo'";
			mysqli_query($con,$str);
			$query = "
				REPLACE INTO tbl_stock_auto
				(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
				FROM tbl_stock
				WHERE stockdate='".$fieldDate."' AND brand = 'AQUA')
				UNION
				(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
				FROM tbl_stock 
				WHERE stockdate='".$fieldDate."' AND brand = 'VIT' AND jwk NOT LIKE '%GENAP');
				";
				mysqli_query($con, $query);
	
			// refresh load data
			$str = "SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 FROM tbl_stock_auto 
			WHERE stockdate='".$fieldDate."'";
			$result = mysqli_query($con,$str);
			// 	// echo 'hasil supplier: '.$value;
			// 	// echo 'hasil supplier: '.$fieldDate;
		
			// 	// $str = "UPDATE tbl_stock s SET s.og_apollo = ROUND(($nilai_spd*spd3w)+(og_apollo-spd3w)) WHERE stockdate='".$fieldDate."' AND s.supplier = '".$value."'";
			// 	// handle perkalian
			// 	// $str = "UPDATE tbl_stock s SET s.og_apollo = 
			// 	// 		CASE
			// 	// 			WHEN s.max_stock3w - s.stock_simu + $nilai_spd*s.spd3w < 5 THEN 5 ELSE
			// 	// 				CASE
			// 	// 					WHEN s.max_stock3w - s.stock_simu + $nilai_spd*s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stock_simu + $nilai_spd*s.spd3w
			// 	// 				END
			// 	// 		END,
			// 	// 		s.jenis_og =
			// 	// 		CASE
			// 	// 			WHEN s.max_stock3w - s.stock_simu + $nilai_spd*s.spd3w < 5 THEN 'OG Minimal 5' ELSE 'OG ORI'
			// 	// 		END
			// 	// 		WHERE s.stockdate = '".$fieldDate."' AND s.supplier = '".$value."'";
			// }
			// mysqli_query($con, $str);
			// $str = "SELECT stockdate, account, outlet_id, outlet_name, sap_id, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, og_apollo, jenis_og, bws, oos, remark, og_urgent FROM tbl_stock 
			// 		WHERE stockdate='".$fieldDate."'";
			// $result = mysqli_query($con,$str);
		}
	
		if (isset($_POST['checklistSupplier']) and isset($_POST['jumlahSPD'])) {
			$counter = 0;
			$jumlahSPD = array();
			foreach ($_POST['jumlahSPD'] as $key => $value) {
				if ($value != '') {
					array_push($jumlahSPD, $value);
				}
			}
			// print_r($jumlahSPD);
			foreach ($_POST['checklistSupplier'] as $key => $value) {
				// echo $value.' '.$jumlahSPD[$counter];
				// handle perkalian
				$str = "
				UPDATE tbl_stock s
				SET s.og_apollo = 
					CASE
						WHEN s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w < 5 THEN 5 ELSE
							CASE
								WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w >= s.max_stock3w THEN s.max_stock3w 
								WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w < s.max_stock3w THEN s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w
								ELSE 5
							END
					END,
					s.jenis_og =
					CASE
						WHEN s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w < 5 THEN 'OG Minimal 5' ELSE 
					CASE
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w >= s.max_stock3w THEN 'OG ORI' 
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w < s.max_stock3w THEN 'OG ORI'
						ELSE 'OG Minimal 5'
					END
					END
				WHERE s.stockdate = '".$fieldDate."' AND s.supplier = '".$value."' AND s.source = 'Depo'";
				
				// Old Formula
				// "UPDATE tbl_stock s SET s.og_apollo = 
				// 		CASE
				// 			WHEN s.max_stock3w - s.stock_simu + ".$jumlahSPD[$counter]."*s.spd3w < 5 THEN 5 ELSE
				// 				CASE
				// 					WHEN s.max_stock3w - s.stock_simu + ".$jumlahSPD[$counter]."*s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stock_simu + ".$jumlahSPD[$counter]."*s.spd3w
				// 				END
				// 		END,
				// 		s.jenis_og =
				// 		CASE
				// 			WHEN s.max_stock3w - s.stock_simu + ".$jumlahSPD[$counter]."*s.spd3w < 5 THEN 'OG Minimal 5' ELSE 'OG ORI'
				// 		END
				// 		WHERE s.stockdate = '".$fieldDate."' AND s.supplier = '".$value."'";
				$counter++;
			}
			mysqli_query($con, $str);
			// echo $str;
			$query = "
			REPLACE INTO tbl_stock_auto
			(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
			FROM tbl_stock
			WHERE stockdate='".$fieldDate."' AND brand = 'AQUA')
			UNION
			(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
			FROM tbl_stock 
			WHERE stockdate='".$fieldDate."' AND brand = 'VIT' AND jwk NOT LIKE '%GENAP');
			";
			mysqli_query($con, $query);
			$str = "SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 FROM tbl_stock_auto 
					WHERE stockdate='".$fieldDate."'";
			$result = mysqli_query($con,$str);
		}
		
		// handle OG Minimal by Depo
		if (isset($_POST['checklistSupplierOG']) and isset($_POST['jumlahOGMinimal'])) {
			// echo 'MASUK';
			$counter = 0;
			$jumlahOGMinimal = array();
			foreach ($_POST['jumlahOGMinimal'] as $key => $value) {
				if ($value != '') {
					array_push($jumlahOGMinimal, $value);
				}
			}
			print_r($jumlahOGMinimal);
			foreach ($_POST['checklistSupplierOG'] as $key => $value) {
				// echo $value.' '.$jumlahSPD[$counter];
				// handle perkalian
				$str = "
				UPDATE tbl_stock s SET 
				s.jenis_og =
				CASE
					WHEN s.og_apollo < ".$jumlahOGMinimal[$counter]." THEN 'OG Minimal ".$jumlahOGMinimal[$counter]."' ELSE 'OG ORI'
				END,
				s.og_apollo = 
				CASE
					WHEN s.og_apollo < ".$jumlahOGMinimal[$counter]." THEN ".$jumlahOGMinimal[$counter]." ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate3 + ".((isset($jumlahSPD[$counter])) ? $jumlahSPD[$counter] : 0)."*s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate3 + ".((isset($jumlahSPD[$counter])) ? $jumlahSPD[$counter] : 0)."*s.spd3w
						END
				END
				WHERE s.stockdate = '".$fieldDate."' AND s.supplier = '".$value."' AND s.source = 'Depo'
				";
				$counter++;
			}
			mysqli_query($con, $str);
			//echo $str;
			$query = "
			REPLACE INTO tbl_stock_auto
			(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
			FROM tbl_stock
			WHERE stockdate='".$fieldDate."' AND brand = 'AQUA')
			UNION
			(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
			FROM tbl_stock 
			WHERE stockdate='".$fieldDate."' AND brand = 'VIT' AND jwk NOT LIKE '%GENAP');
			";
			mysqli_query($con, $query);
			$str = "SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 FROM tbl_stock_auto 
					WHERE stockdate='".$fieldDate."'";
			$result = mysqli_query($con,$str);
		}
	
		// Handle hari JWK
		if (isset($_POST['checklist'])) {
			$item = $_POST['checklist'][0];
	
			// echo $item;
			// $itemSupplier = $_POST['checklistSupplier'][0];
			$str = "SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, ROUND(spd3w,2) AS spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 FROM tbl_stock_auto 
				WHERE stockdate='".$fieldDate."' AND jwk REGEXP '".$item."";
			foreach($_POST['checklist'] as $item) {
				$str .= "|".$item."";
			}
			$str .= "'";
			$str .= " UNION ";
			$item = $_POST['checklist'][0];
			$str .= "SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, ROUND(spd3w,2) AS spd3w, forecast, @og_apollo:=0 as og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 FROM tbl_stock_auto 
					WHERE stockdate='".$fieldDate."' AND jwk NOT REGEXP '".$item."";
			foreach($_POST['checklist'] as $item) {
				$str .= "|".$item."";
			}
			$str .= "'"; 
			$result = mysqli_query($con,$str);
	
			// Summary
			$str = "
			SELECT
				s.supplier,
				COUNT(s.outlet_id) AS total_toko,
				SUM(s.og_apollo) AS total_og,
				s.truck_capacity
			FROM 
				tbl_stock_auto s 
			WHERE 
				s.stockdate = '".$fieldDate."' AND s.supplier <> '' AND s.supplier LIKE '9000%' AND jwk REGEXP '".$item."";
			foreach($_POST['checklist'] as $item) {
				$str .= "|".$item."";
			}
			$str .= "'";
			$str .= " 
			GROUP BY 
				s.supplier
			";
			$resultSummary = mysqli_query($con, $str);
			$rowSummary = array();
			while ($row=mysqli_fetch_array($resultSummary)) {
				$rowSummary[$row['supplier']."-".$row['total_toko']."-".$row['total_og']."-".$row['truck_capacity']]=$row;
			}
	
			// Handle Forecast
			$jwkForecast = '';
			if ($item == 'SENIN') {
				$jwkForecast = 1;
			}
			else if ($item == 'SELASA') {
				$jwkForecast = 2;
			}
			else if ($item == 'RABU') {
				$jwkForecast = 3;
			}
			else if ($item == 'KAMIS') {
				$jwkForecast = 4;
			}
			else if ($item == 'JUMAT') {
				$jwkForecast = 5;
			}
			else if ($item == 'SABTU') {
				$jwkForecast = 6;
			}
			// echo $jwkForecast;
			echo hariForecast($jwkForecast, 1);
			echo hariForecast($jwkForecast, 2);
			echo hariForecast($jwkForecast, 3);
			echo hariForecast($jwkForecast, 4);
			echo hariForecast($jwkForecast, 5);
			echo hariForecast($jwkForecast, 6);
			$str = "
			UPDATE dbosa.tbl_stock s
			SET s.oos4 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate1 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate3 + s.og_apollo - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate1 < 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate3 + s.og_apollo - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate1 < 2 AND s.stockh_1 < 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate1 <= spd3w*3 AND s.stockh_1 > 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent4 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos4 = 'YES' OR s.oos4 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos4 = 'YES' OR s.oos4 = 'Resiko OOS') THEN 5 ELSE 0
				END, 
	
				s.fc_apollo5 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate4 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate4 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate4 + s.spd3w
						END
				END, 
				s.oos5 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate2 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.fc_urgent4=0 AND s.fc_apollo5=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate4 + s.fc_apollo5 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate2 < 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.fc_urgent4=0 AND s.fc_apollo5=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate4 + s.fc_apollo5 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate2 < 2 AND s.stockh_1 < 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.fc_urgent4=0 AND s.fc_apollo5=0 AND s.og_urgent = 0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate2 <= spd3w*3 AND s.stockh_1 > 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.fc_urgent4=0 AND s.fc_apollo5=0 AND s.og_urgent = 0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent5 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos5 = 'YES' OR s.oos5 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos5 = 'YES' OR s.oos5 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate5 = 
				CASE
					WHEN s.stockdate4 + s.fc_urgent5 + s.fc_apollo5 - s.spd3w < 0 THEN 0 ELSE s.stockdate4 + s.fc_urgent5 + s.fc_apollo5 - s.spd3w
				END,
				
				s.fc_apollo6 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate5 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate5 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate5 + s.spd3w
						END
				END,
				s.oos6 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate3 < 10 AND (s.stockc >= 0) AND ((s.og_apollo + s.fc_urgent4)=0 AND s.fc_apollo5=0 AND s.fc_urgent5=0 AND s.fc_apollo6=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate5 + s.fc_apollo6 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate3 < 5 AND (s.stockc >= 0) AND ((s.og_apollo + s.fc_urgent4)=0 AND s.fc_apollo5=0 AND s.fc_urgent5=0 AND s.fc_apollo6=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate5 + s.fc_apollo6 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate3 < 2 AND s.stockh_1 < 2 AND ((s.og_apollo + s.fc_urgent4)=0 AND s.fc_apollo5=0 AND s.fc_urgent5=0 AND s.fc_apollo6=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate3 <= spd3w*3 AND s.stockh_1 > 2 AND ((s.og_apollo + s.fc_urgent4)=0 AND s.fc_apollo5=0 AND s.fc_urgent5=0 AND s.fc_apollo6=0 AND s.og_urgent=0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent6 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos6 = 'YES' OR s.oos6 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos6 = 'YES' OR s.oos6 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate6 = 
				CASE
					WHEN s.stockdate5 + s.fc_urgent6 + s.fc_apollo6 - s.spd3w < 0 THEN 0 ELSE s.stockdate5 + s.fc_urgent6 + s.fc_apollo6 - s.spd3w
				END,
				
				s.fc_apollo7 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate6 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate6 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate6 + s.spd3w
						END
				END,
				s.oos7 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate4 < 10 AND (s.stockc >= 0) AND ((s.fc_apollo5 + s.fc_urgent5)=0 AND s.fc_apollo6=0 AND s.fc_urgent6=0 AND s.fc_apollo7=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate6 + s.fc_apollo7 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate4 < 5 AND (s.stockc >= 0) AND ((s.fc_apollo5 + s.fc_urgent5)=0 AND s.fc_apollo6=0 AND s.fc_urgent6=0 AND s.fc_apollo7=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate6 + s.fc_apollo7 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate4 < 2 AND s.stockh_1 < 2 AND ((s.fc_apollo5 + s.fc_urgent5)=0 AND s.fc_apollo6=0 AND s.fc_urgent6=0 AND s.fc_apollo7=0 AND s.og_urgent = 0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate4 <= spd3w*3 AND s.stockh_1 > 2 AND ((s.fc_apollo5 + s.fc_urgent5)=0 AND s.fc_apollo6=0 AND s.fc_urgent6=0 AND s.fc_apollo7=0 AND s.og_urgent = 0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent7 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos7 = 'YES' OR s.oos7 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos7 = 'YES' OR s.oos7 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate7 = 
				CASE
					WHEN s.stockdate6 + s.fc_urgent7 + s.fc_apollo7 - s.spd3w < 0 THEN 0 ELSE s.stockdate6 + s.fc_urgent7 + s.fc_apollo7 - s.spd3w
				END,
				
				s.fc_apollo8 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate7 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate7 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate7 + s.spd3w
						END
				END,
				s.oos8 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate5 < 10 AND (s.stockc >= 0) AND ((s.fc_apollo6 + s.fc_urgent6)=0 AND s.fc_apollo7=0 AND s.fc_urgent7=0 AND s.fc_apollo8=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate7 + s.fc_apollo8 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate5 < 5 AND (s.stockc >= 0) AND ((s.fc_apollo6 + s.fc_urgent6)=0 AND s.fc_apollo7=0 AND s.fc_urgent7=0 AND s.fc_apollo8=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate7 + s.fc_apollo8 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate5 < 2 AND s.stockh_1 < 2 AND ((s.fc_apollo6 + s.fc_urgent6)=0 AND s.fc_apollo7=0 AND s.fc_urgent7=0 AND s.fc_apollo8=0 AND s.og_urgent = 0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate5 <= spd3w*3 AND s.stockh_1 > 2 AND ((s.fc_apollo6 + s.fc_urgent6)=0 AND s.fc_apollo7=0 AND s.fc_urgent7=0 AND s.fc_apollo8=0 AND s.og_urgent = 0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent8 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos8 = 'YES' OR s.oos8 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos8 = 'YES' OR s.oos8 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate8 = 
				CASE
					WHEN s.stockdate7 + s.fc_urgent8 + s.fc_apollo8 - s.spd3w < 0 THEN 0 ELSE s.stockdate7 + s.fc_urgent8 + s.fc_apollo8 - s.spd3w
				END,
				
				s.fc_apollo9 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate8 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate8 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate8 + s.spd3w
						END
				END,
				s.oos9 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate6 < 10 AND (s.stockc >= 0) AND ((s.fc_apollo7 + s.fc_urgent7)=0 AND s.fc_apollo8=0 AND s.fc_urgent8=0 AND s.fc_apollo9=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate8 + s.fc_apollo9 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate6 < 5 AND (s.stockc >= 0) AND ((s.fc_apollo7 + s.fc_urgent7)=0 AND s.fc_apollo8=0 AND s.fc_urgent8=0 AND s.fc_apollo9=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate8 + s.fc_apollo9 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate6 < 2 AND s.stockh_1 < 2 AND ((s.fc_apollo7 + s.fc_urgent7)=0 AND s.fc_apollo8=0 AND s.fc_urgent8=0 AND s.fc_apollo9=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate6 <= spd3w*3 AND s.stockh_1 > 2 AND ((s.fc_apollo7 + s.fc_urgent7)=0 AND s.fc_apollo8=0 AND s.fc_urgent8=0 AND s.fc_apollo9=0 AND s.og_urgent=0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent9 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos9 = 'YES' OR s.oos9 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos9 = 'YES' OR s.oos9 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate9 = 
				CASE
					WHEN s.stockdate8 + s.fc_urgent9 + s.fc_apollo9 - s.spd3w < 0 THEN 0 ELSE s.stockdate8 + s.fc_urgent9 + s.fc_apollo9 - s.spd3w
				END,
				
				s.fc_apollo10 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate9 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate9 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate9 + s.spd3w
						END
				END,
				s.oos10 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate7 < 10 AND (s.stockc >= 0) AND ((s.fc_apollo8 + s.fc_urgent8)=0 AND s.fc_apollo9=0 AND s.fc_urgent9=0 AND s.fc_apollo10=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate9 + s.fc_apollo10 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate7 < 5 AND (s.stockc >= 0) AND ((s.fc_apollo8 + s.fc_urgent8)=0 AND s.fc_apollo9=0 AND s.fc_urgent9=0 AND s.fc_apollo10=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate9 + s.fc_apollo10 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate7 < 2 AND s.stockh_1 < 2 AND ((s.fc_apollo8 + s.fc_urgent8)=0 AND s.fc_apollo9=0 AND s.fc_urgent9=0 AND s.fc_apollo10=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate7 <= spd3w*3 AND s.stockh_1 > 2 AND ((s.fc_apollo8 + s.fc_urgent8)=0 AND s.fc_apollo9=0 AND s.fc_urgent9=0 AND s.fc_apollo10=0 AND s.og_urgent=0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent10 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos10 = 'YES' OR s.oos10 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN spd3w*4 < 5 THEN 5 ELSE spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos10 = 'YES' OR s.oos10 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate10 = 
				CASE
					WHEN s.stockdate9 + s.fc_urgent10 + s.fc_apollo10 - s.spd3w < 0 THEN 0 ELSE s.stockdate9 + s.fc_urgent10 + s.fc_apollo10 - s.spd3w
				END	
			WHERE s.stockdate = '2022-02-09';
			";
			// mysqli_query($con, $str);
		}
	
		if (isset($_POST['modeSpd'])) {
			$modeSpd = $_POST['modeSpd'];
	
			if ($modeSpd == 'typeSpd') {
				$str = "
				UPDATE tbl_stock s 
				SET s.og_apollo = 
				CASE
					WHEN s.max_stock3w - s.stockdate3 < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN s.max_stock3w 
							WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN s.max_stock3w - s.stockdate3
							ELSE 5
						END
				END,
				s.jenis_og =
				CASE
					WHEN s.max_stock3w - s.stockdate3 < 5 THEN 'OG Minimal 5' ELSE 
					CASE
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN 'OG ORI' 
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN 'OG ORI'
						ELSE 'OG Minimal 5'
					END
				END
				WHERE s.stockdate = '".$fieldDate."' AND s.source = 'Depo'
				";
				mysqli_query($con, $str);
			}
			else if ($modeSpd == 'typeForecast') {
				$str = "
				UPDATE dbosa.tbl_stock s 
				SET s.og_apollo = 
				CASE
					WHEN s.max_stock3w - s.stock_simu + s.forecast < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stock_simu + s.forecast >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stock_simu + s.forecast
						END
				END,
				s.jenis_og =
				CASE
					WHEN s.max_stock3w - s.stock_simu + s.forecast < 5 THEN 'OG Minimal 5' ELSE 'OG ORI'
				END
				WHERE s.stockdate = '".$fieldDate."' AND s.source = 'Depo'
				";	
				mysqli_query($con, $str);
			}
			$query = "
			REPLACE INTO tbl_stock_auto
			(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
			FROM tbl_stock
			WHERE stockdate='".$fieldDate."' AND brand = 'AQUA')
			UNION
			(SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 
			FROM tbl_stock 
			WHERE stockdate='".$fieldDate."' AND brand = 'VIT' AND jwk NOT LIKE '%GENAP');
			";
			mysqli_query($con, $query);
	
			// refresh load data
			$str = "SELECT stockdate, account, dc_name, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock_simu, sellout, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 FROM tbl_stock_auto 
			WHERE stockdate='".$fieldDate."'";
			$result = mysqli_query($con,$str);
		}
	}

	while($row=mysqli_fetch_assoc($result)){
		$rowData[$row['stockdate']."-".$row['account']."-".$row['outlet_id']."-".$row['brand']]=$row;
	}
	if(mysqli_num_rows($result)==0){
	echo alertMsg("Data tidak ada");
	exit;
	}
}
?>

<h3>Summary</h3>
<table class='table-control' id='tabel-summary'>
	<thead>
		<tr>
			<th>Depo</th>
			<th>Total Toko</th>
			<th>Total OG: FC Urgent</th>
			<th>Truck Capacity</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($rowSummary as $key => $value) { ?>
			<tr class="cari">
				<td><?php echo $rowSummary[$key]['supplier']; ?></td>
				<td><?php echo $rowSummary[$key]['total_toko']; ?></td>
				<td class='totalOG'><?php echo $rowSummary[$key]['total_og']; ?></td>
				<td class='truckCapacity'><?php echo $rowSummary[$key]['truck_capacity']; ?></td>
			</tr>
		<?php }	?>
	</tbody>
</table>

<h3>Data</h3>
<div class="row">
	<div class="col-lg-12">
	<table class="table-control" id="myTable">
		<thead>
			<tr>
				<th>Stock Date</th>
				<th>Account</th>
				<th>DC Name</th>
				<th>Outlet ID</th>
				<th>Outlet Name</th>
				<th>SAP ID</th>
				<th>Source</th>
				<th>Supplier</th>
				<th>JWK</th>
				<th>BWS</th>
				<th>Stock Simu</th> 
				<th>Brand</th>
				<th><?php echo $stockdate0; ?></th>
				<th><?php echo $stockdate1; ?></th>
				<th><?php echo $stockdate2; ?></th>
				<th><?php echo $stockdate3; ?></th>
				<th><?php echo $stockdate4; ?></th>
				<th>Max Stock 3w</th>
				<th>SPD 3w</th>
				<th>Forecast</th>
				<th>OG Apollo</th>
				<th>Jenis OG</th>
				<th>Truck Capacity</th>
				<th>OOS</th>
				<th>Urgent?</th>
				<th>OG Urgent</th>
				<th>Forecast Urgent</th>
				</tr>
		</thead>
		<tbody>
			<?php if (isset($_POST['submit'])) { foreach ($rowData	 as $key => $value) { ?>
			<tr class="cari">
				<td><?php echo $rowData[$key]['stockdate']; ?></td>
				<td><?php echo $rowData[$key]['account']; ?></td>
				<td><?php echo $rowData[$key]['dc_name']; ?></td>
				<td><?php echo $rowData[$key]['outlet_id']; ?></td>
				<td><?php echo $rowData[$key]['outlet_name']; ?></td>
				<td><?php echo $rowData[$key]['sap_id']; ?></td>
				<td><?php echo $rowData[$key]['source']; ?></td>
				<td><?php echo $rowData[$key]['supplier']; ?></td>
				<td><?php echo $rowData[$key]['jwk']; ?></td>
				<td><?php echo $rowData[$key]['bws']; ?></td>
				<td><?php echo $rowData[$key]['stock_simu']; ?></td>
				<td><?php echo $rowData[$key]['brand']; ?></td>
				<td><?php echo $rowData[$key]['stockdate0']; ?></td>
				<td><?php echo $rowData[$key]['stockdate1']; ?></td>
				<td><?php echo $rowData[$key]['stockdate2']; ?></td>
				<td><?php echo $rowData[$key]['stockdate3']; ?></td>
				<td><?php echo $rowData[$key]['stockdate4']; ?></td>
				<td><?php echo $rowData[$key]['max_stock3w']; ?></td>
				<td><?php echo $rowData[$key]['spd3w']; ?></td>
				<td><?php echo $rowData[$key]['forecast']; ?></td>
				<td class="og_apollo"><?php echo $rowData[$key]['og_apollo']; ?></td>
				<td><?php echo $rowData[$key]['jenis_og']; ?></td>
				<td><?php echo $rowData[$key]['truck_capacity']; ?></td> 
				<td><?php echo $rowData[$key]['oos']; ?></td>
				<td><?php echo $rowData[$key]['remark']; ?></td>
				<td><?php echo $rowData[$key]['og_urgent']; ?></td>
				<td><?php echo $rowData[$key]['fc_urgent4']; ?></td> 
			</tr>
			<?php }}	?>
		</tbody>
	</table>
	</div>
</div> 

<script type="text/javascript">
  // $("#cmdSoff").on("change", function(){
  //   this.form.submit();
  // });
	let totalOG = document.getElementsByClassName('totalOG');
	let truckCapacity = document.getElementsByClassName('truckCapacity');
	let tabel = document.getElementById('tabel-summary');
	let rows = tabel.getElementsByTagName('tr');
	for (let i = 0; i < totalOG.length; i++) {
		if (parseInt(totalOG[i].innerHTML) > parseInt(truckCapacity[i].innerHTML)) {
			rows[i+1].style.backgroundColor = '#FFCCCB';
		}
		else if (parseInt(totalOG[i].innerHTML) < 0.9*parseInt(truckCapacity[i].innerHTML)) {
			rows[i+1].style.backgroundColor = '#90EE90';
		}
		else {
			rows[i+1].style.backgroundColor = '#FFF192';
		}
	}
</script>

