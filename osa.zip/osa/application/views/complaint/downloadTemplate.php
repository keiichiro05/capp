<?php
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/sql_function.php';

    try {
        $column = "case_number,product,actual_reason_l1,actual_reason_l2,actual_reason_l3,actual_reason_desc_2,status,initial_user,contact_name,mailing_province,mailing_city,mailing_address,factory_name,case_priority,date_of_contract,datetime_closed,phone,mobile,batch_code_primary,batch_code_secondary,account_type,contact_type,quantity_affected,origin_detail,point_of_sale,account_name,account_shipping_province,account_shipping_city,account_shipping_address,issue_sequence,datetime_opened,age_case,subject,description,remarks,analysis_results,consumer_reason_l1,consumer_reason_l2,consumer_reason_l3,consumer_reason,production_line,customer_id,date_of_answer,defect_severity,case_owner_title,issue_remarks";
        $column = str_replace("\n","",str_replace(",", ";", $column));
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=\"template_complaint.csv\"");
        header("Content-Transfer-Encoding: binary");
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        ob_clean();
        $output = fopen('php://output', 'w');
        $arr = explode(';', $column);
        fputcsv($output, $arr);
        fclose($output);
        exit();
    } catch(Error $e) {
        echo $e;
    }

    // echo "<script>location.replace('upload-minis');</script>";


?>