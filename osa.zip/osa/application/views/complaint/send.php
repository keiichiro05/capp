<?php
/*
# Prject: BWG Project 1.0
# Auth  : DamarTeduh©2019
# Create: Taman Dayu | 2019-11-21 19:53
*/

$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];


//check if input file is empty
$err="";
print_r($_FILES);
$c = count($_FILES);
// echo count($_FILES);
// exit;

$filetitle = $_FILES['cFile']['name'];

if(!empty($_FILES['cFile']['name'])){
  $filename = $_FILES['cFile']['tmp_name'];
  $fileinfo = pathinfo($_FILES['cFile']['name']);

  //check file extension
  // if(strtolower($fileinfo['extension']) == 'csv' AND $_FILES['files']['size'] > 0){
    //check if file contains data
  $delimiter = ",";
  $file = fopen($filename, 'r');
  $firstLine = fgets($file);
  $i=0;
    

  if(strpos($firstLine, ";") != FALSE) $delimiter=";";    
  $values = '';
  $impData = fgetcsv($file, 200, $delimiter);
  // echo 'Print First';
  // print_r($impData);
    
  while($i < $c){
    // echo 'Print this';
    // print_r($impData);
    $date_contact = strtok($impData[14], ' ');
    $date_contact = date("Y-m-d", strtotime($date_contact));
    $date_closed = strtok($impData[15], ' ');
    $date_closed = date("Y-m-d", strtotime($date_closed));
    $date_opened = strtok($impData[30], ' ');
    $date_opened = date("Y-m-d", strtotime($date_opened));
    $date_answer = strtok($impData[42], ' ');
    $date_answer = date("Y-m-d", strtotime($date_answer));
    // echo $date_answer;
    $query = "REPLACE INTO tbl_complaint (case_number,product,actual_reason_l1,actual_reason_l2,actual_reason_l3,actual_reason_desc_2,`status`,initial_user,contact_name,mailing_province,mailing_city,mailing_address,factory_name,case_priority,date_of_contact,datetime_closed,phone,mobile,batch_code_primary,batch_code_secondary,account_type,contact_type,quantity_affected,origin_detail,point_of_sale,account_name,account_shipping_province,account_shipping_city,account_shipping_address,issue_sequence,datetime_opened,age_case,`subject`,`description`,remarks,analysis_results,consumer_reason_l1,consumer_reason_l2,consumer_reason_l3,consumer_reason,production_line,customer_id,date_of_answer,defect_severity,case_owner_title,issue_remarks)
    VALUES ('" . trim($impData[0]) . "','" . trim($impData[1]) .  "','" . trim($impData[2]) .  "','" . trim($impData[3]) .  "','" . trim($impData[4]) .  "','" . trim($impData[5]) .  "','" . trim($impData[6]) .  "','" . trim($impData[7]) .  "','" . trim($impData[8]) .  "','" . trim($impData[9]) .  "','" . trim($impData[10]) .  "','" . trim($impData[11]) .  "','" . trim($impData[12]) .  "','" . trim($impData[13]) .  "','" . trim($date_contact) .  "','" . trim($date_closed) .  "','" . trim($impData[16]) .  "','" . trim($impData[17]) .  "','" . trim($impData[18]) .  "','" . trim($impData[19]) .  "','" . trim($impData[20]) . "','" . trim($impData[21]) .  "','" . trim($impData[22]) .  "','" . trim($impData[23]) .  "','" . trim($impData[24]) .  "','" . trim($impData[25]) .  "','" . trim($impData[26]) .  "','" . trim($impData[27]) .  "','" . trim($impData[28]) .  "','" . trim($impData[29]) .  "','" . trim($date_opened) .  "','" . trim($impData[31]) .  "','" . trim($impData[32]) .  "','" . trim($impData[33]) .  "','" . trim($impData[34]) .  "','" . trim($impData[35]) .  "','" . trim($impData[36]) .  "','" . trim($impData[37]) .  "','" . trim($impData[38]) .  "','" . trim($impData[39]) .  "','" . trim($impData[40]) .  "','" . trim($impData[41]) .  "','" . trim($date_answer) .  "','" . trim($impData[43]) .  "','" . trim($impData[44]) .  "','" . trim($impData[45]) .  "')";
    mysqli_query($con,$query);
    // echo $query;
      $i++;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
  }

//   $query = "REPLACE INTO tbl_stock (stockdate, account, dc_name, outlet_id, outlet_name, stockc, stock, sellout, stockh_1,upload_date,brand, stock_simu) VALUES $values ";
  // mysqli_query($con,$query);

  // Logging Uploader User
  $str="INSERT INTO tbl_log (user,total_rows,filename,upload) VALUES ('".$USER."','".$i."','".$filetitle."','complaint')";
  mysqli_query($con, $str);

}

echo "<script>location.replace('complaint?ac=index');</script>";
?>

