<?php
/*
# Prject: BWG Project 1.0
# Auth  : DamarTeduh©2019
# Create: Bandara Sby | 2019-09-20 12:50 PM
# Ket   : Production Module
*/
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/sql_function.php';

# akses control
# Jika di table akses, modul yg di beri akses tdk terdapat list index, maka user tsb tdk bs akses ke module
$str="SELECT * FROM tbl_akses WHERE username='{$_SESSION[APP_NAME]["username"]}' AND action='index'";
$result = mysqli_query($con,$str);
while ($row=mysqli_fetch_assoc($result)) {
	$akses[$row['modul']]="Y";
}
?>

<style type="text/css">
	body {
		background: #104bb2;
		font-family: Segoe UI,Frutiger,Frutiger Linotype,Dejavu Sans,Helvetica Neue,Arial,sans-serif;
	}
	/* Mobile Icon Menu */
	div.mobile-menu div.mobile-icon {
		display: inline-block;
		text-align: center;
		margin: 20px;
		vertical-align: top;
	}
	div.mobile-menu div.mobile-icon span { 
		margin-left: 5px; 
		margin-right: 10px; 
		color: white; 
		width: 100px;
		display: block;
		font-size: 11px;
		padding: 5px;
	}
	div.mobile-menu div.mobile-icon button:hover { opacity: 0.4 }
	div.mobile-menu div.mobile-icon button {
		background: #da532e;		
		border: 2px solid white;
		border-radius: 5px;
		width: 60px;
		height: 60px;
		text-align: center;
		color: white; 
		font-size: 20px;
	}
	h3 { color: white; padding: 30px; }
	
</style>
<div class="row mobile-menu text-center">
	<h3>Welcome to <?php echo APP_NAME; ?> | <small style="color: yellow"><?php echo APP_DESCRIPTION; ?></small></h3>

	<div class="col-lg-12 col-md-12 col-sm-12">
	<?php 
		foreach ($mModul as $kModul => $vModul) { 
			foreach ($vModul as $key => $value) {
				$haveAkses=isset($akses[$kModul])?$kModul:'null';
                $haveAkses=$kModul;
				if($key=="judul"){
	?>
			<div class="mobile-icon">
				<button onclick="cmdGo('<?php echo $haveAkses; ?>');" class="<?php echo $kModul; ?>"></button>
				<span><?php echo $value; ?></span>
			</div>
		<?php } } } ?>
	</div>
</div>

<script type="text/javascript">
	function cmdGo(id){

		if(id!='null') {
			window.location.href=id;
		} else {
			alert("ALERT! Need Permission to Access this module, contact your application administrator...");
		}
	}
</script>

