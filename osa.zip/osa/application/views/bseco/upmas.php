<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php


include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/upload/tab.php';

# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];

// $mDN = array("CMP" => "Complete");
// $str="SELECT * FROM tbm_dn_pending where reason_type = 'INV' or reason_type = 'LTG' order by reason_type";
// $result = mysqli_query($con, $str);
// while($row = mysqli_fetch_assoc($result)){ $mDN[$row['pdn_code']]=$row['description']; }


$DN=getPreValue("dn","");

$judul = "Check Master Customer";
// $otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload Bill Doc (ZFR2SD01106)</a>";
$otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload Master Customer</a>";
// $otherMenu .= "<input type='text' name='dn' id='txBarcode' placeholder='&#xf002; Cari DN' style='font-family:Arial, FontAwesome' autofocus onfocus='this.select();'>";
$otherMenu.= cariKey();

echo tableHeader($judul, $otherMenu);


echo newUpload("fgFrm04","btn1","Upload Store Status","bseco?ac=send");
// echo uploadFile("Upload Bill Doc","bseco?ac=send");
// echo uploadFile2("Upload Amount SAP","bseco?ac=send1");
$plant = $_SESSION['Customer Solution']['plant'];
// echo $str = "SELECT st.account, st.outlet_id, st.outlet_name as outlet FROM tbl_stock st LEFT JOIN tbl_store s on concat(st.account,st.outlet_id) = concat(s.account,s.outlet_id) WHERE s.outlet_name is null";
// echo $str = "SELECT a.account, a.outlet_id, a.outlet FROM 
//   (SELECT account, outlet_id, outlet_name as outlet, concat(account,outlet_id) as id FROM tbl_stock GROUP BY account, outlet_id, outlet, id) a
//   LEFT JOIN 
//   (select *, concat(account,outlet_id) as id from tbl_store) b
//   ON a.id = b.id";

$str = "SELECT  account, outlet_id, outlet_name as outlet FROM tbl_stock WHERE concat(account,outlet_id) NOT IN (select concat(account,outlet_id) FROM tbl_store) GROUP BY account, outlet_id, outlet";
$result = mysqli_query($con, $str);
?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>


<i> Check Master Data </i>
<div class="row">
  <div class="col-lg-12" id="frameparent">
<table class="table-control" id="myTable">
        <thead>
          <tr>
            <th>Source</th>
            <th>Branch</th>
            <th>Outlet_id</th>
            <th>SAP_id</th>
            <th>Outlet_name</th>
            <th>Region</th>
            <th>Account</th>
            <th>Remark</th>
            <th>Supplier</th>
            <th>Region_sales</th>
            <th>Active (Y/N)</th>
          </tr>
        </thead>
        <tbody>
          <?php while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td></td>
            <td></td>
            <td><?php echo $row['outlet_id']; ?></td>
            <td></td>
            <td><?php echo $row['outlet']; ?></td>
            <td></td>
            <td><?php echo $row['account']; ?></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
            <?php } ?>
        </tbody>
    </table> 
  </div>
  </div>

      <!-- <table class="table-control">
        <thead>
          <tr>
            <th>No</th>
            <th>Account</th>
            <th>Outlet ID</th>
            <th>Outlet Name</th>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><?php echo $i; ?></td>
            <td><?php echo $row['account']; ?></td>
            <td><?php echo $row['outlet_id']; ?></td>
            <td><?php echo $row['outlet']; ?></td>
          </tr>
          <?php $i++;} ?>
        </tbody>
    </table>  -->


 
