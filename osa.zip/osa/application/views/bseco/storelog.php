<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php

include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/bseco/tab.php';

$crud = getAkses($_SESSION[APP_NAME]['username']);
$USER = $_SESSION[APP_NAME]['username'];

$DN = getPreValue("dn","");

$judul = "Store Status log";
$otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload Stock</a>";

echo tableHeader($judul, $otherMenu);

echo newUpload("fgFrm04","btn1","Upload Store Status","bseco?ac=send");

$str = "SELECT user, total_rows, upload_date, filename FROM tbl_log WHERE upload = 'stock' ORDER BY seq DESC";
$result = mysqli_query($con, $str);
?>

<i> Data Store Status Log</i>
<div class="row">
  <div class="col-lg-12" id="frameparent">
      <table class="table-control" id="myTable">
        <thead>
          <tr>
            <th>No</th>
            <th>user</th>
            <th>total_row</th>
            <th>Upload Date</th>
            <th>File Name</th>
          </tr>
        </thead>
        <tbody>
          <?php $i=1; while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><?php echo $i; ?></td>
            <td><?php echo $row['user']; ?></td>
            <td><?php echo $row['total_rows']; ?> Rows</td>
            <td><?php echo $row['upload_date']; ?></td>
            <td><?php echo $row['filename']; ?></td>
          </tr>
          <?php $i++;} ?>
        </tbody>
    </table> 
  </div>
 </div>