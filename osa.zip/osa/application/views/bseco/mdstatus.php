<?php
$execution_time_limit = 36000;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/bseco/tab.php';

if(isset($_POST['export_data'])){
  $result = mysqli_query($con, "SELECT source,branch, outlet_id, sap_id, outlet_name, quadrant, region, account, remark, supplier, jwk,bws,region_sales, active, brand  FROM tbl_store");

  header("Content-Type: application/force-download");
  header("Content-Type: application/octet-stream");
  header("Content-Type: application/download");
  header("Content-Disposition: attachment;filename=\"export_table.csv\"");
  header("Content-Transfer-Encoding: binary");
  header("Pragma: public");
  header("Expires: 0");
  header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate, post-check=0, pre-check=0");
  header("Cache-Control: private",false);
  ob_end_flush();
  $output = fopen('php://output', 'w');
  
      fputcsv($output, array('source','branch', 'outlet_id', 'sap_id', 'outlet_name', 'quadrant', 'region', 'account', 'remark', 'supplier', 'jwk','bws','region_sales', 'active', 'brand'));
  
  while ($row = mysqli_fetch_assoc($result))
  {
  fputcsv($output, $row);
  }
  
  fclose($output);
  mysqli_free_result($result);
}
?>

<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
  } 

</style>

<?php
# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];

$DN=getPreValue("dn","");

$str = "SELECT tahun,minggu FROM tbl_md_status GROUP BY tahun,minggu ORDER BY minggu";
$result = mysqli_query($con,$str);
while($row=mysqli_fetch_assoc($result)) {
  $mWk[$row['minggu']]=$row['minggu'];
  $mThn[$row['tahun']]=$row['tahun'];
}

$fieldWk = getPreValue("cmdWk",key($mWk));
$fieldYr = getPreValue("cmdYr",key($mThn));

$judul = "Upload MD Status";

$otherMenu = "<a href='#' id='btn1'><i class='fa fa-upload'></i>Upload MD Status</a>";
$otherMenu.= cmbBox("cmdWk","","cmdWk",$fieldWk,$mWk,"");
$otherMenu.= cmbBox("cmdYr","","cmdYr",$fieldYr,$mThn,"");
$otherMenu.= "<button type='submit' name='submit' >Apply</button>  &nbsp;";
$otherMenu.= cariKey();

echo tableHeader($judul, $otherMenu);

echo newUpload("fgFrm04","btn1","Upload MD Status","bseco?ac=sendMD");

?>

<style type="text/css">
  table.table-control tbody tr td button.btn-cmp { padding: 10px; border: 1px orange; background: orange; }
</style>

<br/>
<i>Check MD Status</i>
<?php
if(isset($_POST['submit_master']))
{

    $makerAccount = $_POST['Account']; // account value
    $makerAccount = $_POST['Brand']; // brand value

    $account = mysqli_real_escape_string($con, $_POST['selected_text']); // get the selected text
    $brand = mysqli_real_escape_string($con, $_POST['selected_text2']);

    $str = "SELECT * FROM tbl_store WHERE account = '$account' AND brand = '$brand';";
    $result = mysqli_query($con, $str);
    
}
 ?>
<br/>



<div class="row">
  <div class="col-lg-12" id="frameparent">
    <table class="table-control" id="myTable">
        <thead>
          <tr>
            <th>No.</th>
            <th>SAP_ID</th>
            <th>Brand</th>
            <th>Segment</th>
            <th>Tahun</th>
            <th>Minggu</th>
            <th>Status</th>
            <th>NDate</th>
            <th>Upload Date</th>
          </tr>
        </thead>
        <tbody>
          <?php 
          $str = "SELECT * FROM tbl_md_status";
          $result = mysqli_query($con, $str);
          $i=1;
          while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><?php echo $i++; ?></td>
            <td><?php echo $row['sap_id']; ?></td>
            <td><?php echo $row['brand']; ?></td>
            <td><?php echo $row['segment']; ?></td>
            <td><?php echo $row['tahun']; ?></td>
            <td><?php echo $row['minggu']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['ndate']; ?></td>
            <td><?php echo $row['upload_date']; ?></td>
          </tr>
            <?php } ?>
        </tbody>
      </table> 
    </div>
  </div>



 
