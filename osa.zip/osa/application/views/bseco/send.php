<?php
/*
# Prject: BWG Project 1.0
# Auth  : DamarTeduh©2019
# Create: Taman Dayu | 2019-11-21 19:53
*/

$execution_time_limit = 1200;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];

//check if input file is empty
$err="";
// print_r($_FILES);
// exit;

if(!empty($_FILES['cFile']['name'])){
  $filename = $_FILES['cFile']['tmp_name'];
  $fileinfo = pathinfo($_FILES['cFile']['name']);

  //check file extension
  // if(strtolower($fileinfo['extension']) == 'csv' AND $_FILES['files']['size'] > 0){
    //check if file contains data
    $delimiter = ",";
    $file = fopen($filename, 'r');
    $firstLine = fgets($file);
    if(strpos($firstLine, ";") != FALSE) $delimiter=";";    
    while(($impData = fgetcsv($file, 200, $delimiter)) != FALSE){
    $outlet = trim($impData[2]);
    $str = "SELECT tanggal FROM tbl_weekconv WHERE tahun = ".$impData[5]." AND minggu = ".$impData[6]." ORDER by tanggal LIMIT 1"; 
    $result = mysqli_query($con, $str);
    $ndate=mysqli_fetch_assoc($result);
    if (strlen($impData[2])>2) {
    	$query = "REPLACE INTO tbl_store_status (source, branch, outlet_id, sap_id, account, tahun, minggu, status, brand, ndate) VALUES ('".$impData[0]."','".$impData[1]."','".$outlet."','".$impData[3]."','".$impData[4]."',".$impData[5].",".$impData[6].",'".$impData[7]."','".$impData[8]."','".$ndate['tanggal']."')"; 
        mysqli_query($con,$query);
    }else{
    	$query = "REPLACE INTO tbl_store_status (source, branch, outlet_id, sap_id, account, tahun, minggu, status, brand) VALUES ('".$impData[0]."','".$impData[1]."','".$outlet."','".$impData[3]."','".$impData[4]."',".$impData[5].",".$impData[6].",'".$impData[7]."','".$impData[8]."','".$ndate['tanggal']."')"; 
        mysqli_query($con,$query);
       $query = "UPDATE tbl_store_status SET outlet_id=(select outlet_id from tbl_store where sap_id = '".$impData[3]."'),account=(select account from tbl_store where sap_id = '".$impData[3]."') where sap_id = '".$impData[3]."'"; 
        mysqli_query($con,$query);

    }
    }
}


echo "<script>location.replace('bseco?ac=index');</script>";
// header("location:main".$err);
?>

