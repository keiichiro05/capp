<style type="text/css">
table tbody tr td input.inputnew{
    width: 100%;
    border: 0;
    padding: 0;
    height: 24px;
    font-size: 12px;
    font-weight: 500;
    background: none;
    border-radius: 0;
    color: #223254;
}

iframe#lpbframe{
  overflow: none;
  height: 500px;
  border: none;
  background-color: lightblue;
} 

</style>

<?php
$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/utility_function.php';
include APP_DIR.'/assets/sql_function.php';
include APP_DIR.'/views/bseco/tab.php';

# akses control
$crud=getAkses($_SESSION[APP_NAME]["username"]);
$USER = $_SESSION[APP_NAME]['username'];

$str = "SELECT * FROM tbl_md_iod";
$result = mysqli_query($con,$str);

$judul = "Table MD IOD";
$otherMenu = "";
echo tableHeader($judul, $otherMenu);

?>

<i> Check Table MD IOD </i>
<div class="row">
    <div class="col-lg-12" id="frameparent">
        <table class="table-control" id="myTable">
            <thead>
                <tr>
                    <th>SAP ID</th>
                    <th>Brand</th>
                    <th>SAP Name</th>
                    <th>Source</th>
                    <th>Supplier</th>
                    <th>Region</th>
                    <th>Region Sales</th>
                    <th>Active</th>
                    <th>Segment</th>
                    <th>Remarks</th>
                    <th>JWK</th>
                </tr>
            </thead>
            <?php while($row = mysqli_fetch_assoc($result)) { ?>
          <tr class="cari">
            <td><?php echo $row['sap_id']; ?></td>
            <td><?php echo $row['brand']; ?></td>
            <td><?php echo $row['sap_name']; ?></td>
            <td><?php echo $row['source']; ?></td>
            <td><?php echo $row['supplier']; ?></td>
            <td><?php echo $row['region']; ?></td>
            <td><?php echo $row['region_sales']; ?></td>
            <td><?php echo $row['active']; ?></td>
            <td><?php echo $row['segment']; ?></td>
            <td><?php echo $row['remarks']; ?></td>
            <td><?php echo $row['jwk']; ?></td>
            <td></td>
          </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>