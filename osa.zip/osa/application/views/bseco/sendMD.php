<?php

$execution_time_limit = 1200;
set_time_limit($execution_time_limit);
include APP_DIR.'/config/connection.php';
$USER = $_SESSION[APP_NAME]['username'];

$filetitle = $_FILES['cFile']['name'];

if(!empty($_FILES['cFile']['name'])) {
    $filename = $_FILES['cFile']['tmp_name'];
    $fileinfo = pathinfo($_FILES['cFile']['name']);
    $i = 0;

    $delimiter = ",";
    $file = fopen($filename, 'r');
    $firstLine = fgets($file);
    if(strpos($firstLine, ";") != FALSE) $delimiter=";";
    $currentTimestamp = date('Y-m-d H:i:s', time());
    while(($impData = fgetcsv($file, 200, $delimiter)) != FALSE) {
        $query = "REPLACE INTO tbl_md_status (sap_id, brand, segment, tahun, minggu, `status`, ndate, upload_date)
        VALUES ('".$impData[0]."','".$impData[1]."','".$impData[2]."','".$impData[3]."','".$impData[4]."','".$impData[5]."','".$impData[6]."','".$currentTimestamp."')";
        $result = mysqli_query($con, $query);
        if ($result) echo "Success";
        else echo "Error";
        $i++;
    }
    $str = "INSERT INTO tbl_log (user,total_rows,filename,upload) VALUES ('".$USER."','".$i."','".$filetitle."','md_status')";
    $log = mysqli_query($con, $str);
    if ($log) echo "Log Done";
    else echo "Log Error";
}

echo "<script>location.replace('bseco?ac=mdstatus');</script>";

?>