<?php
    $execution_time_limit = 3600;
    set_time_limit($execution_time_limit);
    include APP_DIR.'config/connection.php';
    include APP_DIR.'assets/utility_function.php';
    include APP_DIR.'assets/sql_function.php';
    include APP_DIR.'/views/db_176/tab.php';
    echo '<html><head>
    <link href="css/jquery.tablesorter.min.css" rel="stylesheet">
      <!-- Pop Up form -->
      <script src="js/popup.form.js" type="text/javascript"></script>
      <link href="css/popup.form.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script>
          $(function() {
            $("#spd3w_start").datepicker();
            $("#spd3w_end").datepicker();
          });
        </script>
      </head>
      <body>
      <form name="form" action="" method="post">
        <button type="submit" name="download_spd3w">Download SPD</button>
        <br><br>
        <strong><p>SPD 3 Weeks</p></strong>
        <p>Start Date <input type="text" name="spd3w_start" id="spd3w_start" value=' . (isset($_POST['spd3w_start']) ? $_POST['spd3w_start'] : '') . '></p>
        <p>End Date <input type="text" name="spd3w_end" id="spd3w_end" value=' . (isset($_POST['spd3w_end']) ? $_POST['spd3w_end'] : '') . '></p>
        <button type="submit" name="generate_spd3w">Generate SPD</button>
      </form>
      <br/>
      </body></html>
      
      <style type="text/css">
        .box_entry{
          width: 50%;
          float: left;
        
        }
        
        .box_entry {
          border : 3px solid #2989D8;
          padding: 20px;
        }
        
        .card_box {
          border : 3px dotted #2989D8;
          padding: 10px;
        }
        
        </style>
      ';    
?>

<?php
if(isset($_POST['generate_spd3w'])) {
  if (!empty($_POST['spd3w_start']) && !empty($_POST['spd3w_end'])) {
    $q_tr = "DELETE FROM tbl_sps_spd3w";
    query_executor($con_176,$q_tr);
    $spd3w_start = $_POST['spd3w_start'];
    $spd3w_end = $_POST['spd3w_end'];
    $date_start = date('Y-m-d', strtotime($spd3w_start));
    $date_end = date('Y-m-d', strtotime($spd3w_end));
    echo 'Date Start ', $date_start;
    echo '<br>';
    echo 'Date End ', $date_end;
    $query = "REPLACE INTO tbl_sps_spd3w (`account`,sku,cust_id,branch,spd3week)
    (SELECT `account`,sku,cust_id,branch, ROUND(AVG(sales_qty),2) AS spd3week
    FROM tbl_sps
    WHERE date BETWEEN '$date_start' AND '$date_end' AND (cust_id IS NOT NULL OR cust_id != '')
    GROUP BY `account`,sku,branch,cust_id)";
    echo '<br>';
    echo 'spd3w generated';
  
    query_executor($con_176, $query);
  
    $result = "INSERT INTO tbl_generator_log (id,generator_name,date_start,date_end,created_at) VALUES (DEFAULT,'spd3w','$date_start','$date_end',NOW())";
    query_executor($con_176, $result);
  }
  else {
    $message = 'Please check input';
    echo "<script type='text/javascript'>alert('$message');</script>";
  }
}

if(isset($_POST['download_spd3w'])) {
    echo "<script>location.replace('db_176?ac=download_spd_176');</script>";
}

?>