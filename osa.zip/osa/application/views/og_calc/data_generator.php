<?php
    $execution_time_limit = 3600;
    set_time_limit($execution_time_limit);
    include APP_DIR.'config/connection.php';
    include APP_DIR.'assets/utility_function.php';
    include APP_DIR.'assets/sql_function.php';
    include APP_DIR.'/views/og_calc/tab.php';
    echo '<html><head>
    <link href="css/jquery.tablesorter.min.css" rel="stylesheet">
      <!-- Pop Up form -->
      <script src="js/popup.form.js" type="text/javascript"></script>
      <link href="css/popup.form.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script>
          $(function() {
            $("#spd3w_start").datepicker();
            $("#spd3w_end").datepicker();
            $("#maxstock_start").datepicker();
            $("#maxstock_end").datepicker();
          });
        </script>
      </head>
      <body>
      <form name="form" action="" method="post">
        <strong><p>SPD 3 Weeks</p></strong>
        <p>Start Date <input type="text" name="spd3w_start" id="spd3w_start" value=' . (isset($_POST['spd3w_start']) ? $_POST['spd3w_start'] : '') . '></p>
        <p>End Date <input type="text" name="spd3w_end" id="spd3w_end" value=' . (isset($_POST['spd3w_end']) ? $_POST['spd3w_end'] : '') . '></p>
        <button type="submit" name="generate_spd3w">Generate SPD</button>
        <br>
        <br>
        <strong><p>Max Stock 3 Weeks</p></strong>
        <p>Start Date <input type="text" name = "maxstock_start" id="maxstock_start" value='. (isset($_POST['maxstock_start']) ? $_POST['maxstock_start'] : '') .'></p>
        <p>End Date <input type="text" name = "maxstock_end" id="maxstock_end" value='. (isset($_POST['maxstock_end']) ? $_POST['maxstock_end'] : '') .'></p>
        <button type="submit" name="generate_maxstock">Generate Maxstock</button>
      </form>
      <br/>
      </body></html>
      
      <style type="text/css">
        .box_entry{
          width: 50%;
          float: left;
        
        }
        
        .box_entry {
          border : 3px solid #2989D8;
          padding: 20px;
        }
        
        .card_box {
          border : 3px dotted #2989D8;
          padding: 10px;
        }
        
        </style>
      ';    
?>

<?php
if(isset($_POST['generate_spd3w'])) {
  if (!empty($_POST['spd3w_start']) && !empty($_POST['spd3w_end'])) {
    $spd3w_start = $_POST['spd3w_start'];
    $spd3w_end = $_POST['spd3w_end'];
    $date_start = date('Y-m-d', strtotime($spd3w_start));
    $date_end = date('Y-m-d', strtotime($spd3w_end));
    echo 'Date Start ', $date_start;
    echo '<br>';
    echo 'Date End ', $date_end;
    $query = "REPLACE INTO tbl_spd3w (`account`,sap_id, outlet_id, brand, spd3week)
    (SELECT `account`,sap_id, outlet_id, brand, ROUND(AVG(sellout),2) AS spd3week
    FROM tbl_stock 
    WHERE stockdate BETWEEN '$date_start' AND '$date_end' AND (sap_id IS NOT NULL OR sap_id != '')
    GROUP BY `account`,outlet_id, brand)";
    echo '<br>';
    echo 'spd3w generated';
  
    query_executor($con, $query);
  
    $result = "INSERT INTO tbl_generator_log (id,generator_name,date_start,date_end,created_at) VALUES (DEFAULT,'spd3w','$date_start','$date_end',NOW())";
    query_executor($con, $result);
  }
  else {
    $message = 'Please check input';
    echo "<script type='text/javascript'>alert('$message');</script>";
  }
}

if(isset($_POST['generate_maxstock'])) {
  // if (!empty($_POST['max3w_start']) && !empty($_POST['max3w_end'])) {
  $maxstock_start = $_POST['maxstock_start'];
  $maxstock_end = $_POST['maxstock_end'];
  $date_start = date('Y-m-d', strtotime($maxstock_start));
  $date_end = date('Y-m-d', strtotime($maxstock_end));
  echo 'Date Start ', $date_start;
  echo '<br>';
  echo 'Date End ', $date_end, '<br>';
  $query = "REPLACE INTO tbl_max_stock3w (`account`,sap_id, outlet_id, brand, max_stock)
  (SELECT `account`,sap_id, outlet_id, brand, MAX(stock_simu) AS max_stock
  FROM tbl_stock 
  WHERE stockdate BETWEEN '$date_start' AND '$date_end' AND (sap_id IS NOT NULL OR sap_id != '')
  GROUP BY `account`,outlet_id, brand)";

  query_executor($con, $query);

  $result = "INSERT INTO tbl_generator_log (id, generator_name,date_start,date_end,created_at) VALUES (DEFAULT,'maxstock','$date_start','$date_end',NOW())";
  query_executor($con, $result);

  echo 'maxstock 3 generated';
  // }
  // else {
  //   $message = 'Please check input';
  //   echo "<script type='text/javascript'>alert('$message');</script>";
  // }
}

?>