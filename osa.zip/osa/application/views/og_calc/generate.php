<?php
include_once "bws_reset.php";
include_once APP_DIR.'assets/sql_function.php';
function generate($con, $ogdate, $ogurgentdate, $stockdate){

    //TIME START TICKER
    $start_time = time();
    echo "<p>Start time: ".date("Y-m-d h:i:s",$start_time)." </p><br>";

    $str= "
	REPLACE 
	INTO 
	    tbl_og (
	        stockdate, 
	        og_date, 
	        og_urgent_date, 
	        `account`, 
	        outlet_id, outlet_name, stockc, stock, stockh_1,brand, stock_simu, sap_id, `source`, supplier, bws )
	SELECT 
	    stockdate, 
	    '$ogdate' AS og_date, 
	    '$ogurgentdate' AS og_urgent_date, 
	    `account`, outlet_id, outlet_name, stockc, stock, stockh_1,brand, 
	    CASE 
	        WHEN stock_simu IS NULL THEN 0
	        ELSE stock_simu
	        END, 
	    sap_id, `source`, supplier, bws 
	FROM tbl_stock WHERE stockdate = '$stockdate' AND `source` = 'Depo';
	";
    query_executor($con,$str);

    $query = "UPDATE tbl_og t INNER JOIN tbl_store s ON t.outlet_id = s.outlet_id AND t.brand = s.brand AND t.account = s.account SET t.outlet_name = s.outlet_name, t.region = s.region";
    query_executor($con, $query);


    /*
     * BWS cleansing
     * */
    //bws_reset($con);
    //END OF bws cleansing

    $stockdate0 = date('Y-m-d', strtotime($stockdate));
    $stockdate1 = date('Y-m-d', strtotime($stockdate. '+ 1 day'));
    $stockdate2 = date('Y-m-d', strtotime($stockdate. '+ 2 day'));
    $stockdate3 = date('Y-m-d', strtotime($stockdate. '+ 3 day'));
    $stockdate4 = date('Y-m-d', strtotime($stockdate. '+ 4 day'));

    $is_row_affected = false;
    $query = "
	UPDATE tbl_og t LEFT JOIN tbl_masterjwk tmj ON t.sap_id = tmj.id_sap AND t.brand = tmj.brand
	SET t.jwk = tmj.jwk
	WHERE t.stockdate = '$stockdate' AND t.og_date = '$ogdate' AND t.og_urgent_date = '$ogurgentdate';
	";
    query_executor($con, $query);
    //var_dump($query);
    $is_row_affected = $is_row_affected || mysqli_affected_rows($con) > 0;

    //6 menit
    $query = "
	UPDATE tbl_og s INNER JOIN tbl_spd3w spd 
	ON s.outlet_id = spd.outlet_id AND s.brand = spd.brand AND spd.sap_id = s.sap_id AND s.account=spd.account
	SET s.spd3w = spd.spd3week
	WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate';
	";
    query_executor($con, $query);
    //var_dump($query);
    $is_row_affected = $is_row_affected || mysqli_affected_rows($con) > 0;

    //8 menit
    $query = "
	UPDATE tbl_og s INNER JOIN tbl_max_stock3w mx ON s.outlet_id = mx.outlet_id
    AND s.brand = mx.brand AND s.sap_id=mx.sap_id AND s.account=mx.account
	SET s.max_stock3w = mx.max_stock
	WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate';
	";
    query_executor($con, $query);
    //var_dump($query);
    $is_row_affected = $is_row_affected || mysqli_affected_rows($con) > 0;

    function rh_query_helper($refer, $stockdate, $ogdate, $ogurgentdate){
        return "SELECT oo.rh1final
      FROM
          (SELECT s.sap_id, o.ship_to, o.req_deliv_date, @s.rh1 :=
              CASE
                  WHEN DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date THEN o.do_qty ELSE 0
              END AS rh1final
          FROM dbosa.tbl_og s, dbosa.tbl_data_sap o
          WHERE 
              s.stockdate = '$stockdate' AND 
              s.og_date = '$ogdate' AND 
              s.og_urgent_date = '$ogurgentdate' AND 
              (o.bill_block = '' AND o.rejection_code = '') AND 
              s.sap_id = o.ship_to AND DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date
          GROUP BY s.sap_id, o.req_deliv_date, o.do_qty) oo
      WHERE '$refer' = oo.sap_id";
    }

    #rhh can't be null
    //TODO: inspect this code
    // $query = "
	//   REPLACE INTO dbosa.tbl_og (
    //         stockdate, og_date, og_urgent_date, account, outlet_id, outlet_name, sap_id, source, supplier, jwk, stock, brand, jenis_og, 
    //         og_urgent, og_apollo, osa, forecast, remark, stockc, spd3w, max_stock3w, bws, rh_min1, rhh, rh1, ph2, ph3, fc_urgent4, 
    //         fc_urgent5, fc_urgent6, fc_urgent7, fc_urgent8, fc_urgent9, fc_urgent10, fc_apollo5, fc_apollo6, fc_apollo7, 
    //         fc_apollo8, fc_apollo9, fc_apollo10, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, stockdate5, 
    //         stockdate6, stockdate7, stockdate8, stockdate9, stockdate10, stock_simu, stockh_1, stockh_2, oos, oos4, oos5, 
    //         oos6, oos7, oos8, oos9, oos10, truck_capacity
    //         )
    //     SELECT 
    //         s.stockdate, s.og_date, s.og_urgent_date, s.account, s.outlet_id, s.outlet_name, s.sap_id, s.source, s.supplier, s.jwk, s.stock, s.brand, s.jenis_og, 
    //         s.og_urgent, s.og_apollo, s.osa, s.forecast, s.remark, s.stockc, s.spd3w, s.max_stock3w, s.bws, 
    //         CASE
    //           WHEN DATE_SUB(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date THEN o.do_qty
    //             ELSE 0
    //         END,
    //         CASE 
    //           WHEN s.stockdate  = o.req_deliv_date AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL)
    //                THEN o.do_qty
    //           ELSE 0 
    //         END, 
    //         CASE 
    //           WHEN DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL)
    //               THEN o.do_qty
    //             ELSE 0
    //         END, 
    //         CASE 
    //           WHEN DATE_ADD(s.stockdate, INTERVAL 2 DAY) = o.req_deliv_date THEN o.do_qty
    //             ELSE 0
    //         END, 
    //         CASE 
    //               WHEN DATE_ADD(s.stockdate, INTERVAL 3 DAY) = o.req_deliv_date THEN o.do_qty
    //                 ELSE 0
    //         END, 
    //         s.fc_urgent4, s.fc_urgent5, s.fc_urgent6, s.fc_urgent7, s.fc_urgent8, s.fc_urgent9, s.fc_urgent10, s.fc_apollo5, s.fc_apollo6, s.fc_apollo7, 
    //         s.fc_apollo8, s.fc_apollo9, s.fc_apollo10, s.stockdate0, s.stockdate1, s.stockdate2, s.stockdate3, s.stockdate4, s.stockdate5, 
    //         s.stockdate6, s.stockdate7, s.stockdate8, s.stockdate9, s.stockdate10, s.stock_simu, s.stockh_1, s.stockh_2, s.oos, s.oos4, s.oos5, 
    //         s.oos6, s.oos7, s.oos8, s.oos9, s.oos10, s.truck_capacity
    //      FROM dbosa.tbl_og s
    //       LEFT JOIN (
    //         SELECT req_deliv_date, do_qty, ship_to, bill_block, rejection_code
    //         FROM dbosa.tbl_data_sap
            
    //       ) as o
    //       ON s.sap_id = o.ship_to
	//   WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate';
	// ";

    // $query_rhmin1 = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_SUB(s.stockdate, INTERVAL 1 DAY))) SET s.rh_min1 =
    // CASE WHEN s.brand = 'AQUA' THEN 
    //         CASE
    //           WHEN DATE_SUB(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date AND o.material_desc = '5 GALLON AQUA LOCAL' THEN o.do_qty
    //             ELSE 0
    //         END
    //     WHEN s.brand = 'VIT' THEN
    //         CASE
    //           WHEN DATE_SUB(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date AND o.material_desc = '5 GALLON VIT LOCAL' THEN o.do_qty
    //             ELSE 0
    //         END
    // END WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'";

    $query_rhmin1_aqua = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_SUB(s.stockdate, INTERVAL 1 DAY)) AND (o.material_desc = '5 GALLON AQUA LOCAL') AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL)) 
    SET s.rh_min1 = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'AQUA'";

    query_executor($con, $query_rhmin1_aqua);

    $query_rhmin1_vit = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_SUB(s.stockdate, INTERVAL 1 DAY)) AND (o.material_desc = '5 GALLON VIT LOCAL') AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL)) 
    SET s.rh_min1 = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'VIT'";

    query_executor($con, $query_rhmin1_vit);
    //Suspected code, inspect query above
    //var_dump(rh_query_helper('s.sap_id', $stockdate, $ogdate, $ogurgentdate));

    //TOO SLOW -- NEED CHECKING
    // $query_rhh = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = s.stockdate)) SET s.rhh =
    // CASE WHEN s.brand = 'AQUA' THEN
    //         CASE
    //           WHEN s.stockdate  = o.req_deliv_date AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL) AND o.material_desc = '5 GALLON AQUA LOCAL' THEN o.do_qty
    //             ELSE 0
    //         END
    //     WHEN s.brand = 'VIT' THEN
    //         CASE
    //           WHEN s.stockdate  = o.req_deliv_date AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL) AND o.material_desc = '5 GALLON VIT LOCAL' THEN o.do_qty
    //             ELSE 0
    //         END
    //     END WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'";

    $query_rhh_aqua = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = s.stockdate) AND (o.material_desc = '5 GALLON AQUA LOCAL') AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL))
    SET s.rhh = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'AQUA'";

    query_executor($con, $query_rhh_aqua);

    $query_rhh_vit = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = s.stockdate) AND (o.material_desc = '5 GALLON VIT LOCAL') AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL)) 
    SET s.rhh = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'VIT'";

    query_executor($con, $query_rhh_vit);

    // $query_rh1 = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 1 DAY))) SET s.rh1 =
    // CASE WHEN s.brand = 'AQUA' THEN 
    //         CASE
    //             WHEN DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL) AND (o.material_desc = '5 GALLON AQUA LOCAL') THEN o.do_qty
    //                 ELSE 0
    //         END 
    //     WHEN s.brand = 'VIT' THEN
    //         CASE
    //             WHEN DATE_ADD(s.stockdate, INTERVAL 1 DAY) = o.req_deliv_date AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL) AND (o.material_desc = '5 GALLON VIT LOCAL') THEN o.do_qty
    //                 ELSE 0
    //         END 
    //     END WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'";

    $query_rh1_aqua = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 1 DAY)) AND (o.material_desc = '5 GALLON AQUA LOCAL') AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL)) 
    SET s.rh1 = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'AQUA'";

    query_executor($con, $query_rh1_aqua);

    $query_rh1_vit = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 1 DAY)) AND (o.material_desc = '5 GALLON VIT LOCAL') AND (o.bill_block = '' or o.bill_block IS NULL) AND (o.rejection_code = '' or o.rejection_code IS NULL)) 
    SET s.rh1 = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'VIT'";

    query_executor($con, $query_rh1_vit);

    // $query_ph2 = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 2 DAY))) SET s.ph2 =
    // CASE WHEN s.brand = 'AQUA' THEN
    //         CASE
    //             WHEN DATE_ADD(s.stockdate, INTERVAL 2 DAY) = o.req_deliv_date AND o.material_desc = '5 GALLON AQUA LOCAL' THEN o.do_qty
    //                 ELSE 0
    //         END
    //     WHEN s.brand = 'VIT' THEN
    //         CASE
    //             WHEN DATE_ADD(s.stockdate, INTERVAL 2 DAY) = o.req_deliv_date AND o.material_desc = '5 GALLON VIT LOCAL' THEN o.do_qty
    //                 ELSE 0
    //         END
    //     END WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'";

    $query_ph2_aqua = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 2 DAY)) AND (o.material_desc = '5 GALLON AQUA LOCAL')) 
    SET s.ph2 = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'AQUA'";

    query_executor($con, $query_ph2_aqua);

    $query_ph2_vit = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 2 DAY)) AND (o.material_desc = '5 GALLON VIT LOCAL')) 
    SET s.ph2 = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'VIT'";

    query_executor($con, $query_ph2_vit);

    // $query_ph3 = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 3 DAY))) SET s.ph3 =
    // CASE WHEN s.brand = 'AQUA' THEN
    //         CASE
    //         WHEN DATE_ADD(s.stockdate, INTERVAL 3 DAY) = o.req_deliv_date AND o.material_desc = '5 GALLON AQUA LOCAL' THEN o.do_qty
    //             ELSE 0
    //         END
    //     WHEN s.brand = 'VIT' THEN
    //         CASE
    //         WHEN DATE_ADD(s.stockdate, INTERVAL 3 DAY) = o.req_deliv_date AND o.material_desc = '5 GALLON VIT LOCAL' THEN o.do_qty
    //             ELSE 0
    //         END
    //     END WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'";

    $query_ph3_aqua = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 3 DAY)) AND (o.material_desc = '5 GALLON AQUA LOCAL')) 
    SET s.ph3 = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'AQUA'";

    query_executor($con, $query_ph3_aqua);

    $query_ph3_vit = "UPDATE tbl_og s INNER JOIN tbl_data_sap o ON ((s.sap_id = o.ship_to) AND (o.req_deliv_date = DATE_ADD(s.stockdate, INTERVAL 3 DAY)) AND (o.material_desc = '5 GALLON VIT LOCAL')) 
    SET s.ph3 = o.do_qty
    WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.brand = 'VIT'";

    query_executor($con, $query_ph3_vit);

    $query_dmin1 = "UPDATE tbl_og t INNER JOIN tbl_stock s SET t.stock_dmin1 = s.stock, t.sellout_dmin1 = s.sellout WHERE s.stockdate = DATE_SUB('$stockdate', INTERVAL 1 DAY) AND s.account = t.account AND s.outlet_id = t.outlet_id";
    query_executor($con, $query_dmin1);

    $query_dplus1 = "UPDATE tbl_og t INNER JOIN tbl_stock s SET t.stock_dplus1 = s.stock, t.stockc_dplus1 = s.stockc, t.sellout_dplus1 = s.sellout WHERE s.stockdate = DATE_ADD('$stockdate', INTERVAL 1 DAY) AND s.account = t.account AND s.outlet_id = t.outlet_id";
    query_executor($con, $query_dplus1);

    $query_d = "UPDATE tbl_og t INNER JOIN tbl_stock s SET t.sellout = s.sellout WHERE s.stockdate = '$stockdate' AND s.account = t.account AND s.outlet_id = t.outlet_id";
    query_executor($con, $query_d);

    echo mysqli_affected_rows($con)."<br>";
    $is_row_affected = $is_row_affected || mysqli_affected_rows($con) > 0;

    echo mysqli_affected_rows($con)."<br>";

    $end_time = time();
    echo "<br><p>Finish time: ".date("Y-m-d h:i:s",$end_time)." </p><br>";
    echo "<p>Total elapsed time: ".($end_time - $start_time) ." detik </p><br>";
    if(!$is_row_affected){
        echo "<script type=\"text/javascript\">
		alert(\"No data available at that stockdate or no data updated\");
		//window.location = \"og_calc?ac=index\"
			</script>";
    }else{
        echo "<script type=\"text/javascript\">
		alert(\"Success update tbl_og\");
		//window.location = \"og_calc?ac=index\"
			</script>";
    }
}
?>
