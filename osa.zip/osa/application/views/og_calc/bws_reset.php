<?php

require_once APP_DIR.'assets/sql_function.php';

function bws_reset($con){
    $q = "
        UPDATE tbl_og s
            SET s.bws = 
                CASE
                    WHEN s.bws like 'Y%' THEN 'Y'
                    WHEN s.bws like 'N%' THEN 'N'
                    ELSE s.bws
                END
        WHERE s.bws !='Y' AND s.bws !='N'
    ";

    query_executor($con, $q);
    if(mysqli_affected_rows($con) > 0){
        echo "<script type=\"text/javascript\">
		alert(\"bws reset berhasil\");
		//window.location = \"og_calc?ac=index\"
			</script>";
    }else{
        echo "<script type=\"text/javascript\">
		alert(\"tidak ada perubahan terjadi\");
		//window.location = \"og_calc?ac=index\"
			</script>";
    }
}
?>
