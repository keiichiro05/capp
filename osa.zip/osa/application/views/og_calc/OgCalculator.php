<?php

class OgCalculator
{

}