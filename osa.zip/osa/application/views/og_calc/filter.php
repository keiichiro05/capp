<?php

function filter_handler($con, $ogdate, $ogurgentdate, $stockdate){


    $str = "
	SELECT jwk from tbl_og 
	WHERE jwk IN ('SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUMAT', 'SABTU')
	GROUP BY jwk
	ORDER BY jwk = 'SABTU', jwk = 'JUMAT', jwk = 'KAMIS', jwk = 'RABU', jwk = 'SELASA', jwk = 'SENIN', jwk ASC
	";
    $result = mysqli_query($con,$str);
    while($row=mysqli_fetch_assoc($result)){
        $mHariJWK[$row['jwk']]=$row['jwk'];
    }

    $hariJWK  = getPreValue("cmdHariJWK",key($mHariJWK));

    $str = "
  SELECT supplier FROM tbl_og WHERE stockdate = '$stockdate' AND og_date = '$ogdate' AND og_urgent_date = '$ogurgentdate' 
  AND supplier LIKE '9000%' GROUP BY supplier";
    $result = mysqli_query($con,$str);


    while($row=mysqli_fetch_assoc($result)){
        $mSupplier[$row['supplier']]=$row['supplier'];
    }

    if (isset($mSupplier)) {
        $daftarSupplier = getPreValue("cmdSupplier",key($mSupplier));
    }

    echo mysqli_affected_rows($con) . "<br>";
    if(mysqli_affected_rows($con) <= 0){
        echo "<script type=\"text/javascript\">
	alert(\"No data available at that stockdate\");
	window.location = \"og_calc?ac=index\"
		</script>";
    }else{
        echo '<div class="formfilter">';
        echo '<form method="post" id="formPageHeader">';
        echo "<div id='container2'>";
        echo "<div class='box_entry'>";
        echo "<div class='card_box'>";
        echo checkBox("cmdHariJWK","","cmdsHariJWK",$hariJWK,$mHariJWK,"");
        echo radioModeSpd();
        echo "</div>";
        echo checkBoxOGMinimal("cmdOGMinimal","","cmdsOGMinimal",$daftarSupplier,$mSupplier,"");
        echo "</div>";

        echo "<div class='box_entry'>";
        echo checkBoxSupplier("cmdSupplier","","cmdsSupplier",$daftarSupplier,$mSupplier,"");
        echo "<div class='card_box'>";
        echo stockdateSpdMultiplier();
        // echo customSPD();
        echo checkBoxBrand();
        echo radioMode();
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "<button type='submit' name='submitfilter' >Submit</button>  &nbsp;";
        echo "</form>";
        echo "</div>";
    }

}
?>
