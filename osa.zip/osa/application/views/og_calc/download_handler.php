<?php

function download_data(mysqli $con, $stockdate, $ogdate, $ogurgentdate){
    $column = "stockdate,og_date, og_urgent_date, account, outlet_id, sap_id, source, supplier, jwk, stockc, stock, 
           brand, jenis_og, og_urgent, og_apollo, osa, forecast, remark,stockc, max_stock3w, spd3w, bws, rhh, 
           rh1, ph2, ph3, fc_urgent4, fc_urgent5, fc_urgent6, fc_urgent7, fc_urgent8, fc_urgent9, fc_urgent10, 
           fc_apollo5, fc_apollo6, fc_apollo7, fc_apollo8, fc_apollo9, fc_apollo10, stockdate0, stockdate1,stockdate2, 
           stockdate3, stockdate4, stockdate5, stockdate6, stockdate7, stockdate8, stockdate9, stockdate10, stock_simu, 
           stockh_1, stockh_2, oos, oos4, oos5,oos6, oos7, oos8, oos9, oos10,truck_capacity";
    $result = query_executor($con, "
    SELECT ".$column."  FROM tbl_og 
	WHERE stockdate= '$stockdate' AND og_date='$ogdate' AND og_urgent_date='$ogurgentdate'");

    if(mysqli_affected_rows($con) <= 0){
        echo "<script type=\"text/javascript\">
		alert(\"No data available at that stockdate\");
		window.location = \"og_calc?ac=index\"
			</script>";
    }else{

        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=\"tbl_og.csv\"");
        header("Content-Transfer-Encoding: binary");
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        ob_end_flush();
        $output = fopen('php://output', 'w');

        fputcsv($output, explode(",", str_replace($column,"", " ")));

        while ($row = mysqli_fetch_assoc($result))
        {
            fputcsv($output, $row);
        }

        fclose($output);
        mysqli_free_result($result);
    }
}
if(isset($_GET["stockdate"]) && isset($_GET["ogdate"]) && isset($_GET["ogurgentdate"])){
    //echo "ca";
    require_once APP_DIR.'config/connection.php';
    try {
        download_data($con, $_GET["stockdate"], $_GET["ogdate"], $_GET["ogurgentdate"]);
    }catch (Error $e){
        echo $e;
    }
}
?>
