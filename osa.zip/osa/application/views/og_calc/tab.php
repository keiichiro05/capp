<style type="text/css">
	div.tab {
	 	margin-bottom: 30px;
	}
	.tab>a { text-decoration: none; }
	.tab>a:hover { border-bottom: 1px dotted gray; }
	.tab>a:active { font-size: 15px; }
	.tab>a::after, .tab>label::after {
	 	margin-left: 15px;
	 	margin-right: 15px;
	 	content: "|";
	 	color: gray;
	 }
</style>

<div class="tab">
	<!-- <label>Data Upload</label> -->
	<a class='tab-menu' href='og_calc'>OG</a>
	<a class='tab-menu' href='og_calc?ac=data_generator'>Data Generator</a>
</div>

