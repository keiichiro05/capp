
<?php
    include APP_DIR.'/views/og_calc/tab.php';
    include APP_DIR.'config/connection.php';
    include APP_DIR.'assets/utility_function.php';
    include APP_DIR.'assets/sql_function.php';
    $spd3w_latest = "SELECT * FROM tbl_generator_log WHERE generator_name = 'spd3w' ORDER BY ID DESC LIMIT 1";
    $result_spd3w = query_executor($con, $spd3w_latest);
    $result_spd3w = $result_spd3w->fetch_array(MYSQLI_ASSOC);
    echo '<strong>','SPD 3 Weeks Date : <br>','</strong>';
    echo 'Start ', date('Y/m/d', strtotime($result_spd3w['date_start'])), ' Until ', date('Y/m/d', strtotime($result_spd3w['date_end']));
    echo '<br>';
    $max3w_latest = "SELECT * FROM tbl_generator_log WHERE generator_name = 'maxstock' ORDER BY ID DESC LIMIT 1";
    $result_max3w = query_executor($con, $max3w_latest);
    $result_max3w = $result_max3w->fetch_array(MYSQLI_ASSOC);
    echo '<strong>','Maxstock 3 Weeks Date : ', '</strong><br>';
    echo 'Start ', date('Y/m/d', strtotime($result_max3w['date_start'])), ' Until ', date('Y/m/d', strtotime($result_max3w['date_end']));
    echo '<br><br>';
  if(!isset($_POST["download"])){
      echo '<html><head>
    <link href="css/jquery.tablesorter.min.css" rel="stylesheet">
      <!-- Pop Up form -->
      <script src="js/popup.form.js" type="text/javascript"></script>
      <link href="css/popup.form.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script>
          $(function() {
            $("#stockdate").datepicker();
            $("#ogdate").datepicker();
            $("#urgentogdate").datepicker();
          });
        </script>
      </head>
      <body>
      <form name="form" action="" method="post">
        <p>Stock Date: <input type="text" name="stockdate" id="stockdate" value=' . (isset($_POST['stockdate']) ? $_POST['stockdate'] : '') . '></p>
      <p>OG Date: <input type="text" name = "ogdate" id="ogdate" value='. (isset($_POST['ogdate']) ? $_POST['ogdate'] : '') .'></p>
      <p>Urgent OG Date: <input type="text" name = "urgentogdate" id="urgentogdate" value='. (isset($_POST['urgentogdate']) ? $_POST['urgentogdate'] : '') .'></p>
      <button type="submit" name="generate" >Generate</button>
      <button type="submit" name="filter" >Show Filter</button>
      <button type="submit" name="download" >Download</button>
      </form>
      <br>
      <br>
      </body></html>
      
      <style type="text/css">
        .box_entry{
          width: 50%;
          float: left;
        
        }
        
        .box_entry {
          border : 3px solid #2989D8;
          padding: 20px;
        }
        
        .card_box {
          border : 3px dotted #2989D8;
          padding: 10px;
        }
        
        </style>
        <script type="text/javascript">
              // $("#cmdSoff").on("change", function(){
              //   this.form.submit();
              // });
              let totalOG = document.getElementsByClassName("totalOG");
              let truckCapacity = document.getElementsByClassName("truckCapacity");
              let tabel = document.getElementById("tabel-summary");
              let rows = tabel.getElementsByTagName("tr");
              for (let i = 0; i < totalOG.length; i++) {
                  if (parseInt(totalOG[i].innerHTML) > parseInt(truckCapacity[i].innerHTML)) {
                      rows[i+1].style.backgroundColor = "#FFCCCB";
                  }
                  else if (parseInt(totalOG[i].innerHTML) < 0.9*parseInt(truckCapacity[i].innerHTML)) {
                      rows[i+1].style.backgroundColor = "#90EE90";
                  }
                  else {
                      rows[i+1].style.backgroundColor = "#FFF192";
                  }
              }
          </script>
      ';
  } ?>

<?php
if(!isset($_SESSION)) 
{ 
	session_start(); 
}

$defaultValue = '0000-00-00';
$_SESSION['stockdate']= isset($_SESSION['stockdate'])?$_SESSION['stockdate']:$defaultValue;
$_SESSION['stockdate']= isset($_POST['stockdate'])?$_POST['stockdate']:$_SESSION['stockdate'];
$stockdate = date("Y-m-d", strtotime($_SESSION['stockdate']));

$_SESSION['ogdate']= isset($_SESSION['ogdate'])?$_SESSION['ogdate']:$defaultValue;
$_SESSION['ogdate']= isset($_POST['ogdate'])?$_POST['ogdate']:$_SESSION['ogdate'];
$ogdate = date("Y-m-d", strtotime($_SESSION['ogdate']));

$_SESSION['urgentogdate']= isset($_SESSION['urgentogdate'])?$_SESSION['urgentogdate']:$defaultValue;
$_SESSION['urgentogdate']= isset($_POST['urgentogdate'])?$_POST['urgentogdate']:$_SESSION['urgentogdate'];
$ogurgentdate = date("Y-m-d", strtotime($_SESSION['urgentogdate']));

$execution_time_limit = 3600;
set_time_limit($execution_time_limit);
include_once APP_DIR.'views/og_calc/generate.php';
include_once APP_DIR.'views/og_calc/filter.php';
include_once APP_DIR.'views/og_calc/bws_reset.php';
include_once APP_DIR.'views/og_calc/download_handler.php';
$currurl = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$convurl = str_replace("index.php", "", $currurl);
$convurl = str_replace("og_calc", "", $currurl);

if(isset($_POST['bws-reset'])){
    bws_reset($con);
}

if(isset($_POST['generate'])){
    generate($con, $ogdate, $ogurgentdate, $stockdate);
} 

if(isset($_POST['filter'])){
    filter_handler($con, $ogdate, $ogurgentdate, $stockdate);
}

// TODO: Investigate this
try{
    if(isset($_POST['submitfilter'])){
        if (empty($_POST['checklist']) and empty($_POST['checklistSupplier']) and empty($_POST['checklistSupplierOG']) and empty($_POST['checklistBrand[]']) and empty($_POST['mode']) and empty($_POST['modeSpd'])) {
            $str="
		UPDATE tbl_og 
			SET osa = 
					(CASE WHEN stock_simu > 4 THEN 1 ELSE 0 END), 
				remark = 
					(CASE WHEN stockdate3 < 5 THEN 'Urgent' 
					WHEN stockdate3 < 9 THEN 'On Risk'
					ELSE '' END)
		WHERE stockdate  = '$stockdate' AND og_date = '$ogdate' AND og_urgent_date = '$ogurgentdate' AND brand = 'AQUA'";
            query_executor($con, $str);

            if(mysqli_affected_rows($con) <= 0){
                echo "<script type=\"text/javascript\">
			alert(\"No data updated\");
			window.location = \"og_calc?ac=index\"
				</script>";
            }else{
                echo "<script type=\"text/javascript\">
			alert(\"Success update OSA\");
			window.location = \"og_calc?ac=index\"
				</script>";
            }

        } else {
            $stockdate0 = date('Y-m-d', strtotime($stockdate));
            $stockdate1 = date('Y-m-d', strtotime($stockdate. '+ 1 day'));
            $stockdate2 = date('Y-m-d', strtotime($stockdate. '+ 2 day'));
            $stockdate3 = date('Y-m-d', strtotime($stockdate. '+ 3 day'));
            $stockdate4 = date('Y-m-d', strtotime($stockdate. '+ 4 day'));

            if (isset($_POST['checklistBrand']) and isset($_POST['mode'])) {
                $itemMode = $_POST['mode'];

                //Reset all og apollo to 0 first
                $q = 'UPDATE tbl_og s SET s.og_apollo = 0, s.blankminus = NULL';
                query_executor($con,$q);

                if ($itemMode == 'PKM') {
                    $str = "UPDATE tbl_og s JOIN tbl_pkm p ON s.outlet_id = p.outlet_id AND s.`account` = p.`account` AND s.brand = p.brand AND p.pkm != 0
                            SET s.max_stock3w = p.pkm WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'";
                    query_executor($con,$str);
                }

                $str = "UPDATE tbl_og s
			SET s.og_apollo = 
			CASE
				WHEN s.max_stock3w - s.stockdate3 < 5 THEN 5 ELSE
					CASE
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN s.max_stock3w 
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN s.max_stock3w - s.stockdate3
						ELSE 5
					END
			END,
            s.blankminus = 
            CASE 
                WHEN s.max_stock3w <= 0 OR s.max_stock3w IS NULL OR s.max_stock3w = '' THEN 'take out'
            END,
			s.jenis_og =
			CASE
				WHEN s.max_stock3w - s.stockdate3 < 5 THEN 'OG Minimal 5' ELSE 
			CASE
				WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN 'OG ORI' 
				WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN 'OG ORI'
				ELSE 'OG Minimal 5'
			END
			END
			WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'";
                query_executor($con,$str);

            }

            // handle OG Minimal by Depo
            if (isset($_POST['checklistSupplierOG']) and isset($_POST['jumlahOGMinimal'])) {
                $counter = 0;
                $jumlahOGMinimal = array();
                foreach ($_POST['jumlahOGMinimal'] as $key => $value) {
                    if ($value != '') {
                        array_push($jumlahOGMinimal, $value);
                    }
                }

                foreach ($_POST['checklistSupplierOG'] as $key => $value) {
                    $str = "
				UPDATE tbl_og s SET 
				s.jenis_og =
				CASE
					WHEN s.og_apollo < ".$jumlahOGMinimal[$counter]." THEN 'OG Minimal ".$jumlahOGMinimal[$counter]."' ELSE 'OG ORI'
				END,
				s.og_apollo = 
				CASE
					WHEN s.og_apollo < ".$jumlahOGMinimal[$counter]." THEN ".$jumlahOGMinimal[$counter]." ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate3 + ".((isset($jumlahSPD[$counter])) ? $jumlahSPD[$counter] : 0)."*s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate3 + ".((isset($jumlahSPD[$counter])) ? $jumlahSPD[$counter] : 0)."*s.spd3w
						END
				END
				WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.supplier = '".$value."' 
				";
                    query_executor($con, $str);
                    $counter++;
                }


            }

            if (isset($_POST['checklistSupplier']) and isset($_POST['jumlahSPD'])) {
                $counter = 0;
                $jumlahSPD = array();
                foreach ($_POST['jumlahSPD'] as $key => $value) {
                    if ($value != '') {
                        array_push($jumlahSPD, $value);
                    }
                }

                foreach ($_POST['checklistSupplier'] as $key => $value) {

                    $str = "
				UPDATE tbl_og s
				SET s.og_apollo = 
					CASE
						WHEN s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w < 5 THEN 5 ELSE
							CASE
								WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w >= s.max_stock3w THEN s.max_stock3w 
								WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w < s.max_stock3w THEN s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w
								ELSE 5
							END
					END,
					s.jenis_og =
					CASE
						WHEN s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w < 5 THEN 'OG Minimal 5' ELSE 
					CASE
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w >= s.max_stock3w THEN 'OG ORI' 
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 + ".$jumlahSPD[$counter]."*s.spd3w < s.max_stock3w THEN 'OG ORI'
						ELSE 'OG Minimal 5'
					END
					END
				WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.supplier = '".$value."'";
                    query_executor($con, $str);

                    $counter++;
                }

            }
        

            }

            if (isset($_POST['modeSpd'])) {
                $modeSpd = $_POST['modeSpd'];

                if ($modeSpd == 'typeSpd') {
                    $str = "
				UPDATE tbl_og s 
				SET s.og_apollo = 
				CASE
					WHEN s.max_stock3w - s.stockdate3 < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN s.max_stock3w 
							WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN s.max_stock3w - s.stockdate3
							ELSE 5
						END
				END,
				s.jenis_og =
				CASE
					WHEN s.max_stock3w - s.stockdate3 < 5 THEN 'OG Minimal 5' ELSE 
					CASE
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN 'OG ORI' 
						WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN 'OG ORI'
						ELSE 'OG Minimal 5'
					END
				END
				WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate' AND s.source = 'Depo';
				";
                    query_executor($con, $str);
                }
                else if ($modeSpd == 'typeForecast') {
                    $str = "
				UPDATE tbl_og s 
				SET s.og_apollo = 
				CASE
					WHEN s.max_stock3w - s.stock_simu + s.forecast < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stock_simu + s.forecast >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stock_simu + s.forecast
						END
				END,
				s.jenis_og =
				CASE
					WHEN s.max_stock3w - s.stock_simu + s.forecast < 5 THEN 'OG Minimal 5' ELSE 'OG ORI'
				END
				WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'; 
				";
                    query_executor($con, $str);
                }

            if (isset($_POST['checklist'])) {
                $item = $_POST['checklist'][0];

                $jwkForecast = '';
                if ($item == 'SENIN') {
                    $jwkForecast = 1;
                }
                else if ($item == 'SELASA') {
                    $jwkForecast = 2;
                }
                else if ($item == 'RABU') {
                    $jwkForecast = 3;
                }
                else if ($item == 'KAMIS') {
                    $jwkForecast = 4;
                }
                else if ($item == 'JUMAT') {
                    $jwkForecast = 5;
                }
                else if ($item == 'SABTU') {
                    $jwkForecast = 6;
                }

                $regexp = $item;
                foreach($_POST['checklist'] as $item) {
                    $regexp .= "|".$item."";
                }

                $spdMultiplier = 0.5;
                if(isset($_POST['spdMultiplier'])){
                    //echo $_POST['spdMultiplier'];
                    $spdMultiplier = (float)$_POST['spdMultiplier'];
                }

                $customSPD = 0;
                if(isset($_POST['customSPD'])){
                    echo $_POST['customSPD'];
                    $customSPD = (float)$_POST['customSPD'];
                }

                $query = "
            UPDATE 
              tbl_og s 
              JOIN (
                SELECT 
                  sap_id, 
                  brand, 
                  spd3week 
                FROM 
                  tbl_spd3w
              ) AS spd3 ON spd3.sap_id = s.sap_id 
              AND spd3.brand = s.brand 
            SET 
            s.stockdate0 =
            CASE 
                WHEN s.`account` = 'IDM' THEN
                    CASE 
                        WHEN s.`stockc` IS NOT NULL OR s.`stockc` != '' THEN s.`stock` 
                        WHEN s.stock_dmin1 + s.rhh - spd3.spd3week < 0 THEN 0
                        ELSE s.stock_dmin1 + s.rhh - spd3.spd3week 
                    END 
                ELSE 
                    CASE 
                        WHEN s.`stockc` IS NOT NULL OR s.`stockc` != '' THEN 
                            CASE
                                WHEN s.stock + s.rhh - s.sellout < 0 THEN 0
                                ELSE s.stock + s.rhh - s.sellout
                            END
                        WHEN s.stock_dmin1 + s.rh_min1 + s.rhh - (".$spdMultiplier." * s.spd3w) - s.sellout_dmin1 < 0 THEN 0
                        ELSE s.stock_dmin1 + s.rh_min1 + s.rhh - (".$spdMultiplier." * s.spd3w) - s.sellout_dmin1 
                    END 
            END,
              
            s.stockdate1 = 
            CASE 
                WHEN s.`account` = 'IDM' THEN 
                    CASE 
                        WHEN s.stockc_dplus1 IS NULL OR stockc_dplus1 = '' THEN 
                            CASE
                                WHEN s.stockdate0 + s.rh1 - (".$spdMultiplier." * s.spd3w) < 0 THEN 0
                                ELSE s.stockdate0 + s.rh1 - (".$spdMultiplier." * s.spd3w)
                            END
                        ELSE s.stock_dplus1
                    END 
                ELSE 
                    CASE 
                        WHEN s.stockc_dplus1 IS NULL OR s.stockc_dplus1 = '' THEN
                            CASE
                                WHEN s.stockdate0 + s.rh1 - (".$spdMultiplier." * s.spd3w) < 0 THEN 0
                                ELSE s.stockdate0 + s.rh1 - (".$spdMultiplier." * s.spd3w)
                            END
                            
                        ELSE
                            CASE 
                                WHEN s.stock_dplus1 + s.rh1 - s.sellout_dplus1 < 0 THEN 0
                                ELSE s.stock_dplus1 + s.rh1 - s.sellout_dplus1
                            END
                        END 
            END 
            WHERE 
            s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate';
            "; 

            query_executor($con, $query);

                $updater_query0 = "
            UPDATE tbl_og s 
            SET
            s.stockdate2 = 
                  CASE
                      WHEN s.stockdate1 + s.ph2 - (".$spdMultiplier." * s.spd3w) < 0 THEN 0 ELSE s.stockdate1 + s.ph2 - (".$spdMultiplier." * s.spd3w)
                  END,
            s.blankminus =
                  CASE
                      WHEN s.blankminus = 'take out' THEN 'take out'
                      WHEN (s.stockc_dplus1 IS NULL OR s.stockc_dplus1 = '' OR s.stockc_dplus1 < 0) AND (s.stockc IS NULL OR s.stockc = '' OR s.stockc < 0) THEN 'take out'
                      ELSE NULL
                  END,
            s.oos =
			  CASE 
              WHEN s.brand = 'AQUA' AND s.bws = 'BWS' THEN
              CASE
                  WHEN s.blankminus = 'take out' THEN 'NO'
                  WHEN s.stockdate0 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.ph2=0) THEN 'YES'
                  WHEN s.stockdate0 > 10 AND s.stockdate0 <= s.spd3w*3 + 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.ph2=0) THEN 'Resiko OOS'
                  WHEN s.stockc IS NULL OR s.stockc = '' OR s.stockc THEN 'NO'
                  ELSE 'NO'
              END
          WHEN s.brand = 'AQUA' AND s.bws <> 'BWS' THEN
              CASE
                  WHEN s.blankminus = 'take out' THEN 'NO'
                  WHEN s.stockdate1 < 3 AND (s.ph2=0 AND s.ph3=0) THEN 'YES'
                  WHEN s.stockdate1 >= 3 AND s.ph2=0 AND s.stockdate2 + s.ph3 - (".$spdMultiplier." * s.spd3w) < 3 THEN 'Resiko OOS'
                          ELSE 'NO'
                      END
		    WHEN s.brand = 'VIT' AND s.stockdate0 < 2 AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh=0) THEN 'YES'
			WHEN s.brand = 'VIT' AND s.stockdate0 <= s.spd3w*3 AND (s.ph3=0 AND s.rh1=0 AND s.ph2=0 AND s.rhh=0) THEN 'Resiko OOS'
			ELSE 'NO'
			  END,
              s.og_urgent =
                  CASE
                      WHEN (s.stockc_dplus1 IS NULL OR s.stockc_dplus1 = '') AND (s.stockc IS NULL OR s.stockc = '') THEN 0
                      WHEN s.brand = 'AQUA' AND (s.oos = 'YES' OR s.oos = 'Resiko OOS') AND s.stockc >= 0 THEN 
                          CASE
                              WHEN s.spd3w < 0 THEN 5 ELSE 
                                  CASE
                                      WHEN s.spd3w*4 < 3 THEN 5 
                                      ELSE CASE
                                        WHEN (s.spd3w*4) > s.max_stock3w THEN s.max_stock3w 
                                        ELSE s.spd3w*4 
                                        END
                                  END
                          END
                      WHEN s.brand = 'VIT' AND (s.oos = 'YES' OR s.oos = 'Resiko OOS') AND s.stockc >= 0 THEN 5 
                      WHEN s.stockc <= 0 THEN 0
                      ELSE 0
                  END,
              s.stockdate3 = 
                  CASE
                      WHEN s.stockdate2 + s.ph3 - (".$spdMultiplier." * s.spd3w) + s.og_urgent < 0 THEN 0 ELSE s.stockdate2 + s.ph3 - (".$spdMultiplier." * s.spd3w) + s.og_urgent
                  END,
              s.og_apollo = 
              CASE
                  WHEN s.jwk REGEXP '".$regexp."' THEN
                      CASE
                      WHEN s.max_stock3w - s.stockdate3 < 5 THEN 5 
                      ELSE
                          CASE
                              WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN s.max_stock3w 
                              WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN s.max_stock3w - s.stockdate3
                              ELSE 5
                          END
                      END
                  ELSE 0
              END,
              s.blankminus =
              CASE
                  WHEN s.jwk REGEXP '".$regexp."' THEN NULL
                  ELSE 'take out'
              END,
              s.og_apollo =
                    CASE
                        WHEN s.blankminus = 'take out' THEN 0
                        ELSE s.og_apollo
                    END,
              s.jenis_og =
              CASE
                WHEN s.max_stock3w - s.stockdate3 < 5 THEN 'OG Minimal 5' ELSE 
                CASE
                    WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 >= s.max_stock3w THEN 'OG ORI' 
                    WHEN s.max_stock3w >= 5 AND s.max_stock3w - s.stockdate3 < s.max_stock3w THEN 'OG ORI'
                    ELSE 'OG Minimal 5'
                END
              END,
              s.stockdate4 = 
                  CASE
                      WHEN s.stockdate3 + s.og_apollo - s.spd3w < 0 THEN 0 ELSE s.stockdate3 + s.og_apollo - s.spd3w
                  END
              WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate'
                ";
                query_executor($con, $updater_query0);

                $query = "
            UPDATE tbl_og s
            SET s.oos4 =
                CASE 
                    WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
                        CASE
                            WHEN s.stockdate1 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
                            WHEN s.stockdate3 + s.og_apollo - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
                            ELSE 'NO'
                        END
                    WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
                        CASE
                            WHEN s.stockdate1 < 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
                            WHEN s.stockdate3 + s.og_apollo - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
                            ELSE 'NO'
                        END
                    WHEN s.brand = 'VIT' AND s.stockdate1 < 2 AND s.stockh_1 < 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
                    WHEN s.brand = 'VIT' AND s.stockdate1 <= s.spd3w*3 AND s.stockh_1 > 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'Resiko OOS'
                    ELSE 'NO'
                END,
                s.fc_urgent4 =
                CASE
                    WHEN s.brand = 'AQUA' AND (s.oos4 = 'YES' OR s.oos4 = 'Resiko OOS') THEN 
                        CASE
                            WHEN s.spd3w < 0 THEN 5 ELSE 
                                CASE
                                    WHEN s.spd3w*4 < 5 THEN 5
                                    WHEN s.spd3w*4 >= s.max_stock3w THEN s.max_stock3w
                                    ELSE s.spd3w*4
                                END
                        END
                    WHEN s.brand = 'VIT' AND (s.oos4 = 'YES' OR s.oos4 = 'Resiko OOS') THEN 5 ELSE 0
                END
                WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate';
            ";
                query_executor($con, $query);

                $query = "
            UPDATE tbl_og s INNER JOIN tbl_truckcapacity t ON LOWER(t.hari) LIKE concat('%', LOWER(s.jwk), '%')
            SET s.truck_capacity = t.truck_capacity
            WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate';
            ";
                query_executor($con, $query);


                // UPDATER QUERY ORI FROM INDEX
                $updater_query = "
			UPDATE tbl_og s
			SET s.oos4 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate1 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate3 + s.og_apollo - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate1 < 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate3 + s.og_apollo - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate1 < 2 AND s.stockh_1 < 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate1 <= spd3w*3 AND s.stockh_1 > 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.ph2=0 AND s.og_urgent=0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent4 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos4 = 'YES' OR s.oos4 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w <= 0 THEN 5 ELSE 
								CASE
									WHEN s.spd3w*4 < 5 THEN 5 ELSE s.spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos4 = 'YES' OR s.oos4 = 'Resiko OOS') THEN 5 ELSE 0
				END, 
	
				s.fc_apollo5 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate4 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate4 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate4 + s.spd3w
						END
				END, 
				s.oos5 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate2 < 10 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.fc_urgent4=0 AND s.fc_apollo5=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate4 + s.fc_apollo5 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate2 < 5 AND (s.stockc >= 0) AND (s.ph3=0 AND s.og_apollo=0 AND s.fc_urgent4=0 AND s.fc_apollo5=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate4 + s.fc_apollo5 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate2 < 2 AND s.stockh_1 < 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.fc_urgent4=0 AND s.fc_apollo5=0 AND s.og_urgent = 0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate2 <= s.spd3w*3 AND s.stockh_1 > 2 AND (s.ph3=0 AND s.og_apollo=0 AND s.fc_urgent4=0 AND s.fc_apollo5=0 AND s.og_urgent = 0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent5 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos5 = 'YES' OR s.oos5 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN s.spd3w*4 < 5 THEN 5 ELSE s.spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos5 = 'YES' OR s.oos5 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate5 = 
				CASE
					WHEN s.stockdate4 + s.fc_urgent5 + s.fc_apollo5 - s.spd3w < 0 THEN 0 ELSE s.stockdate4 + s.fc_urgent5 + s.fc_apollo5 - s.spd3w
				END,
				
				s.fc_apollo6 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate5 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate5 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate5 + s.spd3w
						END
				END,
				s.oos6 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate3 < 10 AND (s.stockc >= 0) AND ((s.og_apollo + s.fc_urgent4)=0 AND s.fc_apollo5=0 AND s.fc_urgent5=0 AND s.fc_apollo6=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate5 + s.fc_apollo6 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate3 < 5 AND (s.stockc >= 0) AND ((s.og_apollo + s.fc_urgent4)=0 AND s.fc_apollo5=0 AND s.fc_urgent5=0 AND s.fc_apollo6=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate5 + s.fc_apollo6 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate3 < 2 AND s.stockh_1 < 2 AND ((s.og_apollo + s.fc_urgent4)=0 AND s.fc_apollo5=0 AND s.fc_urgent5=0 AND s.fc_apollo6=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate3 <= s.spd3w*3 AND s.stockh_1 > 2 AND ((s.og_apollo + s.fc_urgent4)=0 AND s.fc_apollo5=0 AND s.fc_urgent5=0 AND s.fc_apollo6=0 AND s.og_urgent=0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent6 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos6 = 'YES' OR s.oos6 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN s.spd3w*4 < 5 THEN 5 ELSE s.spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos6 = 'YES' OR s.oos6 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate6 = 
				CASE
					WHEN s.stockdate5 + s.fc_urgent6 + s.fc_apollo6 - s.spd3w < 0 THEN 0 ELSE s.stockdate5 + s.fc_urgent6 + s.fc_apollo6 - s.spd3w
				END,
				
				s.fc_apollo7 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate6 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate6 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate6 + s.spd3w
						END
				END,
				s.oos7 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate4 < 10 AND (s.stockc >= 0) AND ((s.fc_apollo5 + s.fc_urgent5)=0 AND s.fc_apollo6=0 AND s.fc_urgent6=0 AND s.fc_apollo7=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate6 + s.fc_apollo7 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate4 < 5 AND (s.stockc >= 0) AND ((s.fc_apollo5 + s.fc_urgent5)=0 AND s.fc_apollo6=0 AND s.fc_urgent6=0 AND s.fc_apollo7=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate6 + s.fc_apollo7 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate4 < 2 AND s.stockh_1 < 2 AND ((s.fc_apollo5 + s.fc_urgent5)=0 AND s.fc_apollo6=0 AND s.fc_urgent6=0 AND s.fc_apollo7=0 AND s.og_urgent = 0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate4 <= s.spd3w*3 AND s.stockh_1 > 2 AND ((s.fc_apollo5 + s.fc_urgent5)=0 AND s.fc_apollo6=0 AND s.fc_urgent6=0 AND s.fc_apollo7=0 AND s.og_urgent = 0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent7 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos7 = 'YES' OR s.oos7 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN s.spd3w*4 < 5 THEN 5 ELSE s.spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos7 = 'YES' OR s.oos7 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate7 = 
				CASE
					WHEN s.stockdate6 + s.fc_urgent7 + s.fc_apollo7 - s.spd3w < 0 THEN 0 ELSE s.stockdate6 + s.fc_urgent7 + s.fc_apollo7 - s.spd3w
				END,
				
				s.fc_apollo8 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate7 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate7 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate7 + s.spd3w
						END
				END,
				s.oos8 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate5 < 10 AND (s.stockc >= 0) AND ((s.fc_apollo6 + s.fc_urgent6)=0 AND s.fc_apollo7=0 AND s.fc_urgent7=0 AND s.fc_apollo8=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate7 + s.fc_apollo8 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate5 < 5 AND (s.stockc >= 0) AND ((s.fc_apollo6 + s.fc_urgent6)=0 AND s.fc_apollo7=0 AND s.fc_urgent7=0 AND s.fc_apollo8=0 AND s.og_urgent = 0) THEN 'YES'
							WHEN s.stockdate7 + s.fc_apollo8 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate5 < 2 AND s.stockh_1 < 2 AND ((s.fc_apollo6 + s.fc_urgent6)=0 AND s.fc_apollo7=0 AND s.fc_urgent7=0 AND s.fc_apollo8=0 AND s.og_urgent = 0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate5 <= s.spd3w*3 AND s.stockh_1 > 2 AND ((s.fc_apollo6 + s.fc_urgent6)=0 AND s.fc_apollo7=0 AND s.fc_urgent7=0 AND s.fc_apollo8=0 AND s.og_urgent = 0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent8 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos8 = 'YES' OR s.oos8 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN s.spd3w*4 < 5 THEN 5 ELSE s.spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos8 = 'YES' OR s.oos8 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate8 = 
				CASE
					WHEN s.stockdate7 + s.fc_urgent8 + s.fc_apollo8 - s.spd3w < 0 THEN 0 ELSE s.stockdate7 + s.fc_urgent8 + s.fc_apollo8 - s.spd3w
				END,
				
				s.fc_apollo9 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate8 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate8 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate8 + s.spd3w
						END
				END,
				s.oos9 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate6 < 10 AND (s.stockc >= 0) AND ((s.fc_apollo7 + s.fc_urgent7)=0 AND s.fc_apollo8=0 AND s.fc_urgent8=0 AND s.fc_apollo9=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate8 + s.fc_apollo9 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate6 < 5 AND (s.stockc >= 0) AND ((s.fc_apollo7 + s.fc_urgent7)=0 AND s.fc_apollo8=0 AND s.fc_urgent8=0 AND s.fc_apollo9=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate8 + s.fc_apollo9 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate6 < 2 AND s.stockh_1 < 2 AND ((s.fc_apollo7 + s.fc_urgent7)=0 AND s.fc_apollo8=0 AND s.fc_urgent8=0 AND s.fc_apollo9=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate6 <= s.spd3w*3 AND s.stockh_1 > 2 AND ((s.fc_apollo7 + s.fc_urgent7)=0 AND s.fc_apollo8=0 AND s.fc_urgent8=0 AND s.fc_apollo9=0 AND s.og_urgent=0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent9 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos9 = 'YES' OR s.oos9 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN s.spd3w*4 < 5 THEN 5 ELSE s.spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos9 = 'YES' OR s.oos9 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate9 = 
				CASE
					WHEN s.stockdate8 + s.fc_urgent9 + s.fc_apollo9 - s.spd3w < 0 THEN 0 ELSE s.stockdate8 + s.fc_urgent9 + s.fc_apollo9 - s.spd3w
				END,
				
				s.fc_apollo10 = 
				CASE
					WHEN s.jwk LIKE '%".hariForecast($jwkForecast, 1)."%' AND s.max_stock3w - s.stockdate9 + s.spd3w < 5 THEN 5 ELSE
						CASE
							WHEN s.max_stock3w - s.stockdate9 + s.spd3w >= s.max_stock3w THEN s.max_stock3w ELSE s.max_stock3w - s.stockdate9 + s.spd3w
						END
				END,
				s.oos10 =
				CASE 
					WHEN s.brand = 'AQUA' AND s.bws = 'Y' THEN
						CASE
							WHEN s.stockdate7 < 10 AND (s.stockc >= 0) AND ((s.fc_apollo8 + s.fc_urgent8)=0 AND s.fc_apollo9=0 AND s.fc_urgent9=0 AND s.fc_apollo10=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate9 + s.fc_apollo10 - s.spd3w <= 10 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'AQUA' AND s.bws = 'N' THEN
						CASE
							WHEN s.stockdate7 < 5 AND (s.stockc >= 0) AND ((s.fc_apollo8 + s.fc_urgent8)=0 AND s.fc_apollo9=0 AND s.fc_urgent9=0 AND s.fc_apollo10=0 AND s.og_urgent=0) THEN 'YES'
							WHEN s.stockdate9 + s.fc_apollo10 - s.spd3w <= 5 AND (s.stockc >= 0) THEN 'Resiko OOS'
							ELSE 'NO'
						END
					WHEN s.brand = 'VIT' AND s.stockdate7 < 2 AND s.stockh_1 < 2 AND ((s.fc_apollo8 + s.fc_urgent8)=0 AND s.fc_apollo9=0 AND s.fc_urgent9=0 AND s.fc_apollo10=0 AND s.og_urgent=0) THEN 'YES'
					WHEN s.brand = 'VIT' AND s.stockdate7 <= s.spd3w*3 AND s.stockh_1 > 2 AND ((s.fc_apollo8 + s.fc_urgent8)=0 AND s.fc_apollo9=0 AND s.fc_urgent9=0 AND s.fc_apollo10=0 AND s.og_urgent=0) THEN 'Resiko OOS'
					ELSE 'NO'
				END,
				s.fc_urgent10 =
				CASE
					WHEN s.brand = 'AQUA' AND (s.oos10 = 'YES' OR s.oos10 = 'Resiko OOS') THEN 
						CASE
							WHEN s.spd3w < 0 THEN 5 ELSE 
								CASE
									WHEN s.spd3w*4 < 5 THEN 5 ELSE s.spd3w*4
								END
						END
					WHEN s.brand = 'VIT' AND (s.oos10 = 'YES' OR s.oos10 = 'Resiko OOS') THEN 5 ELSE 0
				END,
				s.stockdate10 = 
				CASE
					WHEN s.stockdate9 + s.fc_urgent10 + s.fc_apollo10 - s.spd3w < 0 THEN 0 ELSE s.stockdate9 + s.fc_urgent10 + s.fc_apollo10 - s.spd3w
				END,
                s.og_apollo =
                    CASE
                        WHEN s.jwk REGEXP 'Ganjil$' AND WEEK('$ogdate')%2 = 0 THEN 0
                        WHEN s.jwk REGEXP 'Genap$' AND WEEK('$ogdate')%2 = 1 THEN 0 
                        ELSE s.og_apollo
                    END,
                s.og_total =
                    CASE WHEN s.og_apollo + s.og_urgent > s.max_stock3w THEN s.max_stock3w 
                    ELSE s.og_apollo + s.og_urgent
                    END
			WHERE s.stockdate = '$stockdate' AND s.og_date = '$ogdate' AND s.og_urgent_date = '$ogurgentdate';
			";
                query_executor($con, $updater_query);


//        $str = "SELECT stockdate, account, outlet_id,sap_id, source, supplier, jwk, stock_simu, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, ROUND(spd3w,2) AS spd3w, forecast, og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 FROM tbl_og
//			WHERE stockdate='$stockdate' AND og_date = '$ogdate' AND og_urgent_date = '$ogurgentdate' AND jwk REGEXP '".$item."";
//		foreach($_POST['checklist'] as $item) {
//			$str .= "|".$item."";
//		}
//		$str .= "'";
//		$str .= " UNION ";
//		$item = $_POST['checklist'][0];
//		$str .= "SELECT stockdate, account, outlet_id, sap_id, source, supplier, jwk, stock_simu, osa, brand, stockdate0, stockdate1, stockdate2, stockdate3, stockdate4, max_stock3w, ROUND(spd3w,2) AS spd3w, forecast, @og_apollo:=0 as og_apollo, jenis_og, truck_capacity, bws, oos, remark, og_urgent, fc_urgent4 FROM tbl_og
//				WHERE stockdate='$stockdate' AND og_date = '$ogdate' AND og_urgent_date = '$ogurgentdate' AND jwk NOT REGEXP '".$item."";
//		foreach($_POST['checklist'] as $item) {
//			$str .= "|".$item."";
//		}
//		$str .= "'";
                //$result = query_executor($con,$str);

                // Summary
                $str = "
        WITH og_temp AS (
            SELECT supplier,jwk, outlet_id, outlet_name, fc_urgent4, og_apollo, truck_capacity, og_urgent
            FROM tbl_og
            WHERE stockdate = '$stockdate' AND og_date = '$ogdate' AND og_urgent_date = '$ogurgentdate' AND
            supplier <> '' AND supplier LIKE '9000%'
        ),
        og_urgent_calc AS(
            SELECT SUM(og_urgent) as ogu, supplier AS sup FROM og_temp
            GROUP BY supplier
        )
		SELECT
			s.supplier, 
			COUNT(s.outlet_id) AS total_toko,
			SUM(s.fc_urgent4) AS total_fc_urgent,
			SUM(s.og_apollo) AS total_og_apollo,
			SUM(s.fc_urgent4+s.og_apollo) AS total_og,
			s.truck_capacity AS truck_capacity,
			t.ogu AS og_urgent
		FROM 
			og_temp s 
		INNER JOIN og_urgent_calc t ON t.sup = s.supplier
		WHERE s.jwk REGEXP '".$item."";
                foreach($_POST['checklist'] as $item) {
                    $str .= "|".$item."";
                }
                $str .= "'";
                $str .= " 
		GROUP BY 
			s.supplier, s.truck_capacity
		";

                var_dump($str);
                $resultSummary = query_executor($con, $str);

                $rowSummary = array();

                try{
                    while ($row = mysqli_fetch_array($resultSummary)) {
                        //echo $row;
                        $rowSummary[$row['supplier']."-".$row['total_toko']."-".$row['total_fc_urgent']."-".$row['total_og_apollo']."-".$row['total_og']."-".$row['truck_capacity']."-".$row['og_urgent']]=$row;
                    }

                    echo "<h3>Summary</h3>";
                    echo "<table class='table-control' id='tabel-summary'>";
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th>Depo</th>";
                    echo "<th>Total Toko</th>";
                    echo "<th>OG Urgent</th>";
                    echo "<th>Total FC Urgent</th>";
                    echo "<th>Total OG Apollo</th>";
                    echo "<th>Total OG </th>";
                    echo "<th>Truck Capacity</th>";
                    echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    foreach ($rowSummary as $key => $value) {
                        echo "<tr class='cari'>";
                        echo " <td> ".$rowSummary[$key]['supplier']. "</td>";
                        echo "<td>". $rowSummary[$key]['total_toko']."</td>";
                        echo "<td>". $rowSummary[$key]['og_urgent']."</td>";
                        echo "<td class='totalOG'>". $rowSummary[$key]['total_fc_urgent']."</td>";
                        echo "<td class='totalOG'>". $rowSummary[$key]['total_og_apollo']."</td>";
                        echo "<td class='totalOG'>". $rowSummary[$key]['total_og']."</td>";
                        if($rowSummary[$key]['truck_capacity'] < $rowSummary[$key]['total_og']){
                            echo "<td bgcolor='#ff0000' class='truckCapacity'>".$rowSummary[$key]['truck_capacity']."</td>";
                        }else{
                            echo "<td bgcolor='#00FF00' class='truckCapacity'>".$rowSummary[$key]['truck_capacity']."</td>";
                        }
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                    $uri = 'https://'.$convurl.'unduh_csv?stockdate='.$stockdate.'&ogdate='.$ogdate.'&ogurgentdate='.$ogurgentdate;
                    echo '<br><a href="'.$uri.'">download csv here</a>';
                }catch (Exception $e){
                    echo $e;
                }

            }

        }
    }
}catch (Error $e){
    echo "ERROR TERJADI KETIKA GENERATE HASIL FILTER<br>";
    var_dump($e);
}

if(isset($_POST['download'])){
    //echo $convurl;
    header("Location: https://".$convurl."unduh_csv?stockdate=".$stockdate."&ogdate=".$ogdate."&ogurgentdate=".$ogurgentdate);
}
?>