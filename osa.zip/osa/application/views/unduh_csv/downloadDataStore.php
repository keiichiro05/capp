<?php
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/sql_function.php';

    try {
        $column = "seq, source, branch, outlet_id, sap_id, outlet_name, quadrant, region, account, remark, supplier, jwk, bws, region_sales, active, brand, upload_date";
        $column = str_replace("\n","",str_replace(" ", "", $column));
        $str = "SELECT ".$column." FROM tbl_store";
        $result = query_executor($con, $str);
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=\"tbl_store.csv\"");
        header("Content-Transfer-Encoding: binary");
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        ob_clean();
        $output = fopen('php://output', 'w');
        fputcsv($output, explode(",", $column));
        while ($row = mysqli_fetch_assoc($result))
        {
            fputcsv($output, $row);
        }

        fclose($output);
        mysqli_free_result($result);
    } catch(Error $e) {
        echo $e;
    }

    echo "<script>location.replace('upload?ac=masterstore');</script>";


?>
