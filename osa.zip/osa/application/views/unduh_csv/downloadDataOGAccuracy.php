<?php
include APP_DIR.'/config/connection.php';
include APP_DIR.'/assets/sql_function.php';

    try {
        $column = "sap_id, supplier, brand, prd_id, segment, date, week, outlet_id, cust_name, stock, spd, og_apollo, og_urgent, total_og, po_qty, real_do, so_cap";
        $column = str_replace("\n","",str_replace(" ", "", $column));
        $str = "SELECT ".$column." FROM tbl_og_accuracy";
        $result = query_executor($con, $str);
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=\"tbl_sps.csv\"");
        header("Content-Transfer-Encoding: binary");
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        ob_clean();
        $output = fopen('php://output', 'w');
        fputcsv($output, explode(",", $column));
        while ($row = mysqli_fetch_assoc($result))
        {
            fputcsv($output, $row);
        }

        fclose($output);
        mysqli_free_result($result);
    } catch(Error $e) {
        echo $e;
    }

    echo "<script>location.replace('upload?ac=viewRangedData');</script>";


?>
