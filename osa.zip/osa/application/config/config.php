<?php
/*
# Project : eVisitor
# Auth    : damarteduh@gmail.com©2020, 
# Rev     : 
	KOPI TUGOH BOGOR, 2020-01-25 10:37 AM
*/

define('ROOT_DIR', realpath(dirname(__FILE__)) . '/');
define('APP_DIR', 'application/');
//foc
// define('API_SERVER', 'http://localhost/osa-dev/adopapi/');
//osa
//define('API_SERVER', 'http://10.203.121.81/osa-dev/adopapi/');
define('API_SERVER', 'http://10.203.121.73:83/adopapi/');
define('API_KEY', 'ZmluYW5jZUBkYW1hcnRlZHVoMjAyMA==');
define('APP_NAME', 'Customer Solution');
define('APP_DESCRIPTION', 'OSA Simulation');
define('APP_VER', '1.0');


# Master Main Modul ( controller )
$mModul = array(
	"report" => array(
		"judul" => "Result",
		"Sub" => array("" => "")
	),
	"upload" => array(
		"judul" => "Data Uploader",
		"Sub" => array("" => "")
	),
	"bseco" => array(
		"judul" => "Store Status",
		"Sub" => array("" => "")
	),
	#baru ditambahin
	"og_calc" => array(
		"judul" => "OG Calculation",
		"Sub" => array("download_handler.php" => "download_handler.php")
	),
	"compliance" => array(
		"judul" => "OG Accuracy",
		"Sub" => array("" => "")
	),
    "unduh_csv" => array(
        "Sub" => array("" => "")
    ),
	"complaint" => array(
		"judul" => "Complaint",
		"Sub" => array("" => "")
	),
	"db_176" => array(
		"judul" => "Database 176",
        "Sub" => array("" => "")
    ),

);

if (isset($_COOKIE['key'])) {
	$json_decrypt = openssl_decrypt($_COOKIE['key'], "AES-128-CTR", "D4marT3duh@>ADOP", 0, "ADOP@>D4marT3duh");
	$arr_plant = json_decode($json_decrypt, true);
	define('PLANTID', $arr_plant['nKode']);
	define('PLANTNAME', $arr_plant['plant_name']);
	define('SHORTNAME', $arr_plant['short_name']);
}
