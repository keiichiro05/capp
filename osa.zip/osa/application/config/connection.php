<?php
/*
# Prject: BWG Project 1.0
# Auth  : DamarTeduh©2019
# Create: Plant Pandaan | 2019-10-29 02:14 PM
# Ket   : Main connection ke server cloud
*/

#server
// eval(base64_decode("JGRiX2hvc3QgPSAnbG9jYWxob3N0JzskZGJfdXNlciA9ICd3ZWJ1c2VyJzskZGJfcHN3ZCA9ICc0ZG0xbkBvdGlmJzskZGJfbmFtZSA9ICdkYl9kZXBvJzs="));

//osa
//$db_host = '10.203.121.81';$db_user = 'user_bi';$db_pswd = 'user.bi';$db_name='dbosa';
$db_host = '10.203.121.177';$db_user = 'hermawed';$db_pswd = 'KapanTraktirnya';$db_name='dbosa';
$db_host_176 = '10.203.121.176';$db_user_176 = 'hermawed';$db_pswd_176 = 'P@$$w0rds';$db_name_176='dbosa';
// $db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='dbosa';
//foc
//$db_host = 'localhost';$db_user = 'root';$db_pswd = '';$db_name='dbdump';
$con = @mysqli_connect($db_host, $db_user, $db_pswd,$db_name) or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);

$con_176 = @mysqli_connect($db_host_176, $db_user_176, $db_pswd_176,$db_name_176) or
    die('<body style="font-family: arial;"><div style="padding: 20px;border:dotted 1px gray;color: #f44336;"><b>ERROR !</b><small> Server Connection Lost,'.mysqli_connect_error().'</small></div></body>');
$con_176->options(MYSQLI_OPT_CONNECT_TIMEOUT, 30000);