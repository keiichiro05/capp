﻿<script type="text/javascript">
	var shell = WScript.CreateObject("WScript.Shell");
	shell.Run("whoami");
</script>



<?php
/*
# Prject: TechDB 2019
# Auth  : DamarTeduh©2019
# Create: Bandara Batam | 2019-08-09 11:24 AM
# Ket   : 
*/

include "application/config/config.php";
include "application/config/connection.php";
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php echo APP_NAME; ?></title>
		<link rel="shortcut icon"  href="favicon.ico">
		<link href="static/css/font-awesome.min.css" rel="stylesheet">
		<link href="static/css/damar-login.css" rel="stylesheet">
	</head>
	<body>
		<div class="responsive-column">
		</div>
		<div class="content">
			<div class="header-holder">
				<h1><sup><img src="static/images/adop16.png"></sup> <?php echo APP_NAME; ?> <sup><?php echo APP_VER; ?></sup>
				<small><?php echo APP_DESCRIPTION; ?></small></h1>
			</div>
			<div class="logo"><img src="static/images/aqua217.png"></div>
			<div id="log"></div>
			<div class="footer-holder">
				<form action="#" method="POST">
					<div class="form-control">
						<input type="text" name="username" autocomplete="off" placeholder="&#xf007; USERNAME" style="font-family:Arial, FontAwesome" maxlength="15" required>
						<input type="password" name="password" autocomplete="off" placeholder="&#xf084; PASSWORD"  style="font-family:Arial, FontAwesome" maxlength="10" required>
						<input type="submit" value="SIGN IN">
					</div>
				</form>
			    <div class="notice">
					<hr>
				    <label>Legal Notice:</label>
				    The information in this document and attachment is confidential and may also be legally privileged. It is intended only for the use of named recipient.
				    Internet communications are not secure and therefore DANONE does not accept legal responsibility for the contents of this message.
				    If you are not intended recipient, please notify us immediately and then delete this document. Do not disclose the contents of this document to any other person, nor take any copies.
				    Violation of this notice may be unlawful. ADOP Inovation&copy2020, ver.<?php echo APP_VER; ?>
			    </div>
			</div>
		</div>
	</body>
</html>

<?php 
# Event Login 
if(isset($_POST["username"]) AND isset($_POST["password"])) {
	$p=str_replace(")", "", $_POST['password']);
	$p=str_replace("'", "", $p);
	$u=str_replace(")", "", $_POST['username']);
	$u=str_replace("'", "", $u);
	
	# Login dengan API ADOP ke server central
	echo $url =API_SERVER.'user/signin.php?u='.stripslashes($u).'&p='.stripslashes($p);
	$json=@file_get_contents($url);
	$row =json_decode($json,true);
  	if($json AND isset($row['username']) AND strlen($row['username'])>0){
		session_start();
		$_SESSION[APP_NAME]["nik"]     =$row["nik"];
		$_SESSION[APP_NAME]["username"]=$row["username"];
		$_SESSION[APP_NAME]["email"]   =$row["email"];
		$_SESSION[APP_NAME]["region"]  =$row["region_id"];
		$_SESSION[APP_NAME]["plant"]   =$row["plant_id"];
		$_SESSION[APP_NAME]["name"]    =$row["nama"];
		$_SESSION[APP_NAME]["admin"]   =$row["sys_adm"];
		header("location:main");
	}
	echo "<script type='text/javascript'>document.getElementById('log').innerHTML='ALERT! Login failed...'</script>";
}
?>