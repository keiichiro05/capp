<?php
/*
# Proj. : eVisitor
# Auth  : damarteduh@gmail.con©2020
# Create: Home | 2020-01-26 12:11 PM
*/

date_default_timezone_set("Asia/Jakarta");
?>

<?php
include $content;
?>