<?php
/*
# Prject: TechDB 2019
# Auth  : DamarTeduh©2019
# Create: Bandara Batam | 2019-08-09 11:24 AM
# Rev   : 
	20200123 06:45 AM, CITRA WORLD HOTEL SBY, Chg Pass
	20200123 06:45 AM, CITRA WORLD HOTEL SBY, Chg Address
	20200304 11:01 AM, BWG Plant, Edit logo tulisan ADOP fix position err. saat pop up
	20020215 05:27 AM, Home, reset menggunakan API
	20200306 06:46 AM, BWG El Royal, rework
*/

?>

<!-- Login Pop Up -->
<script type='text/javascript' src='static/js/popup.form.js'></script>
<link type="text/css" rel="stylesheet" href="static/css/popup.form.css"/>

<div class="navbar navbar-default navbar-fixed-top"  id="custom-bootstrap-menu">
	<div class="container-fluid">
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		  <div class="logo"><img src="static/images/adop16.png"> <?php echo APP_NAME.'<sup>'.APP_VER.'</sup>'; ?></div>
		</div>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav">
				<li><a href="../mos"> ADOP</a></li>
				<li><a href="main" class="main"> Main Menu</a></li>
			</ul> 
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#"><i class="fa fa-question-circle"></i> Help</a></li>
				<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-user"></i> <?php echo $_SESSION[APP_NAME]["name"]; ?> <span class="caret"></span></a>
				  	<ul class="dropdown-menu">
						<li><a href="javascript:fg_popup_form('fgChgPass','frmInner','bgChgPass', 80);">Ganti Password</a></li>
						<li class="divider"></li>
						<li><a href="auth?action=signout">Sign out</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div>
<div class="body-wrap-with-navbar">

<!-- Pop Up Form Change Pass
<div id='fgChgPass'>
  <div id="fgHeader">Change Password</div>
  <div id="frmInner">
    <div class='container'>
      <div class="col-md-4">
        <div class="row">
          <div class="form-group">
            <label>New Password</label>
            <input type="password" name="password" class="form-control" id="password" required>
          </div>
          <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control" id="confirmpassword" required>
          </div>
          <div id="missMatch" style="display: none; margin: 10px; font-style: italic; color: red;">Password tidak sama</div>
          <button type="button" id="cmdChgPass" class="btn btn-default" disabled>Submit</button>
          <a class="btn btn-default" href="javascript:fg_hideform('fgChgPass','bgChgPass');" role="button">Cancel</a>
        </div>
      </div>
    </div>
  </div>
</div> 
<div id='bgChgPass'></div> -->

<!--
nambahin fungsi ob_start() line 85
-->

<script type="text/javascript">
	$('#password').keyup(function(){ checkPersamaan(); });
	$('#confirmpassword').keyup(function(){ checkPersamaan(); });

	$("#cmdChgPass").on("click",function(){
		$.post("<?php ob_start(); echo $url; ?>"+$('#confirmpassword').val());
		window.location.replace("auth");
	});

	function checkPersamaan(){
		if($('#password').val()!=$('#confirmpassword').val()){
	        $('#missMatch').show();
	        $('#cmdChgPass').attr({disabled:true});
	    }
	    else{
	    	$('#missMatch').hide();
	        $('#cmdChgPass').attr({disabled:false});
	    }
	}
</script>